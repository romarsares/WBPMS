/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: thomas.proxy.rlwy.net    Database: railway
-- ------------------------------------------------------
-- Server version	9.7.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `address` (
  `address_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `street` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province_id` bigint unsigned DEFAULT NULL,
  `city_id` bigint unsigned DEFAULT NULL,
  `barangay_id` bigint unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`address_id`),
  KEY `province_id` (`province_id`),
  KEY `city_id` (`city_id`),
  KEY `barangay_id` (`barangay_id`),
  CONSTRAINT `address_ibfk_1` FOREIGN KEY (`province_id`) REFERENCES `province` (`province_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `address_ibfk_2` FOREIGN KEY (`city_id`) REFERENCES `city` (`city_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `address_ibfk_3` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`barangay_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Flat address structure; all geography references optional';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance` (
  `attendance_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `branch_assignment_id` bigint unsigned NOT NULL,
  `schedule_id` bigint unsigned DEFAULT NULL COMMENT 'NULL when no schedule assignment exists for this employee on this date',
  `attendance_date` date NOT NULL,
  `time_in` time DEFAULT NULL,
  `time_out` time DEFAULT NULL,
  `hours_worked_minutes` smallint unsigned NOT NULL DEFAULT '0',
  `late_minutes` smallint unsigned NOT NULL DEFAULT '0',
  `undertime_minutes` smallint unsigned NOT NULL DEFAULT '0',
  `overtime_minutes` smallint unsigned NOT NULL DEFAULT '0',
  `status` enum('Complete','Incomplete','ReviewRequired','Approved','Cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Complete',
  `source` enum('xls_import','manual') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `import_batch_id` bigint unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`attendance_id`),
  UNIQUE KEY `uq_attendance_employee_date` (`employee_id`,`attendance_date`),
  KEY `branch_assignment_id` (`branch_assignment_id`),
  KEY `schedule_id` (`schedule_id`),
  KEY `import_batch_id` (`import_batch_id`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`branch_assignment_id`) REFERENCES `employee_branch_assignment` (`branch_assignment_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `attendance_ibfk_4` FOREIGN KEY (`import_batch_id`) REFERENCES `attendance_import_batch` (`import_batch_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_attendance_schedule_id` FOREIGN KEY (`schedule_id`) REFERENCES `work_schedule` (`schedule_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1621 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Daily attendance; unique (employee_id, attendance_date)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES
(1537,110,131,4,'2025-05-02','06:57:00','16:30:00',513,0,30,0,'Complete','xls_import',48,'2026-11-10 02:51:53','2026-11-10 02:51:53'),
(1538,110,131,4,'2025-05-04','07:04:00','16:30:00',506,0,30,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1539,110,131,4,'2025-05-05','06:57:00','16:32:00',515,0,28,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1540,110,131,4,'2025-05-06','07:00:00','16:30:00',510,0,30,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1541,110,131,4,'2025-05-07','07:11:00','16:31:00',500,0,29,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1542,110,131,4,'2025-05-08','07:05:00','16:30:00',505,0,30,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1543,114,135,4,'2025-05-02','07:38:00','17:39:00',541,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1544,114,135,4,'2025-05-04','07:17:00','17:08:00',531,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1545,114,135,4,'2025-05-05','07:32:00','17:19:00',527,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1546,114,135,4,'2025-05-06','07:32:00','18:04:00',572,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1547,114,135,4,'2025-05-07','07:26:00','17:00:00',514,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 10:50:56'),
(1548,114,135,4,'2025-05-08','07:34:00','17:03:00',509,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1549,106,127,2,'2025-05-02','06:44:00','19:00:00',676,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 05:16:00'),
(1550,106,127,2,'2025-05-04','06:48:00',NULL,0,0,0,0,'Incomplete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1551,106,127,2,'2025-05-05','06:43:00',NULL,0,0,0,0,'Incomplete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1552,106,127,2,'2025-05-06','06:50:00','16:28:00',518,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1553,106,127,2,'2025-05-07','07:11:00','16:28:00',497,11,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1554,106,127,2,'2025-05-08','06:33:00','16:33:00',540,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1555,112,133,2,'2025-05-02','06:17:00','19:00:00',703,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 05:16:55'),
(1556,112,133,2,'2025-05-04','06:38:00','16:57:00',559,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1557,112,133,2,'2025-05-05','06:30:00','16:47:00',557,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1558,112,133,2,'2025-05-06','06:44:00','16:29:00',525,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1559,112,133,2,'2025-05-07','07:11:00','16:27:00',496,11,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1560,112,133,2,'2025-05-08','06:43:00','16:28:00',525,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1561,115,136,2,'2025-05-02','07:20:00','17:38:00',558,20,0,0,'Complete','xls_import',48,'2026-11-10 02:51:54','2026-11-10 02:51:54'),
(1562,115,136,2,'2025-05-04','06:52:00','16:40:00',528,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1563,115,136,2,'2025-05-05','06:52:00','16:40:00',528,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1564,115,136,2,'2025-05-06','06:56:00','16:38:00',522,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1565,115,136,2,'2025-05-07','07:11:00','16:36:00',505,11,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1566,115,136,2,'2025-05-08','06:56:00','16:39:00',523,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1567,104,125,2,'2025-05-02','06:45:00','16:49:00',544,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1568,104,125,2,'2025-05-04','07:40:00','16:58:00',498,40,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1569,104,125,2,'2025-05-05','07:38:00','17:00:00',502,38,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1570,104,125,2,'2025-05-06','07:37:00','16:58:00',501,37,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1571,104,125,2,'2025-05-07','07:44:00','16:57:00',493,44,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1572,104,125,2,'2025-05-08','07:40:00','17:00:00',500,40,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1573,109,130,2,'2025-05-02','06:57:00','19:00:00',663,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 05:23:01'),
(1574,109,130,2,'2025-05-04','06:47:00','16:34:00',527,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1575,109,130,2,'2025-05-05','06:58:00','16:39:00',521,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1576,109,130,2,'2025-05-06','06:50:00','16:29:00',519,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1577,109,130,2,'2025-05-07','07:14:00','16:27:00',493,14,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1578,109,130,2,'2025-05-08','06:54:00','16:30:00',516,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1579,113,134,2,'2025-05-02','06:33:00','16:54:00',561,0,0,0,'ReviewRequired','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1580,113,134,2,'2025-05-04','06:35:00','16:32:00',537,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1581,113,134,2,'2025-05-05','06:49:00','16:33:00',524,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1582,113,134,2,'2025-05-06','06:56:00','16:29:00',513,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 02:51:55'),
(1583,113,134,2,'2025-05-07','07:00:00','16:28:00',508,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:55','2026-11-10 05:20:59'),
(1584,113,134,2,'2025-05-08','06:38:00','16:30:00',532,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1585,116,137,1,'2025-05-02','06:48:00','16:47:00',539,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1586,116,137,1,'2025-05-04','07:30:00','16:52:00',502,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1587,116,137,1,'2025-05-05','07:01:00','16:38:00',517,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1588,116,137,1,'2025-05-06','07:27:00','18:04:00',577,0,0,0,'ReviewRequired','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1589,116,137,1,'2025-05-07','07:28:00','16:57:00',509,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1590,116,137,1,'2025-05-08','06:53:00','16:56:00',543,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1591,105,126,4,'2025-05-02','07:29:00','17:00:00',511,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 05:25:20'),
(1592,105,126,4,'2025-05-04','07:33:00','16:59:00',506,0,1,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1593,105,126,4,'2025-05-05','07:22:00','17:09:00',527,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1594,105,126,4,'2025-05-06','07:33:00',NULL,0,0,0,0,'Incomplete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1595,105,126,4,'2025-05-07','07:35:00','16:56:00',501,0,4,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1596,105,126,4,'2025-05-08','07:31:00','17:02:00',511,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1597,107,128,2,'2025-05-02','06:51:00','16:52:00',541,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1598,107,128,2,'2025-05-04','07:03:00','16:29:00',506,3,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1599,107,128,2,'2025-05-05','06:50:00','17:00:00',550,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1600,107,128,2,'2025-05-06','07:01:00','16:28:00',507,1,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1601,107,128,2,'2025-05-07','07:12:00','16:27:00',495,12,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1602,107,128,2,'2025-05-08','06:41:00','17:00:00',559,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1603,117,138,1,'2025-05-02','07:42:00','17:00:00',498,12,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 05:25:57'),
(1604,117,138,1,'2025-05-04','06:45:00','16:59:00',554,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1605,117,138,1,'2025-05-05','06:41:00','16:58:00',557,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1606,117,138,1,'2025-05-06','06:54:00','16:58:00',544,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:56','2026-11-10 02:51:56'),
(1607,117,138,1,'2025-05-07','07:12:00','16:57:00',525,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:57','2026-11-10 02:51:57'),
(1608,117,138,1,'2025-05-08','06:40:00','16:27:00',527,0,3,0,'Complete','xls_import',48,'2026-11-10 02:51:57','2026-11-10 02:51:57'),
(1609,108,129,2,'2025-05-02','06:57:00',NULL,0,0,0,0,'Incomplete','xls_import',48,'2026-11-10 02:51:57','2026-11-10 02:51:57'),
(1610,108,129,2,'2025-05-04','06:56:00','16:00:00',484,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:57','2026-11-10 05:27:16'),
(1611,108,129,2,'2025-05-05','06:52:00','16:39:00',527,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:57','2026-11-10 02:51:57'),
(1612,108,129,2,'2025-05-06','06:55:00','16:31:00',516,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:57','2026-11-10 02:51:57'),
(1613,108,129,2,'2025-05-07','07:11:00','16:28:00',497,11,0,0,'Complete','xls_import',48,'2026-11-10 02:51:57','2026-11-10 02:51:57'),
(1614,108,129,2,'2025-05-08','06:53:00','16:34:00',521,0,0,0,'Complete','xls_import',48,'2026-11-10 02:51:57','2026-11-10 02:51:57'),
(1615,111,132,4,'2025-05-02','06:54:00',NULL,0,0,0,0,'Incomplete','xls_import',48,'2026-11-10 02:51:57','2026-11-10 02:51:57'),
(1616,111,132,4,'2025-05-04','06:40:00','16:53:00',553,0,7,0,'Complete','xls_import',48,'2026-11-10 02:51:57','2026-11-10 02:51:57'),
(1617,111,132,4,'2025-05-05','06:52:00','16:37:00',525,0,23,0,'Complete','xls_import',48,'2026-11-10 02:51:57','2026-11-10 02:51:57'),
(1618,111,132,4,'2025-05-06','06:47:00','16:27:00',520,0,33,0,'Complete','xls_import',48,'2026-11-10 02:51:57','2026-11-10 02:51:57'),
(1619,111,132,4,'2025-05-07','07:15:00','16:56:00',521,0,4,0,'Complete','xls_import',48,'2026-11-10 02:51:57','2026-11-10 02:51:57'),
(1620,111,132,4,'2025-05-08','06:33:00','16:33:00',540,0,27,0,'Complete','xls_import',48,'2026-11-10 02:51:57','2026-11-10 02:51:57');
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_adjustment`
--

DROP TABLE IF EXISTS `attendance_adjustment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_adjustment` (
  `adjustment_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `attendance_id` bigint unsigned NOT NULL,
  `adjusted_by` bigint unsigned DEFAULT NULL,
  `old_time_in` time DEFAULT NULL,
  `new_time_in` time DEFAULT NULL,
  `old_time_out` time DEFAULT NULL,
  `new_time_out` time DEFAULT NULL,
  `old_overtime_minutes` smallint unsigned NOT NULL DEFAULT '0',
  `new_overtime_minutes` smallint unsigned NOT NULL DEFAULT '0',
  `adjustment_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adjustment_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`adjustment_id`),
  KEY `attendance_id` (`attendance_id`),
  KEY `adjusted_by` (`adjusted_by`),
  CONSTRAINT `attendance_adjustment_ibfk_1` FOREIGN KEY (`attendance_id`) REFERENCES `attendance` (`attendance_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `attendance_adjustment_ibfk_2` FOREIGN KEY (`adjusted_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Append-only log of manual attendance corrections';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_adjustment`
--

LOCK TABLES `attendance_adjustment` WRITE;
/*!40000 ALTER TABLE `attendance_adjustment` DISABLE KEYS */;
INSERT INTO `attendance_adjustment` VALUES
(30,1549,2,'06:44:00','06:44:00',NULL,'19:00:00',0,0,'time_correction','Forgot to punch','2026-11-10 05:16:00','2026-11-10 05:16:00'),
(31,1555,2,'06:17:00','06:17:00',NULL,'19:00:00',0,0,'time_correction','Forgot to punch','2026-11-10 05:16:55','2026-11-10 05:16:55'),
(32,1583,2,'16:28:00','07:00:00',NULL,'16:28:00',0,0,'time_correction','forgot to punch','2026-11-10 05:20:59','2026-11-10 05:20:59'),
(33,1573,2,'06:57:00','06:57:00',NULL,'19:00:00',0,0,'time_correction','forgot to punch','2026-11-10 05:23:01','2026-11-10 05:23:02'),
(34,1591,2,'07:29:00','07:29:00',NULL,'17:00:00',0,0,'time_correction','Forgot to punch','2026-11-10 05:25:20','2026-11-10 05:25:20'),
(35,1603,2,'07:42:00','07:42:00',NULL,'17:00:00',0,0,'time_correction','Forgot to Punch','2026-11-10 05:25:57','2026-11-10 05:25:57'),
(36,1610,2,'06:56:00','06:56:00',NULL,'16:00:00',0,0,'time_correction','Forgot to punch','2026-11-10 05:27:16','2026-11-10 05:27:16'),
(37,1547,142,'07:26:00','07:26:00',NULL,'17:00:00',0,0,'time_correction','Forgot Punch','2026-11-10 10:50:56','2026-11-10 10:50:56');
/*!40000 ALTER TABLE `attendance_adjustment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_import_batch`
--

DROP TABLE IF EXISTS `attendance_import_batch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_import_batch` (
  `import_batch_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `device_id` bigint unsigned NOT NULL,
  `uploaded_by` bigint unsigned NOT NULL,
  `file_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_checksum` char(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_year` smallint unsigned NOT NULL,
  `source_month` tinyint unsigned NOT NULL,
  `parser_version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'LDE_XLS_DAILY_LOG_V1',
  `status` enum('Processing','Draft','Approved','Completed','Rejected','Cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Processing',
  `records_parsed` int unsigned NOT NULL DEFAULT '0',
  `records_matched` int unsigned NOT NULL DEFAULT '0',
  `records_unmatched` int unsigned NOT NULL DEFAULT '0',
  `duplicates_skipped` int unsigned NOT NULL DEFAULT '0',
  `incomplete_days` int unsigned NOT NULL DEFAULT '0',
  `multi_punch_days` int unsigned NOT NULL DEFAULT '0',
  `uploaded_at` datetime NOT NULL,
  `completed_at` datetime DEFAULT NULL,
  `approved_by` bigint unsigned DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancellation_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`import_batch_id`),
  UNIQUE KEY `uq_batch_checksum` (`file_checksum`),
  KEY `device_id` (`device_id`),
  KEY `uploaded_by` (`uploaded_by`),
  KEY `approved_by` (`approved_by`),
  KEY `cancelled_by` (`cancelled_by`),
  CONSTRAINT `attendance_import_batch_ibfk_1` FOREIGN KEY (`device_id`) REFERENCES `biometric_device` (`device_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `attendance_import_batch_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `attendance_import_batch_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `attendance_import_batch_ibfk_4` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_batch_month` CHECK ((`source_month` between 1 and 12))
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='One record per uploaded .xls file; SHA-256 prevents duplicate imports';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_import_batch`
--

LOCK TABLES `attendance_import_batch` WRITE;
/*!40000 ALTER TABLE `attendance_import_batch` DISABLE KEYS */;
INSERT INTO `attendance_import_batch` VALUES
(48,1,2,'Attendance_2025-05-02_Fri_to_2025-05-08_Thu.xls','f74476332ab1fb99ba51ccc9ccb2ec948b392c45c7cd79c877ce37f6eac273d8',2025,5,'LDE_XLS_DAILY_LOG_V1','Approved',157,157,0,0,13,2,'2026-11-10 02:51:47','2026-11-10 02:51:57',2,'2026-11-10 02:54:39',NULL,NULL,NULL),
(49,1,2,'2025-05-02_to_2025-05-08.xls','3464afeff98e9d096cc3c2840ef2765cfc90d442e4f39319f184e746b6d2056e',2025,5,'LDE_XLS_DAILY_LOG_V1','Cancelled',157,0,0,157,0,0,'2026-11-10 10:12:02','2026-11-10 10:12:03',2,'2026-11-10 10:12:10',2,'2026-11-10 10:12:58','Cancelled by HR before payroll use.');
/*!40000 ALTER TABLE `attendance_import_batch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_policy_flag`
--

DROP TABLE IF EXISTS `attendance_policy_flag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_policy_flag` (
  `flag_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `flag_type` enum('ConsecutiveLate','TardinessMemoCap','TwoWeekAbsence','ConsecutiveAWOL') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `triggering_date` date NOT NULL,
  `status` enum('Pending','Reviewed','Closed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `reviewed_by` bigint unsigned DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `action_taken` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`flag_id`),
  UNIQUE KEY `uq_apf_employee_type_date` (`employee_id`,`flag_type`,`triggering_date`),
  KEY `reviewed_by` (`reviewed_by`),
  CONSTRAINT `attendance_policy_flag_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `attendance_policy_flag_ibfk_2` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Attendance threshold flags for HR review';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_policy_flag`
--

LOCK TABLES `attendance_policy_flag` WRITE;
/*!40000 ALTER TABLE `attendance_policy_flag` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendance_policy_flag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_punch`
--

DROP TABLE IF EXISTS `attendance_punch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_punch` (
  `attendance_id` bigint unsigned NOT NULL,
  `punch_id` bigint unsigned NOT NULL,
  `evidence_role` enum('TimeIn','Intermediate','TimeOut','Unclassified') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`attendance_id`,`punch_id`),
  UNIQUE KEY `uq_ap_punch_id` (`punch_id`),
  CONSTRAINT `attendance_punch_ibfk_1` FOREIGN KEY (`attendance_id`) REFERENCES `attendance` (`attendance_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `attendance_punch_ibfk_2` FOREIGN KEY (`punch_id`) REFERENCES `biometric_punch` (`punch_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Links each attendance record to its supporting biometric_punch rows';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_punch`
--

LOCK TABLES `attendance_punch` WRITE;
/*!40000 ALTER TABLE `attendance_punch` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendance_punch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_site`
--

DROP TABLE IF EXISTS `attendance_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_site` (
  `site_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Asia/Manila',
  `status` enum('Active','Inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`site_id`),
  UNIQUE KEY `uq_site_code` (`site_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Physical locations where biometric devices are installed';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_site`
--

LOCK TABLES `attendance_site` WRITE;
/*!40000 ALTER TABLE `attendance_site` DISABLE KEYS */;
INSERT INTO `attendance_site` VALUES
(1,'BANGA-SITE','Banga Attendance Site','Banga, South Cotabato','Asia/Manila','Active','2026-09-02 01:00:56','2026-09-02 01:00:56'),
(2,'SURALLAH-SITE','Surallah Attendance Site','Surallah, South Cotabato','Asia/Manila','Active','2026-09-02 01:00:56','2026-09-02 01:00:56');
/*!40000 ALTER TABLE `attendance_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `log_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `event_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_performed` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_affected` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `record_id` bigint unsigned DEFAULT NULL,
  `attempted_identifier` varchar(254) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `idx_audit_user_action_at` (`user_id`,`action_at`),
  KEY `idx_audit_event_action_at` (`event_type`,`action_at`),
  KEY `idx_audit_request_id` (`request_id`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2087 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Immutable audit trail; user_id NULL for unauthenticated events';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES
(1,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','382e2a9e-aa4f-418a-9ad9-d7ffa43cb1bf','49.149.27.91, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-06 17:06:32','2026-10-06 17:06:32'),
(2,NULL,'login_failure','login_attempt',NULL,NULL,'owner','7e8248c7-11bc-4bdc-a83c-2956c9759acd','49.149.27.91, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-06 17:06:42','2026-10-06 17:06:42'),
(3,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead','82ddc957-4466-45b0-9536-710f99e207fd','49.149.27.91, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-06 17:07:05','2026-10-06 17:07:05'),
(4,NULL,'login_failure','login_attempt',NULL,NULL,'owner','7ff83406-1198-4e09-a73f-18cc3ef2d2c5','49.149.27.91, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-06 17:12:21','2026-10-06 17:12:21'),
(5,NULL,'login_failure','login_attempt',NULL,NULL,'owner','355ee3da-2ea0-4eba-af9d-700b2037500d','49.149.27.91, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-06 17:12:44','2026-10-06 17:12:44'),
(6,1,'login_success','login','users',1,NULL,'8d7514b0-a908-4a03-9fe9-82adb4ba4c72','49.149.27.91, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-06 17:12:51','2026-10-06 17:12:51'),
(7,2,'login_success','login','users',2,NULL,'94f92264-da21-49e9-8e2c-0c2890e6551d','49.149.27.91, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-06 17:14:26','2026-10-06 17:14:26'),
(8,2,'login_success','login','users',2,NULL,'227073e2-6492-435c-b980-89fed3151927','49.149.2.255, 152.233.68.97','Mozilla/5.0 (Linux; Android 15; Infinix X1201 Build/AP3A.240905.015.A2; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.36 Safari/537.36 [FB_IAB/FB4A;FBAV/581.0.0.49.91;]','User logged in successfully.','2026-10-06 17:15:27','2026-10-06 17:15:27'),
(9,2,'login_success','login','users',2,NULL,'38575ce9-5813-476f-96ef-27e4f023ebba','165.99.250.31, 152.233.68.105','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.36 Safari/537.36 [FB_IAB/FB4A;FBAV/581.0.0.49.91;]','User logged in successfully.','2026-10-06 17:21:30','2026-10-06 17:21:30'),
(10,2,'login_success','login','users',2,NULL,'4d52ce4a-d412-4df4-8b66-5136dae3b915','180.191.138.117, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 02:22:46','2026-10-07 02:22:46'),
(11,1,'login_success','login','users',1,NULL,'bcab4e21-c1e5-495e-9a8c-bbf69f07c229','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 02:30:00','2026-10-07 02:30:00'),
(12,2,'login_success','login','users',2,NULL,'f3a77975-128d-457b-b8e0-5bc0d1726510','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 02:35:12','2026-10-07 02:35:12'),
(13,2,'user_provisioned','user_provisioned','users',84,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'test.spaced\' for employee_id=79','2026-10-07 02:38:29','2026-10-07 02:38:29'),
(14,NULL,'login_success','login','users',84,NULL,'0e71fde0-87b3-4bf4-b954-f05e2f19efbe','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 02:39:07','2026-10-07 02:39:07'),
(15,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','619ed15b-0289-4e07-a7d6-4fff4bf260ff','49.146.60.226, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-07 05:14:07','2026-10-07 05:14:07'),
(16,2,'login_success','login','users',2,NULL,'99ff24d9-a106-4e44-8b6d-239e3eeac808','49.146.60.226, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 05:14:35','2026-10-07 05:14:35'),
(17,2,'login_success','login','users',2,NULL,'9799ee0b-d076-43a0-8e35-9b521a0c14de','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 07:25:34','2026-10-07 07:25:34'),
(18,2,'user_provisioned','user_provisioned','users',85,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'ronan.delacruz\' for employee_id=80','2026-10-07 07:29:42','2026-10-07 07:29:42'),
(19,NULL,'login_success','login','users',85,NULL,'f68237de-cc82-48c3-9dce-92ad7eb74664','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 07:30:24','2026-10-07 07:30:24'),
(20,2,'login_success','login','users',2,NULL,'d0a9c5a2-27e6-4c09-80dc-9162974062d2','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 07:30:25','2026-10-07 07:30:25'),
(21,2,'login_success','login','users',2,NULL,'d2be35d7-2efb-4097-8e93-402c409073d0','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 07:31:23','2026-10-07 07:31:23'),
(22,2,'user_updated','user_updated','users',85,NULL,NULL,NULL,NULL,'Updated user_id=85: username=\'ronan.delacruz\', role_id=3, status=\'Active\'','2026-10-07 07:32:07','2026-10-07 07:32:07'),
(23,2,'user_provisioned','user_provisioned','users',86,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'melanie.vidal\' for employee_id=81','2026-10-07 07:39:06','2026-10-07 07:39:06'),
(24,2,'user_provisioned','user_provisioned','users',87,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'amara.laurence\' for employee_id=82','2026-10-07 07:41:29','2026-10-07 07:41:29'),
(25,2,'user_provisioned','user_provisioned','users',88,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'linda.lebuna\' for employee_id=83','2026-10-07 07:43:46','2026-10-07 07:43:46'),
(26,NULL,'login_success','login','users',86,NULL,'805c77c7-1f85-4acd-828e-3c62f722a7f5','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 07:44:16','2026-10-07 07:44:16'),
(27,NULL,'login_failure','login_attempt',NULL,NULL,'amara@lightdiamond.com','924bf018-930b-49a1-b288-40c37e9fd206','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-07 07:45:03','2026-10-07 07:45:03'),
(28,NULL,'login_failure','login_attempt',NULL,NULL,'amara@lightdiamond.com','0c9b59dd-9583-4d2d-8f86-c3b2860cf2c6','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-07 07:45:23','2026-10-07 07:45:23'),
(29,NULL,'login_failure','login_attempt',NULL,NULL,'amara@lightdiamond.com','60a00004-7a3a-44cc-8a6b-0a139becbf07','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-07 07:45:43','2026-10-07 07:45:43'),
(30,NULL,'login_success','login','users',88,NULL,'ce849bfb-897a-49f4-b999-6051f67c5a36','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 07:45:58','2026-10-07 07:45:58'),
(31,2,'login_success','login','users',2,NULL,'3df6db89-6d45-4969-ba01-4eec01775003','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 07:46:46','2026-10-07 07:46:46'),
(32,2,'user_provisioned','user_provisioned','users',89,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'jenelyn.carpizo\' for employee_id=84','2026-10-07 08:08:07','2026-10-07 08:08:07'),
(33,2,'user_provisioned','user_provisioned','users',90,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'albert.indo\' for employee_id=85','2026-10-07 08:10:30','2026-10-07 08:10:30'),
(34,NULL,'login_success','login','users',90,NULL,'fbb03531-881c-4082-986f-edf567a156d5','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:11:17','2026-10-07 08:11:17'),
(35,NULL,'login_success','login','users',89,NULL,'6c78e017-7e74-4557-a607-d490021faa40','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:12:28','2026-10-07 08:12:28'),
(36,NULL,'login_success','login','users',87,NULL,'c0bf0b8e-0eb2-4903-a9fb-8f1f95247776','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:14:25','2026-10-07 08:14:25'),
(37,2,'login_success','login','users',2,NULL,'8606bc69-7b0d-45c5-9758-dc9c724b1f3f','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:15:52','2026-10-07 08:15:52'),
(38,2,'user_provisioned','user_provisioned','users',91,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'irish.bansilao\' for employee_id=86','2026-10-07 08:31:55','2026-10-07 08:31:55'),
(39,NULL,'login_success','login','users',91,NULL,'a6e771db-56b8-48fc-84f5-61496ff838f4','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:32:19','2026-10-07 08:32:19'),
(40,2,'login_success','login','users',2,NULL,'869e3032-1867-4704-b2bb-517781683397','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:33:59','2026-10-07 08:33:59'),
(41,2,'login_success','login','users',2,NULL,'e5e47d1c-71dd-4ac9-b9fa-7edc3c792f21','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:34:52','2026-10-07 08:34:52'),
(42,2,'user_provisioned','user_provisioned','users',92,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'joshua.pugay\' for employee_id=87','2026-10-07 08:36:47','2026-10-07 08:36:47'),
(43,2,'user_provisioned','user_provisioned','users',93,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'isabela.tayong\' for employee_id=88','2026-10-07 08:38:55','2026-10-07 08:38:55'),
(44,NULL,'login_success','login','users',93,NULL,'fa503578-b30e-4b5a-bde9-648271e5b23d','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:39:23','2026-10-07 08:39:23'),
(45,NULL,'login_success','login','users',92,NULL,'cf615026-2905-4d22-acf5-ed5edce56521','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:40:50','2026-10-07 08:40:50'),
(46,2,'user_provisioned','user_provisioned','users',94,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'lovely.paguntalan\' for employee_id=89','2026-10-07 08:41:24','2026-10-07 08:41:24'),
(47,2,'login_success','login','users',2,NULL,'5c9ff597-95bb-47e9-b1a4-c990a3b75f95','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:42:31','2026-10-07 08:42:31'),
(48,NULL,'login_success','login','users',94,NULL,'6096f06a-45f4-4ceb-92ba-5486306ba6e2','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:42:54','2026-10-07 08:42:54'),
(49,2,'login_success','login','users',2,NULL,'23029c9b-a667-49c5-b4e7-0e665c96d470','122.3.73.126, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:50:31','2026-10-07 08:50:31'),
(50,1,'login_success','login','users',1,NULL,'4be997ad-bcb2-4906-9c43-d00f4bd87879','122.3.73.126, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:55:16','2026-10-07 08:55:16'),
(51,NULL,'login_success','login','users',93,NULL,'c2cfdb9e-876f-4b0b-b87f-7a2daadb8f14','122.3.73.126, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:58:31','2026-10-07 08:58:31'),
(52,2,'login_success','login','users',2,NULL,'3a5074e7-4294-4441-b536-b6b4d0d4bbc9','122.3.73.126, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:59:05','2026-10-07 08:59:05'),
(53,2,'user_provisioned','user_provisioned','users',95,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'dave.dalipe\' for employee_id=90','2026-10-07 08:59:31','2026-10-07 08:59:31'),
(54,NULL,'login_success','login','users',95,NULL,'546fba71-c4e7-404d-ad4b-09acb1b9e3ec','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 08:59:58','2026-10-07 08:59:58'),
(55,1,'login_success','login','users',1,NULL,'a52b1c5e-fd99-421c-b18d-8c65bebce616','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-07 09:02:38','2026-10-07 09:02:38'),
(56,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','dfef15ec-f0b8-43ab-93eb-f1420c18de6f','180.191.138.117, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-08 00:46:58','2026-10-08 00:46:58'),
(57,2,'login_success','login','users',2,NULL,'801f35a8-108e-4dc1-a21a-c6f1074601ab','180.191.138.117, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-08 00:47:05','2026-10-08 00:47:05'),
(58,2,'login_success','login','users',2,NULL,'33b2b5f9-6dcd-4261-a0ee-0ed196bfccbd','180.191.138.117, 152.233.68.97','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36','User logged in successfully.','2026-10-08 14:04:04','2026-10-08 14:04:04'),
(59,2,'login_success','login','users',2,NULL,'7715349a-44de-4ce5-89dd-34471810c1cd','110.54.207.57, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-08 16:42:41','2026-10-08 16:42:41'),
(60,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','b8658afd-7d9e-4e35-841b-8ba504b3a45e','180.191.138.117, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-09 08:05:26','2026-10-09 08:05:26'),
(61,2,'login_success','login','users',2,NULL,'46902005-894d-4226-a33c-18889fe90257','180.191.138.117, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-09 08:05:36','2026-10-09 08:05:36'),
(62,2,'login_success','login','users',2,NULL,'d8cdc655-0f98-4fd5-8e7a-c0f723c98109','49.149.162.18, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-09 08:21:32','2026-10-09 08:21:32'),
(63,2,'login_success','login','users',2,NULL,'be7428d5-e6af-4b3a-8ee3-907214af6715','165.99.250.108, 152.233.68.97','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.36 Safari/537.36 [FB_IAB/FB4A;FBAV/581.0.0.49.91;]','User logged in successfully.','2026-10-09 16:09:31','2026-10-09 16:09:31'),
(64,2,'login_success','login','users',2,NULL,'a3eb2c0a-b64e-493c-a633-232b5ee5c211','49.149.12.2, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-10 15:38:08','2026-10-10 15:38:08'),
(65,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead.demo.test','9742b433-d1d0-4f4a-b00d-cd847049503a','180.191.139.34, 152.233.15.121','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.57 Safari/537.36 [FB_IAB/FB4A;FBAV/581.0.0.49.91;]','Login failed: invalid credentials or inactive account.','2026-10-10 15:47:41','2026-10-10 15:47:41'),
(66,2,'login_success','login','users',2,NULL,'c1ecfc89-78c0-4967-8f9c-941c9d6997c0','180.191.139.34, 152.233.15.121','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.57 Safari/537.36 [FB_IAB/FB4A;FBAV/581.0.0.49.91;]','User logged in successfully.','2026-10-10 15:47:57','2026-10-10 15:47:57'),
(67,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','f7cbe874-75be-472c-b3b9-d0f447f4a17c','110.54.204.196, 152.233.68.98','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-11 08:51:20','2026-10-11 08:51:20'),
(68,2,'login_success','login','users',2,NULL,'a152bbdc-335a-458e-bad4-8b61c20c9955','110.54.204.196, 152.233.68.98','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36','User logged in successfully.','2026-10-11 08:51:33','2026-10-11 08:51:33'),
(69,2,'login_success','login','users',2,NULL,'882e67a4-8eb9-46c2-9fae-0668be4707ee','49.149.26.158, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-11 13:33:45','2026-10-11 13:33:45'),
(70,2,'login_success','login','users',2,NULL,'84c29ee4-ff47-4e55-a86d-a19ab4f6c42e','180.191.139.34, 152.233.15.123','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.57 Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]','User logged in successfully.','2026-10-11 13:34:38','2026-10-11 13:34:38'),
(71,1,'login_success','login','users',1,NULL,'1c53dbd9-a657-420b-87c2-58fcbb4a84a1','49.149.26.158, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-11 13:45:06','2026-10-11 13:45:06'),
(72,2,'login_success','login','users',2,NULL,'f2714a57-006e-40d0-99ac-f84d8f4e3eca','49.149.26.158, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-11 13:45:31','2026-10-11 13:45:31'),
(73,1,'login_success','login','users',1,NULL,'79ec9fda-9170-4968-8def-1b89e9940f17','180.191.139.34, 152.233.68.98','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.57 Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]','User logged in successfully.','2026-10-11 14:03:44','2026-10-11 14:03:44'),
(74,2,'login_success','login','users',2,NULL,'b0eb53ce-4233-406c-8e14-a8efec8034a6','180.191.139.34, 152.233.68.98','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.57 Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]','User logged in successfully.','2026-10-11 14:05:36','2026-10-11 14:05:36'),
(75,2,'login_success','login','users',2,NULL,'4700926d-7c30-4da5-b85f-b3e5b869aa87','35.185.176.83, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-11 14:05:41','2026-10-11 14:05:41'),
(76,NULL,'login_success','login','users',92,NULL,'ea53f4af-d5ce-4a62-9f7b-0d5aca6bcade','180.191.139.34, 152.233.68.98','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.57 Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]','User logged in successfully.','2026-10-11 14:06:25','2026-10-11 14:06:25'),
(77,NULL,'login_failure','login_attempt',NULL,NULL,'hrhread@demo.test','152d94dc-ef60-44a1-8cdb-ead732fef5cd','180.191.139.34, 152.233.68.98','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.57 Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]','Login failed: invalid credentials or inactive account.','2026-10-11 14:07:26','2026-10-11 14:07:26'),
(78,2,'login_success','login','users',2,NULL,'2377b1f7-8861-41dc-9d4d-1f16a3a99bc2','180.191.139.34, 152.233.68.98','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.57 Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]','User logged in successfully.','2026-10-11 14:07:49','2026-10-11 14:07:49'),
(79,NULL,'login_success','login','users',89,NULL,'52ab0a0f-c736-46ab-888b-1b2fb57dbc8a','180.191.139.34, 152.233.68.98','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.57 Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]','User logged in successfully.','2026-10-11 14:14:29','2026-10-11 14:14:29'),
(80,NULL,'login_success','login','users',85,NULL,'c8e2c114-5fa3-4904-a02c-f5b8c02dcf5f','180.191.139.34, 152.233.68.98','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.57 Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]','User logged in successfully.','2026-10-11 14:15:37','2026-10-11 14:15:37'),
(81,2,'login_success','login','users',2,NULL,'fbe4d427-11a4-4867-bb7d-02dedcd3d677','180.191.139.34, 152.233.68.98','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.57 Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]','User logged in successfully.','2026-10-11 14:20:02','2026-10-11 14:20:02'),
(82,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','29aa8c4f-f778-4b71-a8ef-8ce841bf7c3f','35.185.176.83, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-11 14:26:11','2026-10-11 14:26:11'),
(83,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','3ef57d40-6709-4501-83c5-3315d11d5b46','35.185.176.83, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-11 14:26:20','2026-10-11 14:26:20'),
(84,2,'login_success','login','users',2,NULL,'28950335-537e-4cff-ab1b-a351c6aa995d','35.185.176.83, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-11 14:26:32','2026-10-11 14:26:32'),
(85,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo-test','352d44e6-c698-4997-9906-bab909457571','180.191.139.34, 152.233.68.97','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.57 Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]','Login failed: invalid credentials or inactive account.','2026-10-11 14:49:39','2026-10-11 14:49:39'),
(86,1,'login_success','login','users',1,NULL,'2313c4d9-5fa5-4dd5-ab87-c114a1a1a30b','180.191.139.34, 152.233.68.97','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.57 Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]','User logged in successfully.','2026-10-11 14:50:22','2026-10-11 14:50:22'),
(87,2,'login_success','login','users',2,NULL,'e4dfdc1a-9ca9-4bfd-8e27-cbbaaf52a9c0','180.191.139.34, 152.233.68.97','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/153.0.8010.57 Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]','User logged in successfully.','2026-10-11 14:50:50','2026-10-11 14:50:50'),
(88,2,'login_success','login','users',2,NULL,'90d81c06-6234-4b18-8bca-6471d03ca3b5','49.149.162.18, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-12 01:30:40','2026-10-12 01:30:40'),
(89,2,'login_success','login','users',2,NULL,'db4c6458-42a6-4395-a0fb-cee964f76bce','49.149.162.18, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-12 02:31:54','2026-10-12 02:31:54'),
(90,2,'login_success','login','users',2,NULL,'f879a6a6-7719-446d-8bc2-75fd52d563f9','49.149.162.18, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-12 05:07:15','2026-10-12 05:07:15'),
(91,2,'login_success','login','users',2,NULL,'7ef0d53e-4293-4320-bf08-f18500b096dc','49.149.162.18, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-12 07:07:33','2026-10-12 07:07:33'),
(92,1,'login_success','login','users',1,NULL,'e97218a5-1429-4a8c-94b8-9d45b2121634','49.149.162.18, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-12 07:14:57','2026-10-12 07:14:57'),
(93,NULL,'login_failure','login_attempt',NULL,NULL,'r@demo.test','240a45e1-edba-4375-95dc-04d0c3729426','49.149.162.18, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-12 07:18:56','2026-10-12 07:18:56'),
(94,2,'login_success','login','users',2,NULL,'7f986315-310c-4dc4-9cff-147df9226711','49.149.162.18, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-12 07:19:04','2026-10-12 07:19:04'),
(95,2,'login_success','login','users',2,NULL,'267c8fd1-eee4-4ada-b21e-82b0e4126b1a','49.149.162.18, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-12 07:19:17','2026-10-12 07:19:17'),
(96,1,'login_success','login','users',1,NULL,'cacb30df-4b33-49f7-b75d-2fc0fd32f1fd','49.149.162.18, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-12 07:20:02','2026-10-12 07:20:02'),
(97,2,'login_success','login','users',2,NULL,'2650c949-bac5-4369-aed8-70ae2f9d16f4','49.149.162.18, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-12 07:20:23','2026-10-12 07:20:23'),
(98,1,'login_success','login','users',1,NULL,'3e981c86-a5e6-4b8e-b7a1-baa23d187448','49.149.162.18, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-12 07:22:30','2026-10-12 07:22:30'),
(99,2,'login_success','login','users',2,NULL,'98b4ecc2-fe2a-455a-b02a-375c08b6ba8c','49.149.162.18, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-12 08:07:39','2026-10-12 08:07:39'),
(100,1,'login_success','login','users',1,NULL,'f6a39f05-df52-4545-bb67-73eab2a8b75d','49.149.162.18, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-12 08:08:33','2026-10-12 08:08:33'),
(101,2,'login_success','login','users',2,NULL,'6cadb661-7a39-490c-a354-1800f51626a3','49.145.195.210, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 02:58:11','2026-10-13 02:58:11'),
(102,1,'login_success','login','users',1,NULL,'0a123edf-d351-44a2-a1f6-744124593b35','49.145.195.210, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 02:59:05','2026-10-13 02:59:05'),
(103,2,'login_success','login','users',2,NULL,'026c8791-77f6-414d-8240-6385984abb41','49.145.195.210, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 03:01:20','2026-10-13 03:01:20'),
(104,NULL,'login_success','login','users',85,NULL,'468ecb92-b442-442a-8eec-1da0b200141d','49.145.195.210, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 03:34:29','2026-10-13 03:34:29'),
(105,2,'login_success','login','users',2,NULL,'5eda2bf6-82a9-4f28-b95b-c716f6408fb9','49.145.195.210, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 03:35:31','2026-10-13 03:35:31'),
(106,1,'login_success','login','users',1,NULL,'6c98500d-4ddb-4dfc-806f-073022b3cfe7','49.145.195.210, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 03:41:21','2026-10-13 03:41:21'),
(107,1,'login_success','login','users',1,NULL,'e99fde79-3d4e-402c-b6ef-b30ea3fe55db','49.145.193.114, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 03:46:44','2026-10-13 03:46:44'),
(108,2,'login_success','login','users',2,NULL,'fc8e8f87-559c-411d-9cf4-e5da01db134f','49.145.195.210, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 03:52:09','2026-10-13 03:52:09'),
(109,2,'payroll_cancelled','cancel_payroll_run','payroll_run',5,NULL,NULL,NULL,NULL,'{\"previous_status\":\"Draft\",\"reason\":\"practice\"}','2026-10-13 03:54:06','2026-10-13 03:54:06'),
(110,1,'login_success','login','users',1,NULL,'d901b2ff-52a7-48fd-95df-6ee2930f626f','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 04:05:32','2026-10-13 04:05:32'),
(111,2,'login_success','login','users',2,NULL,'187bab93-47bc-430c-bc38-93f58f76f86c','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 04:08:04','2026-10-13 04:08:04'),
(112,2,'login_success','login','users',2,NULL,'368cd0d4-b319-4f3c-8a18-2e94dca063e5','122.3.73.126, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 04:15:33','2026-10-13 04:15:33'),
(113,NULL,'login_success','login','users',85,NULL,'afae6cb9-05a8-4a33-a080-84e3248fcbf0','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 04:22:02','2026-10-13 04:22:02'),
(114,2,'login_success','login','users',2,NULL,'fd33d855-acd7-4ae4-89fa-83f27a716d7e','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 04:25:47','2026-10-13 04:25:47'),
(115,1,'login_success','login','users',1,NULL,'b705ca46-9a97-42a4-b537-7405bcb58f5f','122.3.73.126, 79.127.217.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 04:59:44','2026-10-13 04:59:44'),
(116,1,'login_success','login','users',1,NULL,'be8bbc52-de1a-4e07-a721-5178a49b5e9a','122.3.73.126, 79.127.217.65','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 05:01:00','2026-10-13 05:01:00'),
(117,2,'login_success','login','users',2,NULL,'1fdc63a3-e8b0-4900-8c81-e51f1ee1353b','122.3.73.126, 152.233.76.10','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 05:02:38','2026-10-13 05:02:38'),
(118,1,'login_success','login','users',1,NULL,'bff71a6f-0c3e-465a-a0c6-ee6c7ce9c50f','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 05:06:13','2026-10-13 05:06:13'),
(119,2,'login_success','login','users',2,NULL,'537d4721-7a6c-4f8f-a2ab-435f54078b8a','122.3.73.126, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 05:08:28','2026-10-13 05:08:28'),
(120,2,'login_success','login','users',2,NULL,'25e7d522-0d87-4f1b-b464-6d445c32d44e','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 05:08:57','2026-10-13 05:08:57'),
(121,2,'login_success','login','users',2,NULL,'c87629b4-bf3d-4d31-8e55-9ff879d65461','122.3.73.126, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 05:15:56','2026-10-13 05:15:56'),
(122,2,'login_success','login','users',2,NULL,'ab76f22f-9ea8-4b82-b1dd-08f3197b08ee','122.3.73.126, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 06:43:43','2026-10-13 06:43:43'),
(123,2,'attendance_adjusted','adjust_attendance','attendance',116,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-07-03\",\"reason\":\"0\",\"old\":{\"time_in\":\"06:55:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:00:00\",\"time_out\":\"17:50:00\",\"overtime_minutes\":0}}','2026-10-13 06:54:47','2026-10-13 06:54:47'),
(124,2,'attendance_adjusted','adjust_attendance','attendance',142,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-07-03\",\"reason\":\"0\",\"old\":{\"time_in\":\"06:51:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:51:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":69}}','2026-10-13 06:57:23','2026-10-13 06:57:23'),
(125,1,'login_success','login','users',1,NULL,'33d85a86-0c05-4933-bb09-946035daa98b','165.99.250.110, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 17:51:33','2026-10-13 17:51:33'),
(126,2,'login_success','login','users',2,NULL,'ae5e6b2b-89f9-4c43-b1bc-ab57b91db9ed','165.99.250.110, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 17:52:43','2026-10-13 17:52:43'),
(127,1,'login_success','login','users',1,NULL,'f02d0182-48d7-46f1-844b-855f37171ebc','165.99.250.110, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 17:53:03','2026-10-13 17:53:03'),
(128,1,'login_success','login','users',1,NULL,'d163c252-85e8-45b1-9729-ea6c321be5a3','165.99.250.110, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 19:16:37','2026-10-13 19:16:37'),
(129,NULL,'login_success','login','users',85,NULL,'afd67335-2b52-4542-82b0-0209f5abcafd','165.99.250.110, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 19:16:58','2026-10-13 19:16:58'),
(130,2,'login_success','login','users',2,NULL,'5c937bef-e0ba-43c3-8ad2-678230e56355','165.99.250.110, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 19:18:09','2026-10-13 19:18:09'),
(131,1,'login_success','login','users',1,NULL,'a6eccda8-79e1-437c-b590-ca1615f49045','165.99.250.110, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 19:18:34','2026-10-13 19:18:34'),
(132,2,'login_success','login','users',2,NULL,'f7762a05-5b2f-4141-9455-f35053ece473','165.99.250.110, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 19:39:00','2026-10-13 19:39:00'),
(133,NULL,'login_success','login','users',85,NULL,'a6b249ca-9427-4b60-975d-569e2248e5b0','165.99.250.110, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 20:48:59','2026-10-13 20:48:59'),
(134,NULL,'login_success','login','users',85,NULL,'18c3a152-cb01-472e-9a82-7102cd56b27a','165.99.250.110, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 21:25:29','2026-10-13 21:25:29'),
(135,2,'login_success','login','users',2,NULL,'5723bf67-2e0a-4c8d-a6aa-87505516fda0','165.99.250.110, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-13 22:32:32','2026-10-13 22:32:32'),
(136,1,'login_success','login','users',1,NULL,'cb474f11-652f-4db4-b3d7-dc884d0f584e','49.145.203.52, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-14 02:54:40','2026-10-14 02:54:40'),
(137,2,'login_success','login','users',2,NULL,'6ddbd795-84a4-4906-bf9e-0cb070abcf56','49.149.30.38, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-14 10:05:17','2026-10-14 10:05:17'),
(138,2,'login_success','login','users',2,NULL,'2a579eac-86a8-40c4-b06e-5e660a6d7ae1','165.99.250.110, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-15 00:55:55','2026-10-15 00:55:55'),
(139,2,'login_success','login','users',2,NULL,'4114cce6-c779-4818-a2a3-a2a806c88f0d','165.99.250.110, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-15 02:06:39','2026-10-15 02:06:39'),
(140,2,'login_success','login','users',2,NULL,'b2767fac-058b-4ce4-8995-6788974673b4','49.149.30.38, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-15 02:33:52','2026-10-15 02:33:52'),
(141,2,'login_success','login','users',2,NULL,'ee5c8c37-2229-4254-b872-71dfdec15b5a','49.149.30.38, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-15 03:08:36','2026-10-15 03:08:36'),
(142,NULL,'login_success','login','users',3,NULL,'f6655430-92b1-411c-aa36-cb1f03de3395','49.149.30.38, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-15 03:10:43','2026-10-15 03:10:43'),
(143,2,'login_success','login','users',2,NULL,'7358a1ac-bde0-483d-9627-efba0f368fc1','49.149.30.38, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-15 03:12:06','2026-10-15 03:12:06'),
(144,2,'login_success','login','users',2,NULL,'4fe811d1-eb5b-40a6-8c28-d8aeb5b4c61a','165.99.250.110, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-15 03:39:08','2026-10-15 03:39:08'),
(145,2,'login_success','login','users',2,NULL,'e44f88f4-b6b4-4252-9154-b7f98656b166','49.149.30.38, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-15 06:25:56','2026-10-15 06:25:56'),
(146,2,'login_success','login','users',2,NULL,'45d42fc6-ef46-4000-a1c2-e24f1f38c7b7','49.149.30.38, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-15 13:53:55','2026-10-15 13:53:55'),
(147,2,'login_success','login','users',2,NULL,'99de8778-7f5b-40cd-9aab-c19d28fadb29','49.149.26.158, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-15 13:57:08','2026-10-15 13:57:08'),
(148,2,'upload_document','upload_document','employee_document',1,NULL,NULL,NULL,NULL,'{\"employee_id\":86,\"document_id\":1,\"description\":\"Uploaded: Employment_Contract.pdf\"}','2026-10-15 14:02:03','2026-10-15 14:02:03'),
(149,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','dde4fde0-2876-4ebb-a914-110d71ecb350','49.149.125.21, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-15 14:36:47','2026-10-15 14:36:47'),
(150,2,'login_success','login','users',2,NULL,'b9944a0a-f46d-4e87-8dca-76d64cbf8509','49.149.125.21, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-15 14:37:03','2026-10-15 14:37:03'),
(151,2,'login_success','login','users',2,NULL,'3e514673-4ed6-4d0b-9c08-1d809619c905','49.149.30.38, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-15 15:19:59','2026-10-15 15:19:59'),
(152,2,'login_success','login','users',2,NULL,'debe008e-21ed-4af1-b274-2517c0634bb8','49.149.30.38, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-15 17:06:00','2026-10-15 17:06:00'),
(153,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','82dbac8a-0485-47c5-a2b0-b67c3e8ed5a4','165.99.250.110, 152.233.68.97','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/155.0.8059.43 Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]','Login failed: invalid credentials or inactive account.','2026-10-16 05:47:18','2026-10-16 05:47:18'),
(154,2,'login_success','login','users',2,NULL,'0b0284f5-28d2-412b-aa17-3e6356f6acd9','165.99.250.110, 152.233.68.97','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/155.0.8059.43 Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]','User logged in successfully.','2026-10-16 05:47:56','2026-10-16 05:47:56'),
(155,2,'login_success','login','users',2,NULL,'8aef82dc-4a90-47cb-9310-421954e73082','165.99.250.110, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 05:59:53','2026-10-16 05:59:53'),
(156,2,'login_success','login','users',2,NULL,'9af094d1-bb85-46d8-be87-1711e5e379f5','165.99.250.110, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 07:10:13','2026-10-16 07:10:13'),
(157,2,'login_success','login','users',2,NULL,'9fbfb8cd-c928-4223-9d14-7a2d892885d5','165.99.250.110, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 08:17:13','2026-10-16 08:17:13'),
(158,NULL,'login_failure','login_attempt',NULL,NULL,'jianearielleee@gmail.com','95070776-47a5-4f9a-82c5-a9f83fb8c611','49.149.30.38, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-16 08:31:08','2026-10-16 08:31:08'),
(159,NULL,'login_success','login','users',94,NULL,'60f1d491-db3f-4a28-ae4d-233bb0427485','49.149.30.38, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 08:31:18','2026-10-16 08:31:18'),
(160,2,'login_success','login','users',2,NULL,'b911dcb8-9e40-47c1-bd51-3e168d4f4e48','49.149.30.38, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 08:31:48','2026-10-16 08:31:48'),
(161,2,'login_success','login','users',2,NULL,'54973ca1-c23e-45c6-a426-f6487256a9f8','165.99.250.110, 152.233.33.161','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 08:58:18','2026-10-16 08:58:18'),
(162,2,'login_success','login','users',2,NULL,'4c9bfcee-c097-4e8f-a0f1-dad4dbdcafbd','165.99.250.110, 152.233.33.165','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 08:58:32','2026-10-16 08:58:32'),
(163,NULL,'login_failure','login_attempt',NULL,NULL,'hr@demo.test','63d92d92-d82f-4cf5-8ca0-a2af1ce1c228','49.146.52.236, 152.233.33.163','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-16 08:59:36','2026-10-16 08:59:36'),
(164,2,'login_success','login','users',2,NULL,'3ef3a240-4252-406c-b8cf-5cad2c7309cd','49.146.52.236, 152.233.33.161','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 08:59:46','2026-10-16 08:59:46'),
(165,2,'user_updated','user_updated','users',95,NULL,NULL,NULL,NULL,'Updated user_id=95: username=\'dave.dalipe\', role_id=3, status=\'Active\'','2026-10-16 09:00:42','2026-10-16 09:00:42'),
(166,NULL,'login_failure','login_attempt',NULL,NULL,'xxroshanxx24@gmail.conm','16e8c99b-2356-4261-873a-818c87326f6f','49.146.52.236, 152.233.33.162','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-16 09:00:52','2026-10-16 09:00:52'),
(167,NULL,'login_failure','login_attempt',NULL,NULL,'almairahmaindan18@gmail.com','7ff2fa0c-bb41-4254-b423-7bae586223e0','165.99.250.110, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-16 13:14:59','2026-10-16 13:14:59'),
(168,2,'login_success','login','users',2,NULL,'710f4f90-336b-40c4-a3b7-13d061f9cc03','165.99.250.110, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 13:16:16','2026-10-16 13:16:16'),
(169,2,'user_provisioned','user_provisioned','users',96,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'joa.villegas\' for employee_id=91','2026-10-16 13:20:27','2026-10-16 13:20:27'),
(170,NULL,'login_success','login','users',96,NULL,'25371bf9-4524-4c17-bc1a-6bb6a8f4725d','165.99.250.110, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 13:21:02','2026-10-16 13:21:02'),
(171,NULL,'login_failure','login_attempt',NULL,NULL,'almairahmaindan18@gmail.com','7137687f-8e22-43b7-a1a2-4da0d24bcb2a','165.99.250.110, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-16 13:21:32','2026-10-16 13:21:32'),
(172,2,'login_success','login','users',2,NULL,'51193607-05f5-4d53-84a6-1d5debcd3d4d','165.99.250.110, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 13:28:51','2026-10-16 13:28:51'),
(173,2,'login_success','login','users',2,NULL,'8348fd22-9319-4dd6-aef0-fd507ac49e3d','165.99.250.110, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 13:28:56','2026-10-16 13:28:56'),
(174,1,'login_success','login','users',1,NULL,'b13d46f4-b337-49f3-b756-bf6e0c648e42','165.99.250.110, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 13:29:17','2026-10-16 13:29:17'),
(175,2,'login_success','login','users',2,NULL,'dc5ede4b-be91-44c1-93c0-a280f35b9d8c','49.149.26.158, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 17:49:45','2026-10-16 17:49:45'),
(176,2,'login_success','login','users',2,NULL,'4b5511cf-f1c1-47a6-b1dd-3dfcb2381fa9','49.149.26.158, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-16 17:54:09','2026-10-16 17:54:09'),
(177,2,'login_success','login','users',2,NULL,'e2ec39e5-a29c-49fb-b81c-013b8aa6621b','110.54.206.188, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 01:31:27','2026-10-17 01:31:27'),
(178,2,'login_success','login','users',2,NULL,'9abec3f8-69a3-41e5-97ca-c5516f3e3723','49.146.52.236, 152.233.15.120','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 01:33:39','2026-10-17 01:33:39'),
(179,1,'login_success','login','users',1,NULL,'485d4d57-70d1-4d27-a7bb-b19198063d32','49.146.52.236, 152.233.15.120','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 01:47:33','2026-10-17 01:47:33'),
(180,2,'login_success','login','users',2,NULL,'70b978a0-af26-44d4-aa5a-048a34fe8fd5','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 01:55:46','2026-10-17 01:55:46'),
(181,1,'login_success','login','users',1,NULL,'b752cd6b-22df-49e4-94a2-1a022d7c91d7','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 01:57:25','2026-10-17 01:57:25'),
(182,1,'user_updated','user_updated','users',96,NULL,NULL,NULL,NULL,'Updated user_id=96: username=\'joa.villegas\', role_id=3, status=\'Active\'','2026-10-17 01:59:04','2026-10-17 01:59:04'),
(183,2,'login_success','login','users',2,NULL,'db35b35f-f50a-4e43-8725-f3cd4f2cf735','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 02:05:39','2026-10-17 02:05:39'),
(184,2,'user_provisioned','user_provisioned','users',97,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'arben.ramirez\' for employee_id=92','2026-10-17 02:07:27','2026-10-17 02:07:27'),
(185,1,'login_success','login','users',1,NULL,'ee48e0d2-b12e-4403-b888-de65d33e8b05','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 02:08:01','2026-10-17 02:08:01'),
(186,1,'user_updated','user_updated','users',97,NULL,NULL,NULL,NULL,'Updated user_id=97: username=\'arben.ramirez\', role_id=2, status=\'Active\'','2026-10-17 02:10:30','2026-10-17 02:10:30'),
(187,1,'user_updated','user_updated','users',97,NULL,NULL,NULL,NULL,'Updated user_id=97: username=\'arben.ramirez\', role_id=2, status=\'Active\'','2026-10-17 02:10:44','2026-10-17 02:10:44'),
(188,NULL,'login_success','login','users',97,NULL,'4b7c896b-98ab-4264-91be-8cd05ff09830','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 02:11:36','2026-10-17 02:11:36'),
(189,1,'login_success','login','users',1,NULL,'424e2db1-afe1-4201-9529-ce2cc6b5950b','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 02:12:06','2026-10-17 02:12:06'),
(190,1,'user_updated','user_updated','users',97,NULL,NULL,NULL,NULL,'Updated user_id=97: username=\'arben.ramirez\', role_id=3, status=\'Active\'','2026-10-17 02:12:18','2026-10-17 02:12:18'),
(191,NULL,'login_success','login','users',97,NULL,'43288b37-1992-4d86-80bb-fd5a99d4b2a6','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 02:12:39','2026-10-17 02:12:39'),
(192,1,'login_success','login','users',1,NULL,'0bc6425c-d5e9-493b-9f25-215c3ce13b9d','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 02:12:57','2026-10-17 02:12:57'),
(193,1,'user_status_changed','user_status_changed','users',97,NULL,NULL,NULL,NULL,'Status changed to \'Inactive\' for user_id=97','2026-10-17 02:13:06','2026-10-17 02:13:06'),
(194,NULL,'login_failure','login_attempt',NULL,NULL,'ramirez@lightdiamond.com','b4706844-8594-4177-93b5-7f1bc2392085','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-17 02:13:18','2026-10-17 02:13:18'),
(195,1,'login_success','login','users',1,NULL,'4e560112-35b0-4bba-b2bb-e1419ebbc158','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 02:13:34','2026-10-17 02:13:34'),
(196,1,'user_archived','user_archived','users',97,NULL,NULL,NULL,NULL,'Archived user_id=97','2026-10-17 02:13:42','2026-10-17 02:13:42'),
(197,2,'login_success','login','users',2,NULL,'360d7e61-b9ec-4bbe-80e4-b1cebe12d9f8','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 02:14:24','2026-10-17 02:14:24'),
(198,1,'login_success','login','users',1,NULL,'deb8b0a7-f070-4109-9aa2-f7e5765f2275','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 02:28:02','2026-10-17 02:28:02'),
(199,2,'login_success','login','users',2,NULL,'76fb19ee-74b9-45ff-955e-ed989378d530','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 02:28:35','2026-10-17 02:28:35'),
(200,2,'upload_document','upload_document','employee_document',2,NULL,NULL,NULL,NULL,'{\"employee_id\":84,\"document_id\":2,\"description\":\"Uploaded: BIKE 3.jpg\"}','2026-10-17 02:34:06','2026-10-17 02:34:06'),
(201,2,'attendance_adjusted','adjust_attendance','attendance',423,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-08-28\",\"reason\":\"dgnsfdgsd\",\"old\":{\"time_in\":\"07:01:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:01:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":59}}','2026-10-17 02:44:11','2026-10-17 02:44:11'),
(202,2,'attendance_adjusted','adjust_attendance','attendance',469,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-08-28\",\"reason\":\"0\",\"old\":{\"time_in\":\"06:57:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:57:00\",\"time_out\":\"17:51:00\",\"overtime_minutes\":114}}','2026-10-17 02:45:39','2026-10-17 02:45:39'),
(203,2,'attendance_policy_flag_reviewed','review_attendance_policy_flag','attendance_policy_flag',5,NULL,NULL,NULL,NULL,'Flag 5 reviewed as Reviewed. Action taken: Cleaning the toilet.','2026-10-17 02:49:55','2026-10-17 02:49:55'),
(204,2,'employee_hr_notice_issued','issue_employee_hr_notice','employee_hr_notice',1,NULL,NULL,NULL,NULL,'Employee notice 1 issued from policy flag 5.','2026-10-17 02:49:55','2026-10-17 02:49:55'),
(205,2,'attendance_policy_flag_reviewed','review_attendance_policy_flag','attendance_policy_flag',6,NULL,NULL,NULL,NULL,'Flag 6 reviewed as Reviewed. Action taken: sample.','2026-10-17 02:50:50','2026-10-17 02:50:50'),
(206,2,'attendance_policy_flag_reviewed','review_attendance_policy_flag','attendance_policy_flag',6,NULL,NULL,NULL,NULL,'Flag 6 reviewed as Closed. Action taken: sample.','2026-10-17 02:51:14','2026-10-17 02:51:14'),
(207,2,'attendance_policy_flag_reviewed','review_attendance_policy_flag','attendance_policy_flag',6,NULL,NULL,NULL,NULL,'Flag 6 reviewed as Closed. Action taken: sample.','2026-10-17 02:51:46','2026-10-17 02:51:46'),
(208,1,'login_success','login','users',1,NULL,'e943ecb0-fbc1-434c-9429-0e937eee1c62','110.54.206.188, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 03:28:48','2026-10-17 03:28:48'),
(209,2,'login_success','login','users',2,NULL,'85d84894-40df-4405-b135-29f079da8b8a','110.54.206.188, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 03:30:07','2026-10-17 03:30:07'),
(210,1,'login_success','login','users',1,NULL,'fc6dc172-eaf0-4c27-bddf-102e2e01b234','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 03:31:16','2026-10-17 03:31:16'),
(211,2,'login_success','login','users',2,NULL,'ffba6238-95a7-4d02-8a04-bb6d4d08fc93','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 03:32:20','2026-10-17 03:32:20'),
(212,1,'login_success','login','users',1,NULL,'03f4501a-e7ed-488d-bef1-28899f8c11fb','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 03:34:26','2026-10-17 03:34:26'),
(213,2,'login_success','login','users',2,NULL,'1c288b88-2a3a-4952-943e-707ee7845b87','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 03:35:14','2026-10-17 03:35:14'),
(214,1,'login_success','login','users',1,NULL,'16fae8f8-89a3-440e-82a0-631c9abdd20a','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 03:35:44','2026-10-17 03:35:44'),
(215,2,'login_success','login','users',2,NULL,'0d51166a-2f2b-46df-becc-bcb8fe59cdbf','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 03:36:32','2026-10-17 03:36:32'),
(216,2,'payroll_cancelled','cancel_payroll_run','payroll_run',6,NULL,NULL,NULL,NULL,'{\"previous_status\":\"Draft\",\"reason\":\"fdfbsdv\"}','2026-10-17 03:38:24','2026-10-17 03:38:24'),
(217,2,'payroll_cancelled','cancel_payroll_run','payroll_run',7,NULL,NULL,NULL,NULL,'{\"previous_status\":\"Draft\",\"reason\":\"rgg\"}','2026-10-17 03:39:34','2026-10-17 03:39:34'),
(218,1,'login_success','login','users',1,NULL,'b7eea8b4-ea70-4a2f-9eba-ac0e31932115','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 03:40:04','2026-10-17 03:40:04'),
(219,2,'login_success','login','users',2,NULL,'8318042b-35fa-417f-a478-85e19fb5fe5f','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 03:40:31','2026-10-17 03:40:31'),
(220,2,'salary_created','salary_created','salary',101,NULL,NULL,NULL,NULL,'Created salary_id=101 for employee_id=84 at rate=500 from 2026-10-16','2026-10-17 03:41:48','2026-10-17 03:41:48'),
(221,2,'salary_archived','salary_archived','salary',101,NULL,NULL,NULL,NULL,'Archived salary_id=101','2026-10-17 03:43:56','2026-10-17 03:43:56'),
(222,NULL,'login_success','login','users',85,NULL,'791cee4c-c20c-40fc-9155-ed9b0df85ef5','110.54.206.188, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 03:50:13','2026-10-17 03:50:13'),
(223,2,'login_success','login','users',2,NULL,'72bc2d2d-e6cf-44c7-a5b7-bde4d8e7339e','49.149.125.21, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-17 05:49:30','2026-10-17 05:49:30'),
(224,NULL,'login_success','login','users',85,NULL,'b20cd237-1578-44e7-a92e-3e85e858586a','180.191.139.34, 152.233.33.165','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 01:48:04','2026-10-18 01:48:04'),
(225,2,'login_success','login','users',2,NULL,'71a6b71a-8195-4ccc-beff-183b3bdf0f50','180.191.139.34, 152.233.33.164','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 02:06:00','2026-10-18 02:06:00'),
(226,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','67436425-64d6-4ede-b692-fdbf598739f3','180.191.139.34, 152.233.33.161','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-18 02:11:06','2026-10-18 02:11:06'),
(227,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','1797ae39-0d7f-4852-ab82-1934705cb024','180.191.139.34, 152.233.33.164','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-18 02:11:23','2026-10-18 02:11:23'),
(228,2,'login_success','login','users',2,NULL,'de4229c8-6687-4551-8bdb-fcb31564bf91','180.191.139.34, 152.233.15.121','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','User logged in successfully.','2026-10-18 12:09:50','2026-10-18 12:09:50'),
(229,2,'login_success','login','users',2,NULL,'630bf6ed-42c0-4698-8e47-31260c4a86b1','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 13:29:19','2026-10-18 13:29:19'),
(230,1,'login_success','login','users',1,NULL,'91927da4-f61f-4641-9a0d-15e4cb5a0b57','49.149.26.158, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 13:47:27','2026-10-18 13:47:27'),
(231,1,'user_archived','user_archived','users',89,NULL,NULL,NULL,NULL,'Archived user_id=89','2026-10-18 13:47:41','2026-10-18 13:47:41'),
(232,2,'login_success','login','users',2,NULL,'1720c209-fa06-41fa-9d95-2f67597540ff','49.149.26.158, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 13:48:08','2026-10-18 13:48:08'),
(233,2,'login_success','login','users',2,NULL,'78cc2775-69a9-4fad-8b98-d1e9f321a56e','49.149.125.21, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 13:52:57','2026-10-18 13:52:57'),
(234,1,'login_success','login','users',1,NULL,'3f4d880c-21c1-4362-b4d0-9993727dfd2c','49.149.125.21, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 13:54:19','2026-10-18 13:54:19'),
(235,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','c87f3fb2-5bee-4d27-90cf-f560f09348a5','49.149.125.21, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-18 13:54:57','2026-10-18 13:54:57'),
(236,2,'login_success','login','users',2,NULL,'8501d68a-c6c5-4e6e-99b0-0749bf3db2f9','49.149.125.21, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 13:55:04','2026-10-18 13:55:04'),
(237,2,'attendance_policy_flag_reviewed','review_attendance_policy_flag','attendance_policy_flag',5,NULL,NULL,NULL,NULL,'Flag 5 reviewed as Reviewed. Action taken: Cleaning the toilet.','2026-10-18 13:58:02','2026-10-18 13:58:02'),
(238,2,'attendance_policy_flag_reviewed','review_attendance_policy_flag','attendance_policy_flag',2,NULL,NULL,NULL,NULL,'Flag 2 reviewed as Reviewed. Action taken: warning letter.','2026-10-18 13:58:19','2026-10-18 13:58:19'),
(239,2,'employee_hr_notice_issued','issue_employee_hr_notice','employee_hr_notice',2,NULL,NULL,NULL,NULL,'Employee notice 2 issued from policy flag 2.','2026-10-18 13:58:19','2026-10-18 13:58:19'),
(240,2,'login_success','login','users',2,NULL,'deba0f1d-4488-43aa-83c6-f0ad3a54a3b3','165.99.250.116, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 14:01:42','2026-10-18 14:01:42'),
(241,2,'attendance_policy_flag_reviewed','review_attendance_policy_flag','attendance_policy_flag',4,NULL,NULL,NULL,NULL,'Flag 4 reviewed as Reviewed. Action taken: Create incident report.','2026-10-18 14:03:20','2026-10-18 14:03:20'),
(242,2,'employee_hr_notice_issued','issue_employee_hr_notice','employee_hr_notice',3,NULL,NULL,NULL,NULL,'Employee notice 3 issued from policy flag 4.','2026-10-18 14:03:20','2026-10-18 14:03:20'),
(243,2,'attendance_policy_flag_reviewed','review_attendance_policy_flag','attendance_policy_flag',3,NULL,NULL,NULL,NULL,'Flag 3 reviewed as Reviewed. Action taken: sample.','2026-10-18 14:03:58','2026-10-18 14:03:58'),
(244,2,'employee_hr_notice_issued','issue_employee_hr_notice','employee_hr_notice',4,NULL,NULL,NULL,NULL,'Employee notice 4 issued from policy flag 3.','2026-10-18 14:03:58','2026-10-18 14:03:58'),
(245,2,'attendance_policy_flag_reviewed','review_attendance_policy_flag','attendance_policy_flag',1,NULL,NULL,NULL,NULL,'Flag 1 reviewed as Reviewed. Action taken: sample action.','2026-10-18 14:04:48','2026-10-18 14:04:48'),
(246,2,'employee_hr_notice_issued','issue_employee_hr_notice','employee_hr_notice',5,NULL,NULL,NULL,NULL,'Employee notice 5 issued from policy flag 1.','2026-10-18 14:04:48','2026-10-18 14:04:48'),
(247,2,'attendance_policy_flag_reviewed','review_attendance_policy_flag','attendance_policy_flag',1,NULL,NULL,NULL,NULL,'Flag 1 reviewed as Reviewed. Action taken: sample action.','2026-10-18 14:05:00','2026-10-18 14:05:00'),
(248,2,'attendance_policy_flag_reviewed','review_attendance_policy_flag','attendance_policy_flag',6,NULL,NULL,NULL,NULL,'Flag 6 reviewed as Closed. Action taken: sample.','2026-10-18 14:06:45','2026-10-18 14:06:45'),
(249,2,'employee_hr_notice_issued','issue_employee_hr_notice','employee_hr_notice',6,NULL,NULL,NULL,NULL,'Employee notice 6 issued from policy flag 6.','2026-10-18 14:06:45','2026-10-18 14:06:45'),
(250,2,'payroll_cancelled','cancel_payroll_run','payroll_run',8,NULL,NULL,NULL,NULL,'{\"previous_status\":\"Computed\",\"reason\":\"Error\"}','2026-10-18 14:31:19','2026-10-18 14:31:19'),
(251,2,'salary_updated','salary_updated','salary',102,NULL,NULL,NULL,NULL,'Updated from salary_id=100 to new salary_id=102, rate=600.00 from 2026-10-19','2026-10-18 14:45:10','2026-10-18 14:45:10'),
(252,2,'salary_updated','salary_updated','salary',103,NULL,NULL,NULL,NULL,'Updated from salary_id=102 to new salary_id=103, rate=700.00 from 2026-11-02','2026-10-18 14:46:22','2026-10-18 14:46:22'),
(253,NULL,'login_failure','login_attempt',NULL,NULL,'golbinalden@gmail.com','eaef196e-1640-4639-8549-44a2366acb98','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-18 14:49:45','2026-10-18 14:49:45'),
(254,NULL,'login_failure','login_attempt',NULL,NULL,'golbinalden@gmail.com','3689cdbb-7eed-4f03-a246-ad1a707ed573','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-18 14:49:52','2026-10-18 14:49:52'),
(255,NULL,'login_failure','login_attempt',NULL,NULL,'golbinalden@gmail.com','a692efa8-fca5-4be9-8463-4fc92235fc9a','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-18 14:50:02','2026-10-18 14:50:02'),
(256,2,'login_success','login','users',2,NULL,'9e602932-0804-4b2a-a56d-196a79edd6be','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 14:50:13','2026-10-18 14:50:13'),
(257,2,'password_reset','password_reset','users',95,NULL,NULL,NULL,NULL,'Password reset by HRHead (user_id=2) for user \'dave.dalipe\'','2026-10-18 14:50:33','2026-10-18 14:50:33'),
(258,NULL,'login_failure','login_attempt',NULL,NULL,'xxroshanxx24@gmail.com','8f57232c-fd71-42b7-8cbc-a054ac17ce83','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-18 14:51:03','2026-10-18 14:51:03'),
(259,NULL,'login_failure','login_attempt',NULL,NULL,'xxroshanxx24@gmail.com','5684d865-ea59-4da0-8d6c-e5e49d530deb','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-18 14:51:14','2026-10-18 14:51:14'),
(260,2,'login_success','login','users',2,NULL,'fa028249-81cd-4a22-9216-ec88cb5664f1','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 14:53:44','2026-10-18 14:53:44'),
(261,2,'password_reset','password_reset','users',94,NULL,NULL,NULL,NULL,'Password reset by HRHead (user_id=2) for user \'lovely.paguntalan\'','2026-10-18 14:53:57','2026-10-18 14:53:57'),
(262,NULL,'login_success','login','users',94,NULL,'a2b0ca57-6e0e-44ea-8118-195c560d947d','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 14:54:15','2026-10-18 14:54:15'),
(263,NULL,'employee_hr_notice_acknowledged','acknowledge_employee_hr_notice','employee_hr_notice',6,NULL,NULL,NULL,NULL,'Employee acknowledged HR notice 6.','2026-10-18 14:56:14','2026-10-18 14:56:14'),
(264,NULL,'employee_hr_notice_acknowledged','acknowledge_employee_hr_notice','employee_hr_notice',4,NULL,NULL,NULL,NULL,'Employee acknowledged HR notice 4.','2026-10-18 14:56:19','2026-10-18 14:56:19'),
(265,NULL,'employee_hr_notice_acknowledged','acknowledge_employee_hr_notice','employee_hr_notice',3,NULL,NULL,NULL,NULL,'Employee acknowledged HR notice 3.','2026-10-18 14:56:24','2026-10-18 14:56:24'),
(266,2,'login_success','login','users',2,NULL,'830b2edc-8fbb-4c22-9f9a-423229641347','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 14:56:37','2026-10-18 14:56:37'),
(267,NULL,'login_success','login','users',94,NULL,'1a91ad4f-0251-4f6d-8987-a93e4dcbca40','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 14:57:14','2026-10-18 14:57:14'),
(268,2,'login_success','login','users',2,NULL,'b7a7016a-85d6-439e-85d7-3c0d04e072b0','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-18 14:58:44','2026-10-18 14:58:44'),
(269,2,'attendance_policy_flag_reviewed','review_attendance_policy_flag','attendance_policy_flag',5,NULL,NULL,NULL,NULL,'Flag 5 reviewed as Reviewed. Action taken: Cleaning the toilet.','2026-10-18 15:05:10','2026-10-18 15:05:10'),
(270,2,'login_success','login','users',2,NULL,'de9ec401-03ae-44fb-8994-f034fd51ba45','49.145.195.33, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-19 00:10:28','2026-10-19 00:10:28'),
(271,NULL,'login_success','login','users',85,NULL,'61f60cb6-555f-4425-857d-334289fc6e85','49.145.195.33, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-19 00:40:49','2026-10-19 00:40:49'),
(272,2,'login_success','login','users',2,NULL,'0291403b-b52a-4adf-b02d-2935631915f7','49.145.195.33, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-19 00:44:02','2026-10-19 00:44:02'),
(273,NULL,'login_success','login','users',85,NULL,'409a61b8-874e-4d27-b11c-4096745ac9a3','49.145.198.187, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-19 01:01:32','2026-10-19 01:01:32'),
(274,2,'login_success','login','users',2,NULL,'562ea437-f9a8-453f-88da-a5a055751a18','49.145.198.187, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','User logged in successfully.','2026-10-19 01:03:25','2026-10-19 01:03:25'),
(275,2,'login_success','login','users',2,NULL,'4234fa56-594f-4760-96b4-542433c1e55e','180.190.45.226, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-19 02:47:22','2026-10-19 02:47:22'),
(276,2,'login_success','login','users',2,NULL,'f4512985-298f-4cd8-ac85-17a15124be64','49.149.26.158, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 14:03:59','2026-10-20 14:03:59'),
(277,2,'attendance_policy_flag_reviewed','review_attendance_policy_flag','attendance_policy_flag',5,NULL,NULL,NULL,NULL,'Flag 5 reviewed as Reviewed. Action taken: Cleaning the toilet.','2026-10-20 14:18:56','2026-10-20 14:18:56'),
(278,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','f94ff583-9ee3-438a-bef4-68fafea8b348','49.149.26.158, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-20 14:20:41','2026-10-20 14:20:41'),
(279,2,'login_success','login','users',2,NULL,'9a073a25-30b8-4d1d-85be-2688a863168b','49.149.26.158, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 14:20:48','2026-10-20 14:20:48'),
(280,2,'password_reset','password_reset','users',96,NULL,NULL,NULL,NULL,'Password reset by HRHead (user_id=2) for user \'joa.villegas\'','2026-10-20 14:21:49','2026-10-20 14:21:49'),
(281,2,'login_success','login','users',2,NULL,'2533ccf7-492d-40ab-b32e-dac20ae5190b','49.149.196.70, 152.233.68.98','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','User logged in successfully.','2026-10-20 14:49:42','2026-10-20 14:49:42'),
(282,2,'login_success','login','users',2,NULL,'c365c8fb-b9aa-425d-b1d0-1675225bba4a','49.149.196.70, 152.233.68.98','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','User logged in successfully.','2026-10-20 14:49:43','2026-10-20 14:49:43'),
(283,2,'login_success','login','users',2,NULL,'94d299d3-6807-4066-a0ef-fa93b96f5a45','49.149.26.158, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 16:35:34','2026-10-20 16:35:34'),
(284,2,'login_success','login','users',2,NULL,'54b91461-26bb-43c5-9bae-af14f42bfb17','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 20:31:16','2026-10-20 20:31:16'),
(285,2,'user_provisioned','user_provisioned','users',98,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'manny.linsaw\' for employee_id=93','2026-10-20 20:36:41','2026-10-20 20:36:41'),
(286,1,'login_success','login','users',1,NULL,'13a80241-c0b7-4e03-93f6-6c401d22db6e','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 20:38:15','2026-10-20 20:38:15'),
(287,1,'user_updated','user_updated','users',93,NULL,NULL,NULL,NULL,'Updated user_id=93: username=\'isabela.tayong\', role_id=2, status=\'Active\'','2026-10-20 20:39:04','2026-10-20 20:39:04'),
(288,NULL,'login_failure','login_attempt',NULL,NULL,'tayong@lightdiamond.com','f0f66588-37b8-4b8d-9684-4f6f0ca22314','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-20 20:39:35','2026-10-20 20:39:35'),
(289,2,'login_success','login','users',2,NULL,'4ddf9483-60f7-4259-a40c-f654182a6435','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 20:39:48','2026-10-20 20:39:48'),
(290,1,'login_success','login','users',1,NULL,'a56913d9-ea00-4903-bd39-b2c91f3e8fc0','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 20:40:02','2026-10-20 20:40:02'),
(291,1,'user_updated','user_updated','users',93,NULL,NULL,NULL,NULL,'Updated user_id=93: username=\'isabela.tayong\', role_id=3, status=\'Active\'','2026-10-20 20:40:15','2026-10-20 20:40:15'),
(292,1,'user_updated','user_updated','users',88,NULL,NULL,NULL,NULL,'Updated user_id=88: username=\'linda.lebuna\', role_id=2, status=\'Active\'','2026-10-20 20:40:46','2026-10-20 20:40:46'),
(293,NULL,'login_failure','login_attempt',NULL,NULL,'lebuna@lightdiamond.com','59904c9b-0221-413f-8e68-adb1fa5e5f1c','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-20 20:41:08','2026-10-20 20:41:08'),
(294,1,'login_success','login','users',1,NULL,'9e1a5d6e-a845-4877-935a-117f73720e6c','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 20:41:20','2026-10-20 20:41:20'),
(295,1,'user_updated','user_updated','users',88,NULL,NULL,NULL,NULL,'Updated user_id=88: username=\'linda.lebuna\', role_id=3, status=\'Active\'','2026-10-20 20:42:49','2026-10-20 20:42:49'),
(296,1,'user_updated','user_updated','users',88,NULL,NULL,NULL,NULL,'Updated user_id=88: username=\'linda.lebuna\', role_id=2, status=\'Active\'','2026-10-20 20:43:24','2026-10-20 20:43:24'),
(297,NULL,'login_failure','login_attempt',NULL,NULL,'linda@lightdiamond.cpm','c3553088-718d-4805-a5ef-80bca2dcd7b7','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-20 20:43:51','2026-10-20 20:43:51'),
(298,1,'login_success','login','users',1,NULL,'0b3ad929-7d30-41ee-9473-b10bba919505','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 20:44:01','2026-10-20 20:44:01'),
(299,1,'password_reset','password_reset','users',88,NULL,NULL,NULL,NULL,'Password reset by BusinessOwner (user_id=1) for user \'linda.lebuna\'','2026-10-20 20:44:18','2026-10-20 20:44:18'),
(300,NULL,'login_failure','login_attempt',NULL,NULL,'linda@lightdiamond.cpm','ff093983-8f3e-4126-9b54-b9845f280e66','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-20 20:45:01','2026-10-20 20:45:01'),
(301,NULL,'login_failure','login_attempt',NULL,NULL,'linda@lightdiamond.cpm','7e35a9db-5d71-4294-ba5b-ace561a9fb05','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-20 20:45:20','2026-10-20 20:45:20'),
(302,1,'login_success','login','users',1,NULL,'9c4de583-1863-4a74-ae16-a5a2234618d5','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 20:45:35','2026-10-20 20:45:35'),
(303,1,'user_updated','user_updated','users',88,NULL,NULL,NULL,NULL,'Updated user_id=88: username=\'linda.lebuna\', role_id=3, status=\'Active\'','2026-10-20 20:46:04','2026-10-20 20:46:04'),
(304,NULL,'login_success','login','users',85,NULL,'7c03afa1-a7c3-4258-a32d-e69aaf06125c','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 20:46:15','2026-10-20 20:46:15'),
(305,1,'login_success','login','users',1,NULL,'dac8622e-c280-4f93-a29d-562649ec8d81','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 20:46:25','2026-10-20 20:46:25'),
(306,1,'user_updated','user_updated','users',85,NULL,NULL,NULL,NULL,'Updated user_id=85: username=\'ronan.delacruz\', role_id=2, status=\'Active\'','2026-10-20 20:46:42','2026-10-20 20:46:42'),
(307,NULL,'login_success','login','users',85,NULL,'9b569163-1307-4ef7-bcad-9e038a5fd635','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 20:46:55','2026-10-20 20:46:55'),
(308,1,'login_success','login','users',1,NULL,'52969bd6-1067-42af-a738-0f6f9c47b3c8','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 20:55:41','2026-10-20 20:55:41'),
(309,1,'user_updated','user_updated','users',85,NULL,NULL,NULL,NULL,'Updated user_id=85: username=\'ronan.delacruz\', role_id=3, status=\'Active\'','2026-10-20 20:55:57','2026-10-20 20:55:57'),
(310,1,'user_status_changed','user_status_changed','users',96,NULL,NULL,NULL,NULL,'Status changed to \'Inactive\' for user_id=96','2026-10-20 20:56:34','2026-10-20 20:56:34'),
(311,1,'user_status_changed','user_status_changed','users',96,NULL,NULL,NULL,NULL,'Status changed to \'Active\' for user_id=96','2026-10-20 20:56:51','2026-10-20 20:56:51'),
(312,1,'user_archived','user_archived','users',96,NULL,NULL,NULL,NULL,'Archived user_id=96','2026-10-20 20:57:00','2026-10-20 20:57:00'),
(313,2,'login_success','login','users',2,NULL,'cbccb249-953f-461c-95f0-9963bb0b70ba','165.99.250.110, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 20:57:16','2026-10-20 20:57:16'),
(314,2,'upload_document','upload_document','employee_document',3,NULL,NULL,NULL,NULL,'{\"employee_id\":85,\"document_id\":3,\"description\":\"Uploaded: profile_icons.png\"}','2026-10-20 21:02:11','2026-10-20 21:02:11'),
(315,NULL,'login_success','login','users',85,NULL,'ef269729-07d5-4164-9cc9-734f57903ca9','165.99.250.110, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-20 21:05:06','2026-10-20 21:05:06'),
(316,NULL,'login_success','login','users',85,NULL,'a46e5799-0544-48ac-a13d-9d1e14b8b34d','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-21 02:45:20','2026-10-21 02:45:20'),
(317,2,'login_success','login','users',2,NULL,'2f299dfd-9a59-463b-be72-0a1a6dd5bcf4','111.90.245.9, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-21 02:51:48','2026-10-21 02:51:48'),
(318,NULL,'login_failure','login_attempt',NULL,NULL,'owner@ldemo.test','d12be956-4d18-417d-b8c9-120c966fa9e5','111.90.245.9, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-21 02:53:36','2026-10-21 02:53:36'),
(319,1,'login_success','login','users',1,NULL,'e44bbb64-edeb-4219-877c-9605527f65f0','111.90.245.9, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-21 02:53:51','2026-10-21 02:53:51'),
(320,1,'user_updated','user_updated','users',98,NULL,NULL,NULL,NULL,'Updated user_id=98: username=\'manny.linsaw\', role_id=3, status=\'Active\'','2026-10-21 02:54:24','2026-10-21 02:54:24'),
(321,2,'login_success','login','users',2,NULL,'31c81e37-88ec-4fbe-923f-143575643169','49.146.52.236, 152.233.15.120','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','User logged in successfully.','2026-10-21 02:55:48','2026-10-21 02:55:48'),
(322,NULL,'login_failure','login_attempt',NULL,NULL,'hradmin','af42c92c-5fad-4827-985c-08363d74a4eb','49.146.52.236, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-21 03:26:23','2026-10-21 03:26:23'),
(323,2,'login_success','login','users',2,NULL,'9360961f-6dd3-4bbb-9157-316dfacbe7de','49.146.52.236, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-21 03:26:32','2026-10-21 03:26:32'),
(324,1,'login_success','login','users',1,NULL,'475ca601-ab7d-4afb-9c3e-c51a9c1a41ee','49.145.201.246, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-21 04:00:18','2026-10-21 04:00:18'),
(325,NULL,'login_failure','login_attempt',NULL,NULL,'owner@lightdiamond.ph','c520599a-fe95-4d43-95d2-4b21b68db504','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:17','2026-10-21 18:04:17'),
(326,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'','3393d4e0-bf26-4cea-a4ed-f925152cdd92','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:39','2026-10-21 18:04:39'),
(327,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6487577f-3f85-4018-89cb-668d27bb431b','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:40','2026-10-21 18:04:40'),
(328,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'1\'=\'1-- -','5e5d3ece-0273-450a-9c2a-1f8c75e15575','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:41','2026-10-21 18:04:41'),
(329,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'1\'=\'1#','6705deca-90e1-470b-b4f4-2d7f09833cbd','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:41','2026-10-21 18:04:41'),
(330,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'1\'=\'1--','94687b56-c82c-4a29-98e8-f8ce32806ca1','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:42','2026-10-21 18:04:42'),
(331,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'1\'=\'1/*','cd27d1a2-5372-4cb5-a5e8-cc1cc038d340','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:42','2026-10-21 18:04:42'),
(332,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" OR \"1\"=\"1-- -','0c14401f-967a-424e-9c67-5218653ea2de','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:42','2026-10-21 18:04:42'),
(333,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'1\'=\'1;--','3dbb3e47-3b27-4737-a49f-39837902fedc','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:42','2026-10-21 18:04:42'),
(334,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" OR \"1\"=\"1#','c90667bc-fe1e-4799-a48b-aa4cb3c14256','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:43','2026-10-21 18:04:43'),
(335,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'1\'=\'1','f72e58c8-4fd5-4218-87a3-3b2d59f60bae','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:43','2026-10-21 18:04:43'),
(336,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND \'1\'=\'2#','4e4f62fd-9987-4bfd-99d6-deb3a9ae74ba','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:44','2026-10-21 18:04:44'),
(337,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND \'1\'=\'2-- -','1a33cd03-e132-41ba-8c1f-872e97cd6dd6','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:44','2026-10-21 18:04:44'),
(338,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND \'1\'=\'2--','80e3488c-899d-4bfc-bfcd-569381a6bb54','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:46','2026-10-21 18:04:46'),
(339,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND \'1\'=\'2/*','23ea4c3f-370f-4e84-97b8-1521e9f96b6b','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:46','2026-10-21 18:04:46'),
(340,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" AND \"1\"=\"2-- -','9e7c626b-995e-4b9f-9f15-03c911cee799','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:46','2026-10-21 18:04:46'),
(341,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND \'1\'=\'2;--','f8b22fad-d7a5-4873-b2c5-f0276a109027','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:46','2026-10-21 18:04:46'),
(342,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" AND \"1\"=\"2#','861c5a98-de94-4b47-8315-fc0d585e0ee5','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:47','2026-10-21 18:04:47'),
(343,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND \'1\'=\'2','0a89ee6f-6108-4b48-bbe5-d745434c6414','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:47','2026-10-21 18:04:47'),
(344,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" OR \"1\"=\"1/*','fbd1ec6b-3412-4aef-a743-08933fb6234e','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:48','2026-10-21 18:04:48'),
(345,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" OR \"1\"=\"1;--','d201b1bc-e254-492a-aea6-6df4d948353e','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:48','2026-10-21 18:04:48'),
(346,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" OR \"1\"=\"1--','b9d905fc-9dd2-4a5b-9bf4-82267da104c8','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:48','2026-10-21 18:04:48'),
(347,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" OR \"1\"=\"1','58da4c36-4277-4f9f-b247-2572712adce3','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:48','2026-10-21 18:04:48'),
(348,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com` OR `1`=`1-- -','0e7b02eb-1ffe-4d5a-9194-2e3c3b080b45','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:50','2026-10-21 18:04:50'),
(349,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com` OR `1`=`1#','403768b4-9176-405d-b692-4926e0f23aec','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:50','2026-10-21 18:04:50'),
(350,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com` OR `1`=`1/*','9fd79f17-8dfc-4fc5-9727-bfb5853d9b82','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:51','2026-10-21 18:04:51'),
(351,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com` OR `1`=`1;--','fc63f55c-6fba-46a9-8925-f6a3e1cf540d','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:51','2026-10-21 18:04:51'),
(352,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" AND \"1\"=\"2/*','100c8256-3462-44e4-84bf-d3b91e823f39','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:51','2026-10-21 18:04:51'),
(353,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" AND \"1\"=\"2;--','1edf7ac5-f4ae-42cd-b546-e8d41b1012ee','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:51','2026-10-21 18:04:51'),
(354,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" AND \"1\"=\"2--','d4c14d0d-2544-4732-ab92-db0cac5c2e09','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:52','2026-10-21 18:04:52'),
(355,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" AND \"1\"=\"2','4ba21962-f5b1-4b0d-bf1b-983b4450d327','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:52','2026-10-21 18:04:52'),
(356,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com` AND `1`=`2-- -','a94efbc1-3000-492e-842e-7b5c8ba4d711','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:53','2026-10-21 18:04:53'),
(357,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com` AND `1`=`2#','9ba3dfe5-8c3d-45c3-8fb0-f2282be8c984','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:53','2026-10-21 18:04:53'),
(358,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com` AND `1`=`2/*','ccb57ca4-8914-4abd-a082-86a22083b2db','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:55','2026-10-21 18:04:55'),
(359,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com` AND `1`=`2;--','157c1327-2057-42d1-8019-aa22674e5828','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:55','2026-10-21 18:04:55'),
(360,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com` OR `1`=`1--','a098074a-3b21-4d86-af13-d00bf9170781','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:55','2026-10-21 18:04:55'),
(361,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com` OR `1`=`1','d999fae9-313a-424d-ac0d-fbd684c36072','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:55','2026-10-21 18:04:55'),
(362,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR 1=1-- -','a65efb83-8f78-4232-859b-9553d90b58b1','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:56','2026-10-21 18:04:56'),
(363,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR 2>1-- -','baa03f8a-7413-4a71-bcaa-5b10cb811018','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:56','2026-10-21 18:04:56'),
(364,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR true-- -','c517402d-96e8-45cd-bcbb-54fc8245f206','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:56','2026-10-21 18:04:56'),
(365,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR 1=1#','83368478-8eef-46df-a016-52fdda6d90a1','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:57','2026-10-21 18:04:57'),
(366,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR 2>1#','85cac356-f7f3-4281-bb28-9a59af807b7d','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:57','2026-10-21 18:04:57'),
(367,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR true#','9840fc6a-34a2-4e91-a5cd-aa5c69027eb1','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:58','2026-10-21 18:04:58'),
(368,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com` AND `1`=`2--','74b0422b-2dba-4298-a161-ba25b0e73159','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:59','2026-10-21 18:04:59'),
(369,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com` AND `1`=`2','30fd67e1-1016-4832-84c9-58ad57f17228','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:04:59','2026-10-21 18:04:59'),
(370,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND 1=2-- -','215e4e58-2f4b-42a7-9f2b-4b859a6124b6','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:00','2026-10-21 18:05:00'),
(371,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND 2<1-- -','18575c58-beeb-4b7d-9da2-ed627d3774cb','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:00','2026-10-21 18:05:00'),
(372,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND false-- -','d505eb3a-b869-4d43-8e0f-706e3daba443','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:00','2026-10-21 18:05:00'),
(373,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND 1=2#','e2a392dc-dde9-464a-9e84-214c5ecb7e5c','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:01','2026-10-21 18:05:01'),
(374,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND 2<1#','36312f60-7351-4b8d-9f31-e5bca1fe9b4f','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:01','2026-10-21 18:05:01'),
(375,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND false#','1213b291-93bf-4454-9b6b-c949ec17766b','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:02','2026-10-21 18:05:02'),
(376,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR 1=1/*','a59e63c8-5ebc-4f5a-ba98-641345e63a77','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:02','2026-10-21 18:05:02'),
(377,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR 2>1/*','b73f90c0-78b3-45d5-a0eb-3db39668399b','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:04','2026-10-21 18:05:04'),
(378,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR true/*','2ebba040-f543-400f-8bf4-04ed3d20be4d','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:04','2026-10-21 18:05:04'),
(379,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR 1=1;--','3fc8e6f1-b93d-4811-88a3-00f31fe9e5b2','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:05','2026-10-21 18:05:05'),
(380,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR true;--','b7565b72-d3ad-4bde-ab19-34683ea41d26','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:05','2026-10-21 18:05:05'),
(381,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR 2>1;--','a4560d72-5265-43c1-bc68-8e3fe27d308a','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:05','2026-10-21 18:05:05'),
(382,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR 1=1--','2baad0d0-02be-400c-b05d-48797c50db06','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:06','2026-10-21 18:05:06'),
(383,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR 2>1--','e382f389-391c-43f9-8fa3-5164409590ca','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:06','2026-10-21 18:05:06'),
(384,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND 1=2/*','aba87877-69de-4203-83f0-b18d691decc4','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:06','2026-10-21 18:05:06'),
(385,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND 1=2;--','eb22c884-6f6b-4b5c-b66c-5a8dfb6ed831','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:07','2026-10-21 18:05:07'),
(386,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND false;--','021a5d0c-8bb3-426c-8695-966e6a890dc1','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:07','2026-10-21 18:05:07'),
(387,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND 2<1/*','15da96ce-2a1e-4367-8948-4aa0b742331a','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:08','2026-10-21 18:05:08'),
(388,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND false/*','900e1ec3-7886-4ea4-acc4-58d56ab39045','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:08','2026-10-21 18:05:08'),
(389,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND 2<1--','854fa680-6ebb-463e-a382-18309fe52193','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:10','2026-10-21 18:05:10'),
(390,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR true--','d6323593-e431-4ba2-8e9b-87c98cc4ee09','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:10','2026-10-21 18:05:10'),
(391,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND 2<1;--','cdcb8478-1f6a-4643-a617-98d1451db2e2','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:11','2026-10-21 18:05:11'),
(392,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND 1=2--','97efe63e-0423-48ed-993d-028a6e415fbe','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:11','2026-10-21 18:05:11'),
(393,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR 2>1','a3adb9d2-dbe5-4fa2-ba9c-f2b1e8514654','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:11','2026-10-21 18:05:11'),
(394,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR 1=1','2fd73c05-79df-40d4-adba-dce737d9c4a6','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:12','2026-10-21 18:05:12'),
(395,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com) OR (1=1-- -','9367cb3b-7a97-481e-9aeb-53a3bf8fcb75','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:12','2026-10-21 18:05:12'),
(396,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com OR true','53b881fa-24d5-4ba0-8232-3c4515f2696e','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:12','2026-10-21 18:05:12'),
(397,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND false--','b0f0736a-1bee-4ea4-9b45-c9f71df13e32','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:13','2026-10-21 18:05:13'),
(398,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\') OR (\'1\'=\'1-- -','815215db-0597-451c-8aa1-f98d48ffa7f7','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:13','2026-10-21 18:05:13'),
(399,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com) OR (1=1#','60de797a-35e1-440e-a5cb-83cf2b4a67ab','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:15','2026-10-21 18:05:15'),
(400,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\') OR (\'1\'=\'1#','d7758dfb-9e5c-493f-beee-15a1ee6a3873','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:15','2026-10-21 18:05:15'),
(401,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND 1=2','713ddb3d-c6dc-4305-8d7a-e0e486f68590','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:15','2026-10-21 18:05:15'),
(402,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND 2<1','cff71994-587b-45ff-9dc8-a52ae958a50c','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:15','2026-10-21 18:05:15'),
(403,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com) AND (1=2-- -','40944667-8744-4612-afb6-a102cc6d2b68','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:16','2026-10-21 18:05:16'),
(404,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com AND false','dcd23a70-adb1-4553-9e7a-263a08c882cd','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:16','2026-10-21 18:05:16'),
(405,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com) OR (1=1','610d290a-6b12-47a4-9373-857b6d02273b','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:17','2026-10-21 18:05:17'),
(406,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\') AND (\'1\'=\'2-- -','c8b850d7-fca6-4aca-a58c-7e668862ce76','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:17','2026-10-21 18:05:17'),
(407,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\') AND (\'1\'=\'2#','fd6d0066-384a-4b30-8158-c59f87b20ed8','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:18','2026-10-21 18:05:18'),
(408,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com) AND (1=2#','1080d440-9bd5-43c5-bb78-fad2db235675','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:18','2026-10-21 18:05:18'),
(409,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\') OR (\'1\'=\'1','1ca9bf59-9aa7-43a1-9e42-68cd2ad530c6','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:19','2026-10-21 18:05:19'),
(410,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com)) OR ((1=1-- -','4e32d490-c97d-48c4-92f6-319281579efc','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:19','2026-10-21 18:05:19'),
(411,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\')) OR ((\'1\'=\'1-- -','35e4244c-d76c-4aea-92a1-8f9a61c1715d','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:20','2026-10-21 18:05:20'),
(412,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\')) OR ((\'1\'=\'1#','5f0f91e3-7dbe-400d-bf59-f732a0b05b9f','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:20','2026-10-21 18:05:20'),
(413,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com) AND (1=2','f27d4bf6-f1f0-4159-8cbc-493a668ff413','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:21','2026-10-21 18:05:21'),
(414,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com)) OR ((1=1','d8ad79c2-fcac-492c-9b9f-9984a9e42013','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:21','2026-10-21 18:05:21'),
(415,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com)) OR ((1=1#','4fbd8d0c-d557-433c-9698-6509babe4fd9','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:21','2026-10-21 18:05:21'),
(416,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\')) OR ((\'1\'=\'1','8d785feb-4760-4584-97d9-9e927ee17c34','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:22','2026-10-21 18:05:22'),
(417,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\') AND (\'1\'=\'2','fce312dd-d1e7-4e39-a780-1ccdc769f75e','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:22','2026-10-21 18:05:22'),
(418,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com)) AND ((1=2-- -','f14b1ac0-da67-4473-b49f-db6f7ab1a12b','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:22','2026-10-21 18:05:22'),
(419,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\')) AND ((\'1\'=\'2#','81a7e264-f1a9-49cb-afaf-1d696440f00a','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:23','2026-10-21 18:05:23'),
(420,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\')) AND ((\'1\'=\'2-- -','9da7650e-dac9-46d7-97a4-80612cd217bd','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:24','2026-10-21 18:05:24'),
(421,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com))) OR (((1=1-- -','95252432-8c10-423c-933b-a6e88ed7a27e','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:24','2026-10-21 18:05:24'),
(422,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com)) AND ((1=2','81e1e416-4f05-4131-a8d0-83ad9c6cf0e1','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:25','2026-10-21 18:05:25'),
(423,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com)) AND ((1=2#','1cb4c97b-36f3-485f-817b-10455c78e6d7','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:25','2026-10-21 18:05:25'),
(424,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\')) AND ((\'1\'=\'2','69bbea2e-16cd-4f96-8deb-daaba4c942ad','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:25','2026-10-21 18:05:25'),
(425,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'))) OR (((\'1\'=\'1-- -','2f5feb00-2e15-452f-8a6a-95b78e9032d1','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:26','2026-10-21 18:05:26'),
(426,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com))) OR (((1=1#','736ee75e-c1d6-407d-98d4-ae3586a8bd4b','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:26','2026-10-21 18:05:26'),
(427,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'))) OR (((\'1\'=\'1#','0a69ac99-f84f-4718-9536-658b484daa21','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:27','2026-10-21 18:05:27'),
(428,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com))) OR (((1=1','1189a8ef-8578-49c7-81f9-c0e410f8c318','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:27','2026-10-21 18:05:27'),
(429,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'))) OR (((\'1\'=\'1','ba7f2c17-d09d-4e11-b23f-801bd1316752','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:27','2026-10-21 18:05:27'),
(430,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com))) AND (((1=2-- -','6065ab82-5196-437a-a414-d1ca4a8691c4','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:28','2026-10-21 18:05:28'),
(431,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com)))) OR ((((1=1-- -','763c605b-8e9a-4dde-8725-67851ea5fc2e','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:29','2026-10-21 18:05:29'),
(432,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\')))) OR ((((\'1\'=\'1-- -','0d31f379-98b5-4901-a418-9978bfbfa15a','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:29','2026-10-21 18:05:29'),
(433,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'))) AND (((\'1\'=\'2-- -','83f4351d-3223-4593-a487-ff3412b8fc5b','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:30','2026-10-21 18:05:30'),
(434,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com))) AND (((1=2#','0a7dface-c2e6-43ca-8472-273dae321e63','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:30','2026-10-21 18:05:30'),
(435,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'))) AND (((\'1\'=\'2#','568c8281-595f-4eaf-96c7-dee2dfda9bc6','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:30','2026-10-21 18:05:30'),
(436,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com))) AND (((1=2','45ea6510-e57b-4200-b9fd-49b20ca9660e','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:30','2026-10-21 18:05:30'),
(437,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'))) AND (((\'1\'=\'2','02b3974c-97f5-4ace-8b2a-46388bbb7a88','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:31','2026-10-21 18:05:31'),
(438,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com)))) AND ((((1=2-- -','a4224616-49fb-49c2-87c1-70d75171404a','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:31','2026-10-21 18:05:31'),
(439,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\')))) AND ((((\'1\'=\'2-- -','fec7457e-bbe0-439b-8b0d-311712489a70','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:32','2026-10-21 18:05:32'),
(440,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com)))) OR ((((1=1#','5f155c1e-a4bd-40bb-a9e2-557e0f00e6ca','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:32','2026-10-21 18:05:32'),
(441,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com)))) OR ((((1=1','a852d105-f758-491a-9fe5-e236fb98bac0','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:34','2026-10-21 18:05:34'),
(442,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'1\' LIKE \'1','e892680b-3697-44b0-9de7-83366435e92d','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:35','2026-10-21 18:05:35'),
(443,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\')))) OR ((((\'1\'=\'1#','d2af3597-a2f4-4932-aea3-859cb3bb23bd','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:35','2026-10-21 18:05:35'),
(444,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com%\' OR \'1\'=\'1','c91162da-b6ba-4363-9034-be6341b3ffba','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:35','2026-10-21 18:05:35'),
(445,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\')))) OR ((((\'1\'=\'1','9c00ff3d-a94b-42fd-a1f8-b8d6e11ae647','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:36','2026-10-21 18:05:36'),
(446,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com)))) AND ((((1=2#','d68a821c-aecc-48a4-bd7c-6833b961ec91','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:36','2026-10-21 18:05:36'),
(447,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'%\'=\'%','de9dbb3f-8d01-4b4c-a136-da215d82b8ae','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:36','2026-10-21 18:05:36'),
(448,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'a\' LIKE \'a','1c314340-e6ed-4dec-95b4-52c2dd532d81','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:37','2026-10-21 18:05:37'),
(449,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com)))) AND ((((1=2','c9ed0fb7-2a10-4aaa-abda-9be6d1552ad2','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:37','2026-10-21 18:05:37'),
(450,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\')))) AND ((((\'1\'=\'2#','69a169f0-68fd-406d-8b7c-6509f97768ac','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:38','2026-10-21 18:05:38'),
(451,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND \'1\' LIKE \'2','9f89503a-90e9-4807-897c-9d6a8af16dc2','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:39','2026-10-21 18:05:39'),
(452,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com%\' AND \'1\'=\'2','ef6b0db6-f46d-4216-98fc-1599e4493b35','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:39','2026-10-21 18:05:39'),
(453,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\')))) AND ((((\'1\'=\'2','f9d94d86-d11f-43fe-acab-d7ecbbc34de6','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:39','2026-10-21 18:05:39'),
(454,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'abc\' LIKE \'%b%','9c36856e-eebe-4dd5-99ca-dcab325efdc0','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:40','2026-10-21 18:05:40'),
(455,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND \'%\'=\'x','76cd94a5-9484-44f3-b5b7-6a57f31f6822','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:40','2026-10-21 18:05:40'),
(456,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'test\' LIKE \'t%','232dd1d4-82c4-4635-aa91-18a9552d948b','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:41','2026-10-21 18:05:41'),
(457,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND \'a\' LIKE \'b','13bc5e52-2ee0-4cd6-9506-670d41495cca','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:41','2026-10-21 18:05:41'),
(458,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'test\' NOT LIKE \'z%','d85f051d-134d-4f53-ae93-709f4168fb22','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:41','2026-10-21 18:05:41'),
(459,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 LIKE 1','81ec6c5d-3167-4d63-bd51-8862de27ead7','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:42','2026-10-21 18:05:42'),
(460,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'x\'=\'x-- -','da48a545-8924-4ea2-b36e-863669248412','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:42','2026-10-21 18:05:42'),
(461,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION SELECT 1-- -','59bae151-ac4e-4528-9ca2-c24a163af657','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:43','2026-10-21 18:05:43'),
(462,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION SELECT NULL-- -','2ac3f6bb-9848-47ed-b8cc-13f77cf88575','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:44','2026-10-21 18:05:44'),
(463,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND \'abc\' LIKE \'%z%','e65bcd05-9048-4fba-a5af-9b6d3b7b1c23','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:44','2026-10-21 18:05:44'),
(464,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND \'test\' LIKE \'z%','280b4cae-8cf8-4597-9fee-3068265923ba','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:44','2026-10-21 18:05:44'),
(465,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION ALL SELECT 1-- -','ae86e809-aa66-47ef-8986-4b12a907bf72','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:45','2026-10-21 18:05:45'),
(466,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND \'test\' NOT LIKE \'t%','6456bd87-f5d2-42df-8477-cf3e12349b45','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:45','2026-10-21 18:05:45'),
(467,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1 LIKE 2','e606d9d4-5ad2-47a0-be68-bbdd407c1d7d','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:45','2026-10-21 18:05:45'),
(468,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'x\'=\'y\' AND \'1\'=\'2-- -','8f892c83-859d-4ba0-883c-5905982f6571','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:46','2026-10-21 18:05:46'),
(469,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION SELECT 1 WHERE 1=2-- -','cd7794d3-69a3-4041-a66d-6674c7f30bd9','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:46','2026-10-21 18:05:46'),
(470,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION SELECT 1#','4e4fdee7-ae33-494d-9898-cae80570115d','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:47','2026-10-21 18:05:47'),
(471,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION ALL SELECT 1 WHERE 1=2-- -','67d69f8d-9ba9-4bdc-a323-35d563171ba6','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:47','2026-10-21 18:05:47'),
(472,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION SELECT NULL WHERE 1=2-- -','bf23d6be-7bba-43f3-a84f-15a10d77a490','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:48','2026-10-21 18:05:48'),
(473,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'x\'=\'x#','715c8801-9987-43f9-941d-e2be32ac4680','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:49','2026-10-21 18:05:49'),
(474,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION SELECT NULL#','35a9a693-f52b-4628-b595-056fcd0b8050','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:49','2026-10-21 18:05:49'),
(475,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION SELECT 1','e0dc7b13-4602-4563-a560-01e11506b608','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:50','2026-10-21 18:05:50'),
(476,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION ALL SELECT 1#','a5a765ff-0fd2-4431-8945-a497975611f3','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:50','2026-10-21 18:05:50'),
(477,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'x\'=\'x','aaa667be-59a0-41a9-a1b2-9a03c224f2c6','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:50','2026-10-21 18:05:50'),
(478,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION SELECT 1 WHERE 1=2#','6bbd735a-179a-40f2-a65c-35046f547578','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:51','2026-10-21 18:05:51'),
(479,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION SELECT NULL','98ba085d-9f72-427f-bda7-31477f060b9a','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:51','2026-10-21 18:05:51'),
(480,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION ALL SELECT 1','60c9a91b-f545-4b9f-bb1a-7cf119ab4f1b','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:51','2026-10-21 18:05:51'),
(481,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'x\'=\'y\' AND \'1\'=\'2#','f8e626be-ec46-453a-a2b6-98f8bbad368f','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:51','2026-10-21 18:05:51'),
(482,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION SELECT 1 WHERE 1=2','0953fbb3-f14f-450c-9182-04e82714c716','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:52','2026-10-21 18:05:52'),
(483,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION SELECT NULL WHERE 1=2#','21b29b06-4fbb-46a3-a807-4fb9891a3ae6','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:53','2026-10-21 18:05:53'),
(484,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION ALL SELECT 1 WHERE 1=2#','785f3b3b-d594-4449-9ecc-3f49f553caee','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:54','2026-10-21 18:05:54'),
(485,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'x\'=\'y\' AND \'1\'=\'2','d0b615db-d3c5-44b8-b305-9fc91a0ad2e4','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:54','2026-10-21 18:05:54'),
(486,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR SLEEP(0)=\'0','538d91df-b6ad-4730-9b3b-2703bbc4781f','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:54','2026-10-21 18:05:54'),
(487,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION SELECT NULL WHERE 1=2','468f3088-f160-4e3e-8f0a-afbac8078f65','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:55','2026-10-21 18:05:55'),
(488,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR TRUE-- -','ede199a8-e452-4e68-94cc-b5bf3d9a1d64','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:55','2026-10-21 18:05:55'),
(489,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UNION ALL SELECT 1 WHERE 1=2','44518559-a79d-475e-846c-c37b96caec64','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:55','2026-10-21 18:05:55'),
(490,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1::int-- -','a4706563-d295-4dc2-b92b-64bbdddf231e','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:56','2026-10-21 18:05:56'),
(491,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1;--','7bd27d69-d91c-4f18-9bcf-029c97da4b34','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:56','2026-10-21 18:05:56'),
(492,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1--','82b4cc11-acf9-4c07-80be-aa8fa71ec9d8','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:57','2026-10-21 18:05:57'),
(493,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'a\'=\'a','4464e136-8c0b-4cd7-8b19-eaea17718bd1','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:57','2026-10-21 18:05:57'),
(494,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND SLEEP(0)=\'1','bf383381-6ee9-42f6-9972-d083f9ff2bbf','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:58','2026-10-21 18:05:58'),
(495,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR ROWNUM=1-- -','5f8d7e91-19f3-42cf-8fd3-2d402bd4ef11','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:58','2026-10-21 18:05:58'),
(496,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR FALSE-- -','0b7f4577-f47a-4803-848e-1fbabeb70dc6','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:59','2026-10-21 18:05:59'),
(497,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1; --','762c627a-eef4-4239-929a-bc32f6858f21','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:05:59','2026-10-21 18:05:59'),
(498,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2;--','09afb5c3-af83-4cdd-b3b6-e72de2f8253f','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:00','2026-10-21 18:06:00'),
(499,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2::int-- -','577277ce-737b-477e-a838-ff901b81ff39','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:00','2026-10-21 18:06:00'),
(500,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'1\'=\'1\' AND \'1\'=\'1','b2c9f48a-42fe-4526-9a21-7a04ab0685d0','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:01','2026-10-21 18:06:01'),
(501,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2--','af4edd6f-bbea-4f83-a216-60eb0386ebee','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:01','2026-10-21 18:06:01'),
(502,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND \'a\'=\'b','b0a305e8-069e-4fe3-a64b-05521e238e68','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:01','2026-10-21 18:06:01'),
(503,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2; --','3fd73c01-5b07-461c-aeb9-19dea6dbe377','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:02','2026-10-21 18:06:02'),
(504,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND ROWNUM=0-- -','fafd99da-6676-4f92-ae4b-701f763a4f27','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:03','2026-10-21 18:06:03'),
(505,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 XOR 0-- -','f27ee593-2743-449a-8a42-22a874bbc491','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:04','2026-10-21 18:06:04'),
(506,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1 LIMIT 1-- -','38a9d55d-9b38-4550-88fa-64cdc59a6c4f','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:04','2026-10-21 18:06:04'),
(507,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1 OFFSET 0-- -','048332fe-e635-4643-9070-97fc31c1b971','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:05','2026-10-21 18:06:05'),
(508,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'1\'=\'1\' AND \'1\'=\'2','3f839656-c750-4163-96e3-21f3c03b484c','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:05','2026-10-21 18:06:05'),
(509,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR DUAL.DUMMY=\'X-- -','5ade4e13-6e78-4b0d-b08e-6ad832afd854','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:05','2026-10-21 18:06:05'),
(510,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR TOP 1 1=1-- -','d5ffd230-bc8c-4e3a-9015-5645a15ff874','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:06','2026-10-21 18:06:06'),
(511,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1::text=\'1\'-- -','e4ef24d9-47bc-4344-aa1c-dfdfa58829db','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:06','2026-10-21 18:06:06'),
(512,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR CAST(1 AS INT)=1-- -','f42ce9c2-5803-4fcc-9096-6d78acdccd21','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:06','2026-10-21 18:06:06'),
(513,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 XOR 1-- -','5b0d1c86-3389-499d-9261-38a125213fa5','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:07','2026-10-21 18:06:07'),
(514,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2 OFFSET 0-- -','a123c2fc-26c1-46c4-9eed-199b1a42d9bd','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:07','2026-10-21 18:06:07'),
(515,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2 LIMIT 1-- -','90d763af-e8bc-4ef6-aea3-c3605c6104ee','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:08','2026-10-21 18:06:08'),
(516,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR CONVERT(INT,1)=1-- -','06f388db-d4be-474b-9ef2-98ed98fd9fa4','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:09','2026-10-21 18:06:09'),
(517,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND DUAL.DUMMY=\'Y-- -','693c127e-a04c-42c9-b9af-6d2315adcdd9','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:09','2026-10-21 18:06:09'),
(518,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND TOP 1 1=2-- -','d0b53d15-fbc8-46d5-bc6b-fd33ab66b12c','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:10','2026-10-21 18:06:10'),
(519,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2::text=\'1\'-- -','35bb3e90-c9b5-4e00-9616-7b11ee994f83','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:10','2026-10-21 18:06:10'),
(520,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1 RETURNING 1-- -','b4087ae8-e57b-4d52-a1bf-2e67d23b8a10','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:10','2026-10-21 18:06:10'),
(521,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND CAST(1 AS INT)=2-- -','323a4098-7a8e-4341-89a7-eb1312abd2a7','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:10','2026-10-21 18:06:10'),
(522,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR pg_sleep(0)=pg_sleep(0)-- -','7bedd94d-9cf7-409a-b004-300c5390bfa4','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:11','2026-10-21 18:06:11'),
(523,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR BENCHMARK(0,1)=0-- -','633b83ff-fdef-4971-b15a-b6db7310936b','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:11','2026-10-21 18:06:11'),
(524,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (CASE WHEN 1=1 THEN 1 ELSE 0 END)=1-- -','2b39313f-ba8a-4da6-a762-f10137a9c2de','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:12','2026-10-21 18:06:12'),
(525,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND CONVERT(INT,1)=2-- -','a67c9ca3-9410-4d69-b569-535a08aa5c71','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:13','2026-10-21 18:06:13'),
(526,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR IF(1=1,1,0)=1-- -','7b7bc365-eff6-49d8-93ce-1c0187d7a070','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:13','2026-10-21 18:06:13'),
(527,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR IIF(1=1,1,0)=1-- -','dcf8374d-12a8-476d-a52e-0369013d3137','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:14','2026-10-21 18:06:14'),
(528,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR DECODE(1,1,1,0)=1-- -','2d70e6bc-0fb6-4cee-b814-30f7d5d0c3bb','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:14','2026-10-21 18:06:14'),
(529,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2 RETURNING 1-- -','d0c36f41-768c-4a6e-96e1-012fd77462c7','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:14','2026-10-21 18:06:14'),
(530,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND pg_sleep(0)!=pg_sleep(0)-- -','caef5ae4-40f6-4713-a441-7757f9ccc19a','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:15','2026-10-21 18:06:15'),
(531,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND BENCHMARK(0,1)=1-- -','c7183aee-46f9-4497-9f7a-67d674ecdf9b','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:15','2026-10-21 18:06:15'),
(532,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (CASE WHEN 1=2 THEN 1 ELSE 0 END)=1-- -','f47c4e8d-e443-4ca0-be05-d807c67c52fe','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:16','2026-10-21 18:06:16'),
(533,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR IIF(1=2,1,0)=1-- -','6b91dd43-3567-438f-b993-ca9ac337ad0b','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:16','2026-10-21 18:06:16'),
(534,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR DECODE(1,2,1,0)=1-- -','cb8c4f71-295c-4d38-b392-d12f05768bd9','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:17','2026-10-21 18:06:17'),
(535,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (SELECT CASE WHEN (1=1) THEN 1 ELSE 0 END)=1-- -','34e1b6d5-d0b3-4432-a6c1-3d054c7e7fc3','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:17','2026-10-21 18:06:17'),
(536,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR IF(1=2,1,0)=1-- -','d26c5fcd-9082-49b5-bd75-936d23cc0d27','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:17','2026-10-21 18:06:17'),
(537,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR NULLIF(1,1) IS NULL-- -','3d6b90b7-128e-4de4-a1f7-91d0e63498c8','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:18','2026-10-21 18:06:18'),
(538,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (SELECT 1)=1-- -','5fec25d9-4c42-4cae-b72a-b5995e7c80ac','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:19','2026-10-21 18:06:19'),
(539,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR COALESCE(NULL,1)=1-- -','87705977-bc50-4146-af14-01b892b541e4','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:19','2026-10-21 18:06:19'),
(540,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (SELECT COUNT(*) FROM (SELECT 1) x)=1-- -','3d7dacb5-3e49-4c89-a673-9f0a4aee3fab','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:20','2026-10-21 18:06:20'),
(541,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR EXISTS(SELECT 1)-- -','e80c8ec3-a1b3-4e90-87c8-57f018bb46ef','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:20','2026-10-21 18:06:20'),
(542,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=(SELECT 1)-- -','9a42e1cc-88e5-4e77-a238-13fb20adc83a','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:20','2026-10-21 18:06:20'),
(543,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (SELECT CASE WHEN (1=2) THEN 1 ELSE 0 END)=1-- -','25e9a6a2-d16a-441a-9b84-96f1fa3119bf','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:20','2026-10-21 18:06:20'),
(544,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (SELECT 1 FROM DUAL)=1-- -','0894d89e-f062-4f64-a4e1-5319e0cd79d0','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:21','2026-10-21 18:06:21'),
(545,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR NULLIF(1,2) IS NULL-- -','caa8e1b1-ca8e-4a31-ace7-28e1408356bc','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:21','2026-10-21 18:06:21'),
(546,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (SELECT 1)=2-- -','fe426369-cf0b-4de0-99d2-c8badb216c94','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:22','2026-10-21 18:06:22'),
(547,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR COALESCE(NULL,1)=2-- -','44e832de-8549-4b3c-9580-33220c9731e7','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:23','2026-10-21 18:06:23'),
(548,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (SELECT COUNT(*) FROM (SELECT 1) x)=2-- -','8b04837f-5412-41e6-bc57-359156374137','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:24','2026-10-21 18:06:24'),
(549,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR EXISTS(SELECT 1 WHERE 1=2)-- -','339c5dd9-4919-4589-a9d8-1b2f145c1c6f','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:24','2026-10-21 18:06:24'),
(550,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (SELECT 1)=(SELECT 1)-- -','44e44401-464c-4399-bfd2-6a99b236af4f','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:24','2026-10-21 18:06:24'),
(551,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 2=(SELECT 1)-- -','1abe839b-fc9c-471b-ae6e-e9e8c9b171b8','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:24','2026-10-21 18:06:24'),
(552,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (SELECT 1 FROM DUAL)=2-- -','58f16f15-bbcf-4d08-9119-37a1746de690','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:25','2026-10-21 18:06:25'),
(553,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR NOT EXISTS(SELECT 1 WHERE 1=2)-- -','04d40d45-e847-4ad2-ad36-0427194ed715','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:25','2026-10-21 18:06:25'),
(554,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' HAVING 1=1-- -','9d3efd10-fcc4-44dd-bb7f-a15dd8d8f660','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:25','2026-10-21 18:06:25'),
(555,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' GROUP BY 1 HAVING 1=1-- -','662bd1c5-aa4f-45ef-9bd7-17985ff998be','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:26','2026-10-21 18:06:26'),
(556,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' GROUP BY 1 HAVING 1=1#','6e9dfebc-b1ba-4c2d-9741-5c932f085c73','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:27','2026-10-21 18:06:27'),
(557,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' GROUP BY 1,2 HAVING 1=1-- -','1ce37af2-12c5-4a88-a1af-8bbc2be4068a','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:27','2026-10-21 18:06:27'),
(558,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (SELECT 1)=(SELECT 2)-- -','add3b364-af1c-423d-93a7-321a2776e5f9','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:28','2026-10-21 18:06:28'),
(559,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'+OR+\'1\'=\'1','d80bb137-4209-4642-942c-25b1dc3f69b7','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:28','2026-10-21 18:06:28'),
(560,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'%20OR%20\'1\'=\'1','6014eb2c-6e1c-4af7-912f-2885b5af772d','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:29','2026-10-21 18:06:29'),
(561,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR NOT EXISTS(SELECT 1)-- -','f657618a-df2d-4ea4-8286-e5bfbf8cff02','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:29','2026-10-21 18:06:29'),
(562,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' HAVING 1=2-- -','33853ef5-6b4f-4bde-9fed-317069ed7c7d','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:29','2026-10-21 18:06:29'),
(563,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' GROUP BY 1 HAVING 1=2-- -','46598e24-9132-45d7-b838-5b1fd562b70f','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:30','2026-10-21 18:06:30'),
(564,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' GROUP BY 1 HAVING 1=2#','f5ca3fa4-6775-4e91-9e52-eb2896213a7d','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:30','2026-10-21 18:06:30'),
(565,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'+OR+\'1\'=\'2','6b5f8b9f-2ee4-45c7-bce3-8e5445831881','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:31','2026-10-21 18:06:31'),
(566,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'%20AND%20\'1\'=\'2','f5bfe048-dbdc-4c9b-8118-8b192f6631db','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:31','2026-10-21 18:06:31'),
(567,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' GROUP BY 1,2 HAVING 1=2-- -','d8aa70ad-d471-42a2-8999-e80a8df79837','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:31','2026-10-21 18:06:31'),
(568,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\\\' OR \\\'1\\\'=\\\'1','473ff7d7-fe95-47f7-ab0c-dd8baf8d9c08','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:32','2026-10-21 18:06:32'),
(569,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1%00','02129c91-d215-4062-bb50-6cebd6802e25','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:33','2026-10-21 18:06:33'),
(570,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1	-- -','92df3bd2-0b61-4ff8-a971-cc674445349d','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:33','2026-10-21 18:06:33'),
(571,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1\n--','ba7aa283-7e66-41ae-a67e-a480c7265222','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:34','2026-10-21 18:06:34'),
(572,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'/**/OR/**/1=1-- -','e317c476-4511-4776-a56d-488be0135d93','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:34','2026-10-21 18:06:34'),
(573,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'%0aOR%0a1=1-- -','b5edd4cd-4c5b-4b5c-8540-6439e4208aae','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:34','2026-10-21 18:06:34'),
(574,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' oR 1=1-- -','f6aaa78a-22f8-414e-85ee-4416ff747fa5','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:35','2026-10-21 18:06:35'),
(575,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' Or 1=1-- -','2d702811-082a-4b51-93b4-d71a076139f3','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:35','2026-10-21 18:06:35'),
(576,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\\\' AND \\\'1\\\'=\\\'2','fb8a6ef7-752b-455a-bba4-cafb27c763fa','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:35','2026-10-21 18:06:35'),
(577,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2%00','b681f820-3796-43cd-ba61-bc8a4ea188d7','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:36','2026-10-21 18:06:36'),
(578,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2	-- -','b5213b3c-0128-454d-adab-585c9e9e3585','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:36','2026-10-21 18:06:36'),
(579,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'/**/AND/**/1=2-- -','b1c3be6b-f656-42ec-b011-e7d0745a98b8','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:38','2026-10-21 18:06:38'),
(580,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2\n--','b0571ec3-c402-4749-bde2-141952d2bb51','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:38','2026-10-21 18:06:38'),
(581,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' aND 1=2-- -','82389a7a-a145-498c-90d3-fe93ccc9979c','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:38','2026-10-21 18:06:38'),
(582,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'%0aAND%0a1=2-- -','3dee2664-a906-4df7-b705-3b11aa85564e','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:39','2026-10-21 18:06:39'),
(583,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR/**/1=1-- -','95ae691a-0b93-4451-b0e2-0be77fbcbd96','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:39','2026-10-21 18:06:39'),
(584,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' And 1=2-- -','e4c9804d-96d2-4e5e-93e9-58b5b489e5da','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:39','2026-10-21 18:06:39'),
(585,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR(1=1)-- -','1a425a04-a35f-41c6-8b53-433523bde403','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:40','2026-10-21 18:06:40'),
(586,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'%09OR%091=1-- -','838cd16c-b1d7-48d8-baf2-b3c8a7ce4b44','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:40','2026-10-21 18:06:40'),
(587,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'%0dOR%0d1=1-- -','3d0e8d23-2968-426d-bbc3-d67f7eaaef4a','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:41','2026-10-21 18:06:41'),
(588,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' /*!OR*/ 1=1-- -','acf59871-e78d-49c7-8417-c3e3bc9f9fde','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:41','2026-10-21 18:06:41'),
(589,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UnIoN SeLeCt 1-- -','3969cf6c-dc92-45fd-bad2-228669cc9e24','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:42','2026-10-21 18:06:42'),
(590,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND/**/1=2-- -','40059bc0-5b03-4ba6-8c26-3ec49cacf9af','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:43','2026-10-21 18:06:43'),
(591,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND(1=2)-- -','ade74d4d-b42c-40f4-a3bc-8d93f7c9fff8','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:43','2026-10-21 18:06:43'),
(592,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR%0b1=1-- -','2c99e697-4cad-4af0-9591-3d7df72119a2','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:43','2026-10-21 18:06:43'),
(593,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR+1=1-- -','aa872dc3-d8cd-4c25-9341-6daacaf18c7f','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:44','2026-10-21 18:06:44'),
(594,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'%09AND%091=2-- -','ad7d74a8-13ee-4eb8-a96e-93aaad3efc14','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:44','2026-10-21 18:06:44'),
(595,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'%0dAND%0d1=2-- -','84238ab0-4e00-4a70-8015-14fcb3814912','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:45','2026-10-21 18:06:45'),
(596,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1.0-- -','5bac2482-af74-4d90-949d-0c588ed0ce7b','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:45','2026-10-21 18:06:45'),
(597,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND%0b1=2-- -','0c32e1c5-e4c7-4b57-aff4-05a7e3e8fe37','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:46','2026-10-21 18:06:46'),
(598,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' /*!AND*/ 1=2-- -','074618a9-70c7-42dc-85ba-87a8d940848b','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:46','2026-10-21 18:06:46'),
(599,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' UnIoN SeLeCt 1 WHERE 1=2-- -','10b2fe2a-e5cb-4bb8-8ddf-f4add4fec82a','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:46','2026-10-21 18:06:46'),
(600,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'1\'!=\'2','c061bac1-c137-4394-a79e-16c56897e33a','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:47','2026-10-21 18:06:47'),
(601,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 3-2=1-- -','cfee518e-40e3-49b7-a5c9-fc1bacd3c09d','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:48','2026-10-21 18:06:48'),
(602,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR NOT 1=2-- -','d5584725-5b3f-4487-90c2-55291fec7673','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:48','2026-10-21 18:06:48'),
(603,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND+1=2-- -','605bece6-533a-49e9-b6d9-558eaebbc8e9','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:49','2026-10-21 18:06:49'),
(604,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2.0-- -','dc381fd3-4b22-490b-b6b3-149b2097a891','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:49','2026-10-21 18:06:49'),
(605,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 10%3=1-- -','79a331e3-d39f-4ece-a1bf-fb510afdce9b','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:49','2026-10-21 18:06:49'),
(606,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 2*2=4-- -','514f57c9-6bc8-4ccb-91b5-fb13ae692758','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:49','2026-10-21 18:06:49'),
(607,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR ABS(-1)=1-- -','2f16455a-4cdf-41e4-9f5b-c47c0131af19','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:50','2026-10-21 18:06:50'),
(608,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'1\'!=\'1','2516dbc7-cabc-4e3d-8981-a6ed0571a63a','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:50','2026-10-21 18:06:50'),
(609,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 3-2=2-- -','259b685c-9cda-453d-9f03-88272844f324','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:51','2026-10-21 18:06:51'),
(610,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR NOT 1=1-- -','b7509404-c058-4712-8432-a2ef349ed708','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:52','2026-10-21 18:06:52'),
(611,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR ASCII(\'a\')=97-- -','88d47915-68e5-4ac7-b766-c95f15de685d','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:52','2026-10-21 18:06:52'),
(612,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR LENGTH(\'a\')=1-- -','c0640e2b-0d02-48fe-b1c7-624e570d33cf','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:52','2026-10-21 18:06:52'),
(613,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 2*2=5-- -','778f3ebc-eee8-4fac-b4ef-95cf896d02f0','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:53','2026-10-21 18:06:53'),
(614,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 10%3=2-- -','49993480-6c9b-4793-9658-124716a5ea1e','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:53','2026-10-21 18:06:53'),
(615,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR CHAR_LENGTH(\'a\')=1-- -','58e22b0f-2d1a-4ee8-a842-f6c646aeb637','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:54','2026-10-21 18:06:54'),
(616,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR ABS(-1)=2-- -','3eeb1ca1-d4b9-4fd9-9cfd-0df56c03f19b','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:54','2026-10-21 18:06:54'),
(617,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR POWER(2,1)=2-- -','10238f2f-b0a3-416d-bab5-c48715a29333','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:54','2026-10-21 18:06:54'),
(618,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR SQRT(4)=2-- -','c265f7f8-1822-4dde-9a70-b0b2364a658d','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:55','2026-10-21 18:06:55'),
(619,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR ASCII(\'a\')=98-- -','48095e21-7e50-487a-89ad-8d0eb781a290','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:55','2026-10-21 18:06:55'),
(620,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR LENGTH(\'a\')=2-- -','d514e883-49bb-4702-af19-88833400f91c','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:56','2026-10-21 18:06:56'),
(621,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR CEIL(1.5)=2-- -','d6294ca5-847a-43f5-9d96-ba58fd56f6eb','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:57','2026-10-21 18:06:57'),
(622,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR FLOOR(1.5)=1-- -','239e01dd-37a6-4e2c-93f0-1a4bd5d901ea','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:57','2026-10-21 18:06:57'),
(623,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR ROUND(1.4)=1-- -','b9359adf-a617-4433-a659-50fc11a9582f','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:58','2026-10-21 18:06:58'),
(624,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR CHAR_LENGTH(\'a\')=2-- -','01ce8405-de85-4220-bf75-300046251a24','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:58','2026-10-21 18:06:58'),
(625,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR POWER(2,1)=3-- -','bc5d5b38-7ed8-4ca2-a5d8-3c45039c602a','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:58','2026-10-21 18:06:58'),
(626,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR SQRT(4)=3-- -','e52a0f1d-0533-4b5c-a280-c42a96d5a814','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:59','2026-10-21 18:06:59'),
(627,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 5/5=1-- -','c7ae106b-04c1-49a0-ad71-b24c408a3e33','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:59','2026-10-21 18:06:59'),
(628,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR FLOOR(1.5)=2-- -','e32f7063-89bb-4789-95ed-52793d75c73b','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:06:59','2026-10-21 18:06:59'),
(629,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR CEIL(1.5)=3-- -','8e2fbf80-b3f1-4c76-88dc-6c5aec998eea','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:00','2026-10-21 18:07:00'),
(630,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1<<1=2-- -','09fcc84c-7fe3-47ef-840e-3c196db00357','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:00','2026-10-21 18:07:00'),
(631,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR ROUND(1.4)=2-- -','c956c27c-74b9-4e04-ae89-7b004dfe225d','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:01','2026-10-21 18:07:01'),
(632,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1&1=1-- -','713eaec1-abc7-4094-93b7-7164edda6aa2','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:02','2026-10-21 18:07:02'),
(633,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 2>>1=1-- -','3409ecbb-5913-4693-aff5-2d1ff96a422d','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:02','2026-10-21 18:07:02'),
(634,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com1\' OR \'1\'=\'1','bbf83b97-1f2c-4de6-8026-482eb0866fce','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:03','2026-10-21 18:07:03'),
(635,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 5/5=2-- -','9da3659b-621f-4988-85b6-03929ac9fd8a','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:03','2026-10-21 18:07:03'),
(636,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com1) OR (1=1','1260c4af-74a6-4d36-a119-508dbf45bcb6','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:03','2026-10-21 18:07:03'),
(637,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1|0=1-- -','1baf42a6-791c-4fb5-97c4-2827defee503','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:03','2026-10-21 18:07:03'),
(638,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1<<1=3-- -','8f3156ac-bf52-4758-846d-bc12b11e1ceb','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:04','2026-10-21 18:07:04'),
(639,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com1\' OR \'1\'=\'1\' #','a6b791af-633c-4628-a01e-8ddf60899310','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:05','2026-10-21 18:07:05'),
(640,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1&1=0-- -','9a04fcbd-2475-48c6-99e3-c890b7205230','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:05','2026-10-21 18:07:05'),
(641,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 2>>1=2-- -','540bebea-7d55-4d10-9f0c-32671c3ac9d4','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:06','2026-10-21 18:07:06'),
(642,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com1\' AND \'1\'=\'2','f293a3cd-ad8d-4511-9c0d-2e5f051f44d0','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:07','2026-10-21 18:07:07'),
(643,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com0 OR 1=1','15c14af0-4164-47d6-93f0-d58c5016a045','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:07','2026-10-21 18:07:07'),
(644,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com1) AND (1=2','6eee74e0-84b0-48e5-bb41-f76ee8b67ef9','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:07','2026-10-21 18:07:07'),
(645,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1|0=0-- -','360ee2ee-2bda-4131-9a60-688ff024ac1b','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:07','2026-10-21 18:07:07'),
(646,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com-1 OR 1=1','5db9ccee-8ec6-4220-a16f-cbaf2ebf7347','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:08','2026-10-21 18:07:08'),
(647,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com1\' AND \'1\'=\'2\' #','53e2e673-85d1-4fb1-b3f1-a41c9c9e8880','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:08','2026-10-21 18:07:08'),
(648,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com999999 OR 1=1','ec329e4e-979a-4b43-8db5-95123880f13e','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:09','2026-10-21 18:07:09'),
(649,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com0 OR 1=2','92570dbc-34b2-476c-9a4e-36cb03aad143','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:09','2026-10-21 18:07:09'),
(650,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com1 OR 1=1 LIMIT 1,1-- -','b911d8e7-e250-4a4d-aea0-e12218dbe5e4','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:10','2026-10-21 18:07:10'),
(651,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com1\' OR 1=1 ORDER BY 1-- -','d2560f32-8074-48e4-aa5a-b10f8c5eb6b5','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:10','2026-10-21 18:07:10'),
(652,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' ORDER BY 1-- -','64c65b5e-d033-46d5-966a-8a88ed9eb22e','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:11','2026-10-21 18:07:11'),
(653,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' ORDER BY (SELECT 1)-- -','b451d179-a1ed-4062-88f4-735c6b7db681','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:11','2026-10-21 18:07:11'),
(654,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com-1 OR 1=2','b3c4bc0a-4a76-4ca1-88a8-24fd7434ee82','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:12','2026-10-21 18:07:12'),
(655,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' ORDER BY 1 ASC-- -','ab0b1935-d2f7-4ab4-971c-b0802ce9b6a2','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:12','2026-10-21 18:07:12'),
(656,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com999999 OR 1=2','13278f42-5068-4d85-a4a1-2caa576ca65e','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:12','2026-10-21 18:07:12'),
(657,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' ORDER BY 1 DESC-- -','20e07277-e51f-4ea5-9816-c0109943f583','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:13','2026-10-21 18:07:13'),
(658,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com1 OR 1=2 LIMIT 1,1-- -','bdef06ca-8954-4fe4-931d-da2a04010125','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:13','2026-10-21 18:07:13'),
(659,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com1\' AND 1=2 ORDER BY 1-- -','363bfc2c-5597-485a-80e4-1a7a3943166e','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:13','2026-10-21 18:07:13'),
(660,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR CONCAT(\'a\',\'b\')=\'ab\'-- -','deca4d0b-ff96-478e-b2cc-b424ea83726a','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:14','2026-10-21 18:07:14'),
(661,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' ORDER BY (SELECT 1 WHERE 1=2)-- -','cec0eded-bcbe-4e09-a960-135c684dcd9e','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:14','2026-10-21 18:07:14'),
(662,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' ORDER BY 999999-- -','330e1e77-352e-4f39-9209-698bff5b4baf','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:15','2026-10-21 18:07:15'),
(663,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' ORDER BY 999999 ASC-- -','b4f0060f-32ab-4a02-bf88-1002b9a18496','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:16','2026-10-21 18:07:16'),
(664,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'a\'||\'b\'=\'ab\'-- -','4afcd924-5832-4d28-bf94-0a57eef0f7bb','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:16','2026-10-21 18:07:16'),
(665,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' ORDER BY 999999 DESC-- -','eacd98c0-8c08-46b5-98e4-494de19e3e40','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:17','2026-10-21 18:07:17'),
(666,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR JSON_EXTRACT(\'{\"a\":1}\',\'$.a\')=1-- -','3963a2ad-be15-4e4e-be18-787bbc8c32f0','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:17','2026-10-21 18:07:17'),
(667,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'a\'+\'b\'=\'ab\'-- -','0c177eb9-93f5-4641-a721-dac89085b888','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:17','2026-10-21 18:07:17'),
(668,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR CONCAT(\'a\',\'b\')=\'ac\'-- -','337f9312-245a-451f-b223-943f944e1a4f','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:18','2026-10-21 18:07:18'),
(669,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'{\"a\":1}\'::json->>\'a\'=\'1\'-- -','82a355ec-249b-4e06-ac0a-d65b44616b30','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:18','2026-10-21 18:07:18'),
(670,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR EXTRACTVALUE(1,\'/a\')=\'/a\'-- -','a28a8997-b92b-4357-8004-7af928d33a43','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:18','2026-10-21 18:07:18'),
(671,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'abc\' REGEXP \'^a\'-- -','fc1bda3b-a902-40d1-88e2-564b38f39a8d','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:19','2026-10-21 18:07:19'),
(672,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'a\'||\'b\'=\'ac\'-- -','cac2f21f-13c9-4d2a-8e6f-cc1999843457','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:19','2026-10-21 18:07:19'),
(673,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'abc\' ~ \'^a\'-- -','266b67eb-2b9f-45a7-a6de-9599ef1832a9','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:20','2026-10-21 18:07:20'),
(674,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR JSON_EXTRACT(\'{\"a\":1}\',\'$.a\')=2-- -','1b152ffd-ffe3-42fd-95ed-105f3554ea31','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:21','2026-10-21 18:07:21'),
(675,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'a\'+\'b\'=\'ac\'-- -','897d99d7-d08a-4df0-8f9e-3c41e61b6141','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:21','2026-10-21 18:07:21'),
(676,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'abc\' SIMILAR TO \'a%\'-- -','86322d21-1ae4-4c9e-9f96-b92d31a37e0c','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:22','2026-10-21 18:07:22'),
(677,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'{\"a\":1}\'::json->>\'a\'=\'2\'-- -','f0bfc19c-eb0d-4d21-95cb-3b132a1f3b31','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:22','2026-10-21 18:07:22'),
(678,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR EXTRACTVALUE(1,\'/a\')=\'/b\'-- -','186350a1-63d1-4d3c-a62e-23cdff3cd72b','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:22','2026-10-21 18:07:22'),
(679,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'abc\' REGEXP \'^z\'-- -','ec1878b8-3805-45ad-aee3-6d788471c0d1','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:22','2026-10-21 18:07:22'),
(680,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'abc\' RLIKE \'^a\'-- -','3618ce32-1bd3-4a18-be44-d991ac2412e9','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:23','2026-10-21 18:07:23'),
(681,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'abc\' ~ \'^z\'-- -','fe27d353-9491-4918-a5b5-9438e5632404','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:23','2026-10-21 18:07:23'),
(682,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 BETWEEN 0 AND 2-- -','2dc0e084-0236-43b8-8a7c-3c19dd02716d','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:24','2026-10-21 18:07:24'),
(683,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 IN (1,2,3)-- -','a51ac985-eabe-415d-9cab-c5546b6f5ed7','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:24','2026-10-21 18:07:24'),
(684,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'abc\' SIMILAR TO \'z%\'-- -','88faeee5-0abf-41da-9e67-01688e97b0a7','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:25','2026-10-21 18:07:25'),
(685,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 NOT IN (4,5,6)-- -','d7bfa9f7-2bea-4bb2-897d-82a9e9f8f853','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:26','2026-10-21 18:07:26'),
(686,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'a\' IN (\'a\',\'b\')-- -','b78d3b0f-7a10-41f8-a33c-f2ad7b7ccef8','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:26','2026-10-21 18:07:26'),
(687,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR NULL IS NULL-- -','b5881dc6-8c43-4bf1-a032-c6717db51695','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:26','2026-10-21 18:07:26'),
(688,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'abc\' RLIKE \'^z\'-- -','2fe5da1a-e95a-4f86-9c59-fbaab9f2c3af','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:27','2026-10-21 18:07:27'),
(689,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 IS NOT NULL-- -','417a78ea-6f82-41ff-ad2e-41a9251a4cdc','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:27','2026-10-21 18:07:27'),
(690,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 BETWEEN 2 AND 3-- -','9b0a9d7a-c84f-42ac-9932-ecdbedd64020','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:27','2026-10-21 18:07:27'),
(691,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 IN (4,5,6)-- -','f4fd8581-11cd-403d-a2c7-637f07084837','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:28','2026-10-21 18:07:28'),
(692,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 NOT IN (1,2,3)-- -','07e784de-c1e8-45a4-8b76-9f620f2e8b59','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:28','2026-10-21 18:07:28'),
(693,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'a\' IN (\'x\',\'y\')-- -','ce32841a-ac56-405b-9c5a-5df43c93df8c','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:28','2026-10-21 18:07:28'),
(694,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR ISNULL(1,1)=1-- -','fdd9460c-3bf1-4ef7-a953-bf73a3dfe5a5','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:29','2026-10-21 18:07:29'),
(695,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 IS NULL-- -','616f81fc-6ec2-4be6-ac3e-962819262283','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:30','2026-10-21 18:07:30'),
(696,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR NULL IS NOT NULL-- -','64a2862b-6294-4aab-8dcc-900b25acb5ee','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:31','2026-10-21 18:07:31'),
(697,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR x\'31\'=x\'31\'-- -','c9124770-853f-4b3c-b0c8-f88093019f9a','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:31','2026-10-21 18:07:31'),
(698,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 0x31=0x31-- -','26a1c81b-8b1c-4788-a0be-ee0a33cf9b28','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:31','2026-10-21 18:07:31'),
(699,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 0b1=0b1-- -','c2323526-c529-436d-8b5d-901da08e8f63','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:31','2026-10-21 18:07:31'),
(700,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=CONV(\'1\',2,10)-- -','e5277247-647a-468b-8a91-edf4fa24c853','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:32','2026-10-21 18:07:32'),
(701,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR UNHEX(\'31\')=\'1\'-- -','cd95494e-1e7a-4729-8dac-e81d1b0be59b','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:32','2026-10-21 18:07:32'),
(702,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR ISNULL(NULL,2)=1-- -','6611ed4b-35a7-4f31-9333-d6f42d0995ca','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:33','2026-10-21 18:07:33'),
(703,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR HEX(\'1\')=\'31\'-- -','3708f418-a136-48ba-a34c-3e566702997d','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:33','2026-10-21 18:07:33'),
(704,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR x\'31\'=x\'32\'-- -','2e24c715-14d0-4f78-9c84-0df6c59d0136','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:34','2026-10-21 18:07:34'),
(705,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR CURDATE()=CURDATE()-- -','a6c8ef2d-b4d7-443c-9e70-1e4d15e880ac','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:34','2026-10-21 18:07:34'),
(706,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 0x31=0x32-- -','59743418-7e6c-45f2-8aaf-d2f0b3d7e363','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:35','2026-10-21 18:07:35'),
(707,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 0b1=0b0-- -','11f85c78-2edc-4cdc-8d1e-5b1a59e6af2e','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:36','2026-10-21 18:07:36'),
(708,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=CONV(\'10\',2,10)-- -','de3e68d8-13e8-4bba-b267-dd9ce2a18afb','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:36','2026-10-21 18:07:36'),
(709,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR UNHEX(\'31\')=\'2\'-- -','78b55575-1e9d-4f53-86cc-fe7f7ca7015f','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:36','2026-10-21 18:07:36'),
(710,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR DATEDIFF(NOW(),NOW())=0-- -','587bd7c7-7171-402a-9f84-9c92e0ea1170','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:37','2026-10-21 18:07:37'),
(711,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR HEX(\'1\')=\'32\'-- -','9157300c-e6da-4998-9eeb-141fe52b539f','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:37','2026-10-21 18:07:37'),
(712,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR EXTRACT(YEAR FROM NOW())>0-- -','93d83dde-5ad9-4f37-bca4-2e4ba4c6f779','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:38','2026-10-21 18:07:38'),
(713,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR CURDATE()!=CURDATE()-- -','0ff7eb2c-8a35-4ac2-93cd-31628723e2a6','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:38','2026-10-21 18:07:38'),
(714,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=ANY(SELECT 1)-- -','32d7004d-bb57-4806-b8af-2cedf3112d0f','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:39','2026-10-21 18:07:39'),
(715,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=ALL(SELECT 1)-- -','529ce746-b70e-421b-b84e-7a2df5e550aa','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:39','2026-10-21 18:07:39'),
(716,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR MATCH(\'a\') AGAINST(\'a\')-- -','4c4f5aab-2b92-46a9-93a9-ced24addc681','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:40','2026-10-21 18:07:40'),
(717,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com%27%20OR%20%271%27%3D%271','25e15cc0-2815-4761-9071-15f7313c3a2d','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:41','2026-10-21 18:07:41'),
(718,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR DATEDIFF(NOW(),NOW())=1-- -','0c53dc39-9117-4e7d-938c-7f3b11877894','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:41','2026-10-21 18:07:41'),
(719,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com%2527%2520OR%2520%25271%2527%253D%25271','b0ec6a2e-f264-4581-98cf-c78444e1b7d6','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:41','2026-10-21 18:07:41'),
(720,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR EXTRACT(YEAR FROM NOW())<0-- -','aa7f9d33-8196-4409-91ef-b6afd816f16d','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:42','2026-10-21 18:07:42'),
(721,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' /*!50000OR*/ 1=1-- -','710fc03d-9a80-44ee-85a2-2ca9be14161e','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:42','2026-10-21 18:07:42'),
(722,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=ANY(SELECT 2)-- -','7bbf1cad-3aff-4e46-840d-48232cf5efde','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:43','2026-10-21 18:07:43'),
(723,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 2=ALL(SELECT 1)-- -','d3eb242a-25d1-4d5e-8ecc-c3945757e2fe','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:44','2026-10-21 18:07:44'),
(724,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com%27%20AND%20%271%27%3D%272','ac022a4a-a1b9-4b63-95e9-f26191d6ba8b','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:44','2026-10-21 18:07:44'),
(725,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR MATCH(\'a\') AGAINST(\'z\')-- -','d91ed5ad-9dad-4aec-87d5-690cb9ff3dc0','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:44','2026-10-21 18:07:44'),
(726,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR/**/1/**/=/**/1-- -','dc26710a-f2d9-4e0f-89cd-a942c74493c5','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:45','2026-10-21 18:07:45'),
(727,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com%2527%2520AND%2520%25271%2527%253D%25272','30626523-b2cf-47ec-8970-a9832e853eda','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:46','2026-10-21 18:07:46'),
(728,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' /*!50000AND*/ 1=2-- -','5aebee22-4e35-464d-aedf-ec23f64e2760','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:46','2026-10-21 18:07:46'),
(729,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR STRCMP(\'a\',\'a\')=0-- -','0ebf8f34-ee40-4c22-8702-cdd335fdd000','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:47','2026-10-21 18:07:47'),
(730,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com¿\' OR \'1\'=\'1','60515bc6-4239-4e2f-962f-cc2c208b6b9c','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:47','2026-10-21 18:07:47'),
(731,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR SUBSTRING(\'abc\',1,1)=\'a\'-- -','c06d5fc5-ce97-4fc4-90cf-880aad1f4122','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:48','2026-10-21 18:07:48'),
(732,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com%bf%27 OR %271%27=%271','b539e10c-7cfa-4123-9b8b-0192a498d336','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:48','2026-10-21 18:07:48'),
(733,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR SUBSTR(\'abc\',1,1)=\'a\'-- -','8cf147e5-944b-4b55-b71d-6e8dbd6f1993','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:48','2026-10-21 18:07:48'),
(734,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND/**/1/**/=/**/2-- -','daccd48f-1cff-4417-83ab-5e5dd62347e2','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:49','2026-10-21 18:07:49'),
(735,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR LEFT(\'abc\',1)=\'a\'-- -','b83606d6-0ce6-4329-ad4a-b2b228620e9c','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:49','2026-10-21 18:07:49'),
(736,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR STRCMP(\'a\',\'b\')=0-- -','42920f16-ebfc-4dd0-bedc-2cc1d9aa7d53','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:50','2026-10-21 18:07:50'),
(737,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR RIGHT(\'abc\',1)=\'c\'-- -','bc8ea031-3077-4453-87b3-9e71676a255f','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:50','2026-10-21 18:07:50'),
(738,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com¿\' AND \'1\'=\'2','426f3dfe-73a9-4209-8954-ab9230c421bc','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:51','2026-10-21 18:07:51'),
(739,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR SUBSTRING(\'abc\',1,1)=\'z\'-- -','55619801-9712-4bfc-918c-c59f5ad53224','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:52','2026-10-21 18:07:52'),
(740,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com%bf%27 AND %271%27=%272','b740a723-4bc4-4d9b-9717-3aad464d4547','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:52','2026-10-21 18:07:52'),
(741,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR SUBSTR(\'abc\',1,1)=\'z\'-- -','18676e2c-77a6-455d-bcd8-e4431c710e16','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:52','2026-10-21 18:07:52'),
(742,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR LEFT(\'abc\',1)=\'z\'-- -','1dc1cdbd-2a8f-45d9-b986-0d6511464c78','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:53','2026-10-21 18:07:53'),
(743,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR UPPER(\'a\')=\'A\'-- -','f647f0e9-5c91-44ac-8b38-6652678fc1b4','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:53','2026-10-21 18:07:53'),
(744,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR RIGHT(\'abc\',1)=\'z\'-- -','2c0f3237-7db0-4f51-857a-b4518b43dada','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:53','2026-10-21 18:07:53'),
(745,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR LOWER(\'A\')=\'a\'-- -','7c73b653-9b26-4291-b2e1-8fbe02cfaaac','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:53','2026-10-21 18:07:53'),
(746,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR TRIM(\' a \')=\'a\'-- -','5137e9ab-c5f2-479b-b11c-aa9eff2e9bd0','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:54','2026-10-21 18:07:54'),
(747,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR REVERSE(\'ab\')=\'ba\'-- -','3f8f4cb5-f4d8-4330-baa6-01adc0838e66','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:54','2026-10-21 18:07:54'),
(748,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR REPLACE(\'abc\',\'b\',\'x\')=\'axc\'-- -','7b98cad2-252d-4f3d-9b2b-f040f9d290e0','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:56','2026-10-21 18:07:56'),
(749,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR COUNT(*)>=0-- -','aac17372-2eda-412e-9316-ce261b1605a0','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:56','2026-10-21 18:07:56'),
(750,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR GROUP_CONCAT(1)=1-- -','c5ebcca8-35ae-404e-9476-25a491e469a8','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:56','2026-10-21 18:07:56'),
(751,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR UPPER(\'a\')=\'Z\'-- -','7529964d-812e-44d1-8843-1c074ae39813','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:57','2026-10-21 18:07:57'),
(752,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR LOWER(\'A\')=\'z\'-- -','2ced86ba-88aa-4c1e-9ab7-afe28e27cf23','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:57','2026-10-21 18:07:57'),
(753,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR SUM(1)=1-- -','dc49473a-5613-477f-87e8-2d8b3b486b56','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:57','2026-10-21 18:07:57'),
(754,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR REVERSE(\'ab\')=\'ab\'-- -','a8f97c8f-5484-4162-af45-8b205f05b84c','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:58','2026-10-21 18:07:58'),
(755,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR TRIM(\' a \')=\'z\'-- -','2b0e7c7b-f16a-46b4-ae4f-93f545d0214e','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:58','2026-10-21 18:07:58'),
(756,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR REPLACE(\'abc\',\'b\',\'x\')=\'abc\'-- -','8b30d625-2704-4b91-812f-2d62bb8c2062','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:59','2026-10-21 18:07:59'),
(757,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR COUNT(*)<0-- -','7b38902e-d28e-444f-964e-f60329e90b57','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:07:59','2026-10-21 18:07:59'),
(758,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR GROUP_CONCAT(1)=2-- -','8ec1410a-efac-4a81-a3f9-93085fe7af9a','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:01','2026-10-21 18:08:01'),
(759,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR MAX(1)=1-- -','c25f8313-b434-4d98-a3c6-1fb9fc69b8fa','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:01','2026-10-21 18:08:01'),
(760,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR SUM(1)=2-- -','5dbf61c6-8664-4db6-95d1-50dfeea268a4','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:01','2026-10-21 18:08:01'),
(761,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR MIN(1)=1-- -','1337178e-0065-4df9-b214-30a6dcf97ef4','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:02','2026-10-21 18:08:02'),
(762,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR AVG(1)=1-- -','25347c34-0db1-4650-b8fe-e59c8346f7c7','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:02','2026-10-21 18:08:02'),
(763,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com1 ORDER BY (CASE WHEN 1=1 THEN 1 ELSE 1/0 END)-- -','eb8774b0-c822-4c4d-9baa-e0ee7aa15ba7','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:02','2026-10-21 18:08:02'),
(764,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'%a0OR%a01=1-- -','fb8b18f1-b103-4761-89dc-d61f9fa99016','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:03','2026-10-21 18:08:03'),
(765,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'%0cOR%0c1=1-- -','ac71e6e6-2c91-4752-b2b6-d8e946a7a30f','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:03','2026-10-21 18:08:03'),
(766,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR ROW_NUMBER() OVER (ORDER BY 1)=1-- -','a15e3d6f-d11f-492c-9222-cd4213046783','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:04','2026-10-21 18:08:04'),
(767,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR MAX(1)=2-- -','1c83f1de-9afe-49d8-aabe-29a8475d543e','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:04','2026-10-21 18:08:04'),
(768,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR RANK() OVER (ORDER BY 1)=1-- -','0a9d6b62-92b7-4b22-9c69-f66dce569794','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:05','2026-10-21 18:08:05'),
(769,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR MIN(1)=2-- -','edb2bf69-a6ac-42a2-a440-1ed1ffe81323','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:06','2026-10-21 18:08:06'),
(770,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR AVG(1)=2-- -','2e7554cb-c776-479c-a39e-0dce21862a03','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:06','2026-10-21 18:08:06'),
(771,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com1 ORDER BY (CASE WHEN 1=2 THEN 1 ELSE 1/0 END)-- -','5e9ff359-e731-46f7-94ed-5282cc9b3466','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:07','2026-10-21 18:08:07'),
(772,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'%a0AND%a01=2-- -','d6e4c243-3ad2-4c3c-8a41-6f984f187916','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:07','2026-10-21 18:08:07'),
(773,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'%0cAND%0c1=2-- -','cdb4511f-fc75-479b-8937-82d46a66c4fe','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:07','2026-10-21 18:08:07'),
(774,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR ROW_NUMBER() OVER (ORDER BY 1)=2-- -','38af209c-07b8-4278-82d3-59f1efb9ecd7','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:07','2026-10-21 18:08:07'),
(775,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'; WITH x AS (SELECT 1) SELECT 1 FROM x WHERE 1=1-- -','9484cad6-b75d-4c60-8835-945301e1bee4','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:08','2026-10-21 18:08:08'),
(776,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR RANK() OVER (ORDER BY 1)=2-- -','1659bac9-03f0-4395-b214-b0b206601bd9','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:08','2026-10-21 18:08:08'),
(777,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR ARRAY[1,2]=ARRAY[1,2]-- -','1aa1fcb2-b054-4a8c-8e6a-36a93f6770dc','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:09','2026-10-21 18:08:09'),
(778,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=ANY(ARRAY[1,2,3])-- -','f3484f95-105d-41da-a24f-caf08df25e01','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:09','2026-10-21 18:08:09'),
(779,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (1=1 AND 1=1) OR (1=2)-- -','2b5addca-54e1-46a5-ac5f-f49f497f6b43','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:10','2026-10-21 18:08:10'),
(780,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1-- \'','2bf65a61-1566-4f9c-98f9-029267dd2962','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:11','2026-10-21 18:08:11'),
(781,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR NOT (1=1 AND 1=2)-- -','ad1f2665-54c3-4060-8d23-11a71e15ca71','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:11','2026-10-21 18:08:11'),
(782,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 2=2-- \'','2d447ca4-0486-4b8a-bad5-971e8221ca50','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:11','2026-10-21 18:08:11'),
(783,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'; WITH x AS (SELECT 1) SELECT 1 FROM x WHERE 1=2-- -','37b2098b-c1e5-4c9e-bf04-54760518eda7','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:12','2026-10-21 18:08:12'),
(784,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 3>1-- \'','72e702fa-c112-43bb-a730-b4da2c391c3e','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:12','2026-10-21 18:08:12'),
(785,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR ARRAY[1,2]=ARRAY[3,4]-- -','06a0b872-1bb3-46e6-99d4-b8a4ce54690c','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:12','2026-10-21 18:08:12'),
(786,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=ANY(ARRAY[4,5,6])-- -','9e4b0aa2-5ac5-4d7d-9bd0-253901bd22f5','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:13','2026-10-21 18:08:13'),
(787,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2-- \'','5ce41d91-35db-42c2-9702-696607870bde','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:13','2026-10-21 18:08:13'),
(788,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR NOT (1=1 AND 1=1)-- -','9c913100-f6a8-49cb-9d26-e685d62164c7','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:13','2026-10-21 18:08:13'),
(789,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (1=1 AND 1=2) OR (1=2)-- -','a99e4b26-f835-4e08-86ef-a5843096e45d','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:14','2026-10-21 18:08:14'),
(790,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 2=3-- \'','9840960d-9202-4dc9-a61f-966027fd476e','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:15','2026-10-21 18:08:15'),
(791,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" OR 1=1-- \"','8e40bb9d-e185-4d7a-992c-bb6fbceed835','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:16','2026-10-21 18:08:16'),
(792,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1>3-- \'','cab04587-a486-4422-9fd3-d10b4d6f1a82','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:16','2026-10-21 18:08:16'),
(793,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" OR 2=2-- \"','3e2761b8-020c-4c18-b969-91bdc8bcccde','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:16','2026-10-21 18:08:16'),
(794,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 5<10-- \'','6b83136a-1d6c-423e-afaf-5088a11992a8','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:17','2026-10-21 18:08:17'),
(795,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" OR 5<10-- \"','5e290217-99e6-456e-97bd-ea0a5297e022','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:17','2026-10-21 18:08:17'),
(796,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" OR 3>1-- \"','1324b490-ce7d-4741-b569-b44fe67d41b3','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:17','2026-10-21 18:08:17'),
(797,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (SELECT 1 FROM (SELECT 1) AS t)=1-- -','1e39899b-9336-4242-bb6d-b32e34e6cbcd','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:18','2026-10-21 18:08:18'),
(798,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR EXISTS(SELECT * FROM (SELECT 1) AS t)-- -','ee08e8a2-9200-4b80-858b-72f8b22cc0d8','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:18','2026-10-21 18:08:18'),
(799,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" AND 1=2-- \"','419bc3ac-a675-4018-ac24-bad89952bbdb','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:19','2026-10-21 18:08:19'),
(800,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 >= 1-- -','23348773-69a8-4cd8-9937-ae2c7d0b2881','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:20','2026-10-21 18:08:20'),
(801,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" AND 2=3-- \"','7101f47b-26a8-405a-87fd-ab24f8d66811','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:20','2026-10-21 18:08:20'),
(802,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 10<5-- \'','4c63f0b3-41d7-462d-8889-e2f69c2c4bff','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:21','2026-10-21 18:08:21'),
(803,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" AND 10<5-- \"','ae8fbaf3-e83c-4c2a-9310-2964dcb9e46e','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:21','2026-10-21 18:08:21'),
(804,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" AND 1>3-- \"','3efb6293-56ee-48d0-8b55-757aee8c8431','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:21','2026-10-21 18:08:21'),
(805,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR (SELECT 1 FROM (SELECT 1) AS t)=2-- -','957f4b56-939c-4c0a-8cd1-7c88f380dfba','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:21','2026-10-21 18:08:21'),
(806,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 <= 1-- -','a80e1872-9b69-4ab8-aeb0-3a0f199f30a7','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:22','2026-10-21 18:08:22'),
(807,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR EXISTS(SELECT * FROM (SELECT 1) AS t WHERE 1=2)-- -','9e010a22-d087-4c67-b58d-fbbab2ce2ce0','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:22','2026-10-21 18:08:22'),
(808,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 < 1-- -','af41dbdd-2bd4-423e-9dc5-36fda9048427','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:23','2026-10-21 18:08:23'),
(809,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1<>2-- -','d3dd5f74-946e-4348-9b6f-240598ffe59c','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:23','2026-10-21 18:08:23'),
(810,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'\'=\'1\'=\'1\' OR \'\'=\'','db566b02-7526-46bb-81af-93dbe96b3a14','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:24','2026-10-21 18:08:24'),
(811,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'\'=\'','6bb3ac96-a529-43c2-859a-ce5cb12dc2cf','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:24','2026-10-21 18:08:24'),
(812,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'0\'=\'0\'-- -','baf0035f-949f-4a5b-a6cc-d2ff92576127','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:25','2026-10-21 18:08:25'),
(813,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'true\'=\'true\'-- -','35de8d4b-76bf-4185-9d1f-3f2c37e3fd74','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:25','2026-10-21 18:08:25'),
(814,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'\' = \'\'-- -','921b2da7-0728-48b6-8986-38d326f06f7e','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:26','2026-10-21 18:08:26'),
(815,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1 > 1-- -','0ed20464-3922-4935-8d3d-03b4513be760','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:26','2026-10-21 18:08:26'),
(816,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1 WAITFOR DELAY \'0:0:0\'-- -','fa25dbb5-0ca9-4d31-bce2-d75ba890ba9e','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:27','2026-10-21 18:08:27'),
(817,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1<>1-- -','cc9bc220-a110-4374-b66b-81347650e094','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:27','2026-10-21 18:08:27'),
(818,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'\'=\'1\'=\'2\' AND \'\'=\'','428ec7f7-dbe9-4a87-a3e3-a30057db4a32','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:28','2026-10-21 18:08:28'),
(819,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'true\'=\'false\'-- -','c75c74db-c53b-42b8-aba9-2fe75dec4884','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:28','2026-10-21 18:08:28'),
(820,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'\' = \'x\'-- -','99650219-35f3-4dde-9e06-7fef8d9c8bd3','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:28','2026-10-21 18:08:28'),
(821,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND \'\'=\'x','7023581c-cca4-441b-9f73-0d492e24ebef','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:29','2026-10-21 18:08:29'),
(822,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR \'0\'=\'1\'-- -','bb5755e1-704a-4415-97e5-9d16bc816089','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:29','2026-10-21 18:08:29'),
(823,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR @@VERSION IS NOT NULL-- -','343483a3-bddc-4c6a-b4c6-87549fd2a294','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:30','2026-10-21 18:08:30'),
(824,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR SYSDATE=SYSDATE-- -','366cb044-3d86-4cac-8ffc-9f0e3c21d39c','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:31','2026-10-21 18:08:31'),
(825,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' OR 1=1 AND ROWNUM<=1-- -','2e869a19-6658-44ad-9194-f8f5e365faad','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:31','2026-10-21 18:08:31'),
(826,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND @@VERSION IS NULL-- -','ecf02894-6d6c-4339-b872-55cd21cb3106','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:32','2026-10-21 18:08:32'),
(827,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2 WAITFOR DELAY \'0:0:0\'-- -','1647d170-30eb-41fb-adc2-f4e66175cef4','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:32','2026-10-21 18:08:32'),
(828,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND 1=2 AND ROWNUM<=1-- -','b3ca65ed-80a6-4479-a643-aea8c44b0f12','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:33','2026-10-21 18:08:33'),
(829,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' AND SYSDATE!=SYSDATE-- -','b1c05935-dffe-4fc9-9a11-4dd1de6a05ba','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:33','2026-10-21 18:08:33'),
(830,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','bccc8e8b-cf9e-46d1-be0b-c36910df7a2e','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:34','2026-10-21 18:08:34'),
(831,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9ce71df1-c6da-4023-b85d-dadbf1ad615e','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:35','2026-10-21 18:08:35'),
(832,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','53253a3c-1747-40ca-ba43-a046a0c3411a','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:36','2026-10-21 18:08:36'),
(833,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4aec4c7c-2520-419f-8923-5b10f2c869ff','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:36','2026-10-21 18:08:36'),
(834,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','2829688a-d624-420f-a7e3-092570aaa851','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:36','2026-10-21 18:08:36'),
(835,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f0c3881b-f274-4e17-871f-38a810501fcf','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:36','2026-10-21 18:08:36'),
(836,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','2f35285b-6507-4881-aeba-495a33f9672c','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:38','2026-10-21 18:08:38'),
(837,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e2846538-b430-490e-a6a1-e6fc3603f40a','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:38','2026-10-21 18:08:38'),
(838,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4f6869d5-1815-40d2-89b1-0e555278c85d','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:38','2026-10-21 18:08:38'),
(839,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','fd24dff5-9718-47b0-abb1-e998cfbd6654','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:38','2026-10-21 18:08:38'),
(840,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8a875054-9434-49a6-a573-fd3edae2567a','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:39','2026-10-21 18:08:39'),
(841,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','76e4c9fb-2b50-4cbf-87ce-e8a3dcb70b20','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:39','2026-10-21 18:08:39'),
(842,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','886b182a-494f-47bd-8367-3b5178d57c0d','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:41','2026-10-21 18:08:41'),
(843,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8dd404dc-f7d4-4351-bcad-3ee92b53cf54','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:41','2026-10-21 18:08:41'),
(844,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','cdc48252-6481-4b10-8446-711e1da430df','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:42','2026-10-21 18:08:42'),
(845,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a0642ae6-c72b-4d25-87da-83383b8cebd2','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:42','2026-10-21 18:08:42'),
(846,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8bc3ab4f-1a42-4797-bca4-b2c6d6070eb6','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:42','2026-10-21 18:08:42'),
(847,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f1d69c04-6a95-4556-883c-d4e47ad82a65','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:42','2026-10-21 18:08:42'),
(848,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','953b57f1-887b-4274-914c-e6398cbbdee2','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:43','2026-10-21 18:08:43'),
(849,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7979d254-d52e-44f9-ab06-925200ab5e68','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:43','2026-10-21 18:08:43'),
(850,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','73a0fb97-03b9-4ceb-8f24-e6191cde329d','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:44','2026-10-21 18:08:44'),
(851,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6a6cf5e2-5f48-4913-b974-3341f0ccb03e','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:44','2026-10-21 18:08:44'),
(852,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9cc048c2-8223-4b82-8188-cfed6a845191','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:45','2026-10-21 18:08:45'),
(853,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f5e444aa-f414-42cf-9e5a-f642e3c4d07c','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:46','2026-10-21 18:08:46'),
(854,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','bac80b5a-b82b-4ec4-a95a-aad1ec439c21','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:46','2026-10-21 18:08:46'),
(855,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','531b5212-71f0-4795-b12e-d26b22a19530','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:46','2026-10-21 18:08:46'),
(856,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c0ac47f0-b32d-43fb-983e-195c528e2d59','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:47','2026-10-21 18:08:47'),
(857,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','95df3ef8-2edd-4c3e-a046-1012fde61df4','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:47','2026-10-21 18:08:47'),
(858,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c9e1918b-f578-440c-8a49-5a3932019dce','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:48','2026-10-21 18:08:48'),
(859,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','46b9433a-1927-4cbd-80c4-876a7c8160a8','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:48','2026-10-21 18:08:48'),
(860,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4e5ad3bd-644c-4198-b39e-c5402c1dd1cc','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:49','2026-10-21 18:08:49'),
(861,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5852153f-a1a0-4c4b-a45f-798dd743feed','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:49','2026-10-21 18:08:49'),
(862,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9a6d2ff4-cece-43b8-89ab-4382bb613158','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:49','2026-10-21 18:08:49'),
(863,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6de9e887-7de3-4bd1-b05f-717deac3fdfb','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:50','2026-10-21 18:08:50'),
(864,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','467b5ab2-4302-4719-8408-be2585127b88','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:51','2026-10-21 18:08:51'),
(865,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','2264184c-3985-4541-8bb3-657cdec1052d','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:51','2026-10-21 18:08:51'),
(866,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a10c8975-a252-454d-a0d2-c382d205f4f7','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:52','2026-10-21 18:08:52'),
(867,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','58bf3e81-568a-42d2-af7e-0c3ab1b5971b','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:52','2026-10-21 18:08:52'),
(868,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','72d9b22a-3173-44a7-b190-2f6fee33662a','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:52','2026-10-21 18:08:52'),
(869,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','63d323c2-99f5-49b1-bf20-e0d693daf3fd','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:52','2026-10-21 18:08:52'),
(870,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8109e140-cc53-4e2a-ab35-921329a6a5ab','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:53','2026-10-21 18:08:53'),
(871,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c8985f43-185c-47af-b6fe-478cf0c1486a','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:53','2026-10-21 18:08:53'),
(872,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0667919d-08ac-46b4-ada3-4bd9453b1a0c','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:54','2026-10-21 18:08:54'),
(873,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','70bed9aa-5e8b-4dcc-87f6-3cbfcae7e917','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:55','2026-10-21 18:08:55'),
(874,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1c7c70a7-a335-4619-8543-25240edcf657','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:55','2026-10-21 18:08:55'),
(875,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ce513788-9299-4bb0-8865-e6c6d52ca64c','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:56','2026-10-21 18:08:56'),
(876,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0e3f2e16-8662-40ed-a4cd-e7c4f055aced','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:56','2026-10-21 18:08:56'),
(877,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','56fc3b45-38fb-4967-8f0e-914b5f488177','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:56','2026-10-21 18:08:56'),
(878,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','96a31c37-d622-45f6-84fa-b287ffaf0bbf','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:57','2026-10-21 18:08:57'),
(879,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','db11b9b1-075d-4558-b6b8-003460f11846','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:57','2026-10-21 18:08:57'),
(880,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e99e6f3f-72d8-4297-be7b-68d2bed66046','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:58','2026-10-21 18:08:58'),
(881,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','99f30fa9-5b25-4abf-8ad4-17da50686c15','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:58','2026-10-21 18:08:58'),
(882,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','95db5193-fbb6-4b17-a59a-5981db33783e','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:59','2026-10-21 18:08:59'),
(883,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','37601ab7-cc58-405b-80ad-9bafdc6bf539','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:08:59','2026-10-21 18:08:59'),
(884,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f299bc0f-b656-4752-af74-26c26adaf932','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:00','2026-10-21 18:09:00'),
(885,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','79c33f5b-2f43-4f04-b08a-40dbee1fcd87','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:00','2026-10-21 18:09:00'),
(886,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','40a1063b-7532-42f7-a9eb-814474af3443','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:01','2026-10-21 18:09:01'),
(887,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','74543282-d16a-4be0-8975-1d11b6547168','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:01','2026-10-21 18:09:01'),
(888,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c09140d8-2e98-42a9-9bab-5b83ab688759','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:02','2026-10-21 18:09:02'),
(889,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','14cdd221-d1a2-4890-849d-d109ebd0bf9d','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:02','2026-10-21 18:09:02'),
(890,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d689f4a8-00f1-495b-be83-491431c9926b','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:02','2026-10-21 18:09:02'),
(891,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','2c8469d9-940c-4be2-bc88-99be87a97352','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:03','2026-10-21 18:09:03'),
(892,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f9eb43d3-eab9-4c95-be9c-174c7e333f04','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:03','2026-10-21 18:09:03'),
(893,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','eb70ffa5-6d84-40f1-b8fc-1ce270761ac0','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:03','2026-10-21 18:09:03'),
(894,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','92098073-8a8f-477f-9570-1920d2bdbf5b','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:04','2026-10-21 18:09:04'),
(895,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','75bc9145-9b4f-4b6c-92c7-18fda51b6153','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:05','2026-10-21 18:09:05'),
(896,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e233b32d-a1e5-461d-a331-448795e3cb82','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:06','2026-10-21 18:09:06'),
(897,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a8c92a08-44c5-4c68-a775-d4a9149ca60a','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:06','2026-10-21 18:09:06'),
(898,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4562cdbf-d29d-4fc9-bdda-12ac0e907d99','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:06','2026-10-21 18:09:06'),
(899,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a43862df-82d4-41a1-9264-fefc9f976ff4','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:06','2026-10-21 18:09:06'),
(900,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f28f3df5-8001-4405-824b-4f8af11cc072','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:07','2026-10-21 18:09:07'),
(901,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c507c7ab-90f2-4975-ab5a-97a7879eccfb','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:07','2026-10-21 18:09:07'),
(902,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1d5c0e5d-0958-480a-b8d8-9a3203e38bff','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:08','2026-10-21 18:09:08'),
(903,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7b77691c-2139-4285-bb7e-6817320db993','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:08','2026-10-21 18:09:08'),
(904,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','02eab591-d73e-4dd2-b02e-ea24c35a228e','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:09','2026-10-21 18:09:09'),
(905,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3bb1843a-4cd3-4765-a12a-b30e3dc931aa','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:09','2026-10-21 18:09:09'),
(906,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','87d5689a-f6b5-4e1a-b0d9-99134ae2ba83','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:10','2026-10-21 18:09:10'),
(907,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e1bb76f1-19db-482e-9738-386d7710ce50','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:10','2026-10-21 18:09:10'),
(908,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f388da65-8799-4647-a4bc-d47e91cb11b2','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:11','2026-10-21 18:09:11'),
(909,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','09eb6444-250e-414a-8a7f-510c20bc7a30','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:11','2026-10-21 18:09:11'),
(910,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','fd50cbf7-2de3-4ece-855c-4de53b8d6c4b','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:12','2026-10-21 18:09:12'),
(911,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5e7cb3a7-89b8-4b52-abd3-63dd3624650b','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:12','2026-10-21 18:09:12'),
(912,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','051c11f8-9a3b-471c-b2ad-0cbdf75ba48b','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:12','2026-10-21 18:09:12'),
(913,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','139f9ef1-28a4-4982-a5c7-819df7699688','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:13','2026-10-21 18:09:13'),
(914,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5e50bc32-c2b6-4b22-b003-d9ef8a33b15e','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:13','2026-10-21 18:09:13'),
(915,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4f2884e1-e472-4869-bbd0-575799338c19','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:13','2026-10-21 18:09:13'),
(916,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0d8db358-83d3-41aa-b302-e0aabd62086e','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:14','2026-10-21 18:09:14'),
(917,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','18a3efdb-cb0c-4b8d-ae36-1c6f25a4c9e1','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:15','2026-10-21 18:09:15'),
(918,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','345857aa-8525-42ab-8092-9bd35d2c9342','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:15','2026-10-21 18:09:15'),
(919,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b6c39217-b8a2-45e2-b0cb-d468bb6847d9','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:16','2026-10-21 18:09:16'),
(920,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','58f68695-8cb6-4adc-874b-efb860772fe9','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:16','2026-10-21 18:09:16'),
(921,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6e68098e-7185-470d-9219-09584a8b5fff','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:17','2026-10-21 18:09:17'),
(922,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3394c919-3525-4b88-91da-7da937df5127','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:17','2026-10-21 18:09:17'),
(923,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8b1be432-2b4a-41de-a91b-2db6ea063c16','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:17','2026-10-21 18:09:17'),
(924,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','95da3042-438a-4a48-848b-c440f5709607','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:18','2026-10-21 18:09:18'),
(925,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','321d31ad-58be-466c-9bc5-dc0badcce166','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:18','2026-10-21 18:09:18'),
(926,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b61687d8-0143-407c-8d55-28657b736097','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:18','2026-10-21 18:09:18'),
(927,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d6962c01-65f7-462f-bdb3-358d29d50923','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:20','2026-10-21 18:09:20'),
(928,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','92403c51-8e5e-4032-ad18-703405d85e2b','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:20','2026-10-21 18:09:20'),
(929,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ff6995c4-f664-4e15-a4f3-66d29b98482e','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:20','2026-10-21 18:09:20'),
(930,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','2f79b3c7-0a24-44d0-80af-7751436295fe','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:21','2026-10-21 18:09:21'),
(931,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5642b6c3-9130-4ee6-89c1-c635e7c0a531','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:21','2026-10-21 18:09:21'),
(932,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','76a48f7d-ee6f-41fb-bf34-bfb1754f9750','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:21','2026-10-21 18:09:21'),
(933,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','73cb67bc-1c35-42ef-8860-ec79640de3fb','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:22','2026-10-21 18:09:22'),
(934,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','af38c416-9311-46a5-a146-5fae5fd5333f','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:22','2026-10-21 18:09:22'),
(935,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6fb54c4a-1c1b-4f7c-bfa2-557613b98abc','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:23','2026-10-21 18:09:23'),
(936,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','832dc0ea-5ad2-47d1-928a-3a8514a3a0d7','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:23','2026-10-21 18:09:23'),
(937,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','25a4779f-2275-443f-9fc9-a2cc4dfb8ecd','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:24','2026-10-21 18:09:24'),
(938,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c794c7e4-5e6a-4a0a-ba63-ddc70ece5237','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:25','2026-10-21 18:09:25'),
(939,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','668f8a11-31f8-4425-a256-e10a4ff92c73','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:25','2026-10-21 18:09:25'),
(940,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ce8ac5b9-fc39-4782-ba44-a16807f29004','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:25','2026-10-21 18:09:25'),
(941,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e9182640-3840-4a21-93e2-c4f518db0a97','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:26','2026-10-21 18:09:26'),
(942,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','31744cc6-52d0-4fb1-a246-5c37fa8bfa55','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:26','2026-10-21 18:09:26'),
(943,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3213398a-9c24-45ee-b8a4-72f8400b038e','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:26','2026-10-21 18:09:26'),
(944,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3e89217e-c50d-4d37-b782-41c45eb6eadd','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:27','2026-10-21 18:09:27'),
(945,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e346fabd-abee-4c62-8d6c-dd5e480b01a5','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:27','2026-10-21 18:09:27'),
(946,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ef4302d2-be48-434e-b42d-9297ac02b8ad','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:28','2026-10-21 18:09:28'),
(947,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ec8dc596-6094-450d-bc22-afb1028a4b8d','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:28','2026-10-21 18:09:28'),
(948,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','84622668-af27-4cfc-ac10-8dc75b9c8d67','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:29','2026-10-21 18:09:29'),
(949,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','06bcb1f8-e49f-4189-ab33-89e5f2c9b93b','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:30','2026-10-21 18:09:30'),
(950,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','cd10d585-01f0-420d-9858-04f05883a05d','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:30','2026-10-21 18:09:30'),
(951,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','69d80257-9530-4d93-b03c-8121518f9742','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:30','2026-10-21 18:09:30'),
(952,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','25f5bea2-70ce-4815-9381-32fb6645e638','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:30','2026-10-21 18:09:30'),
(953,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9ad8d6a3-31ec-4a0e-a7ff-5f7efe8b2fec','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:31','2026-10-21 18:09:31'),
(954,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b277beaa-438e-4d8d-a2f6-3d2b226bec21','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:31','2026-10-21 18:09:31'),
(955,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','57c60312-003a-4762-a5c9-e5367522cdb5','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:32','2026-10-21 18:09:32'),
(956,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e91ae528-5285-4102-84c6-bd80bed52585','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:32','2026-10-21 18:09:32'),
(957,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f77e4f16-a65e-4543-b68b-096ea3f06813','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:32','2026-10-21 18:09:32'),
(958,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e60e0202-c21a-45a6-b3fd-bd839360d4e9','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:33','2026-10-21 18:09:33'),
(959,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','95e43b29-7016-4166-b8eb-c495dd91c8fe','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:34','2026-10-21 18:09:34'),
(960,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','01ff7cc3-2b7b-44ea-8ca4-d850d9b94eb4','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:35','2026-10-21 18:09:35'),
(961,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','02cb8eac-f204-44cb-adcd-7e1ab381a9d6','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:35','2026-10-21 18:09:35'),
(962,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','fe60b7cc-df1c-449a-99e7-c11bf1a2c2e0','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:35','2026-10-21 18:09:35'),
(963,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','2dbd1938-44dd-4f83-9188-b45f5528ebb2','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:35','2026-10-21 18:09:35'),
(964,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e7e32bf5-166c-4144-b4f8-79759de9e2c8','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:36','2026-10-21 18:09:36'),
(965,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','91bff7b7-e021-4c54-ba61-bbf4f82bc2e8','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:36','2026-10-21 18:09:36'),
(966,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','506013c2-5633-4c1b-bd21-d302cd657dd1','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:36','2026-10-21 18:09:36'),
(967,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1f06816b-8475-4f6b-9d9a-384bfb4d1155','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:37','2026-10-21 18:09:37'),
(968,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','77a57379-8913-4b8c-8d00-a23a113cf21b','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:37','2026-10-21 18:09:37'),
(969,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','53c064bd-b68e-4951-a31b-8578947a73d2','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:38','2026-10-21 18:09:38'),
(970,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e09d6e02-7cb9-445c-bb48-42f6c9ca9567','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:39','2026-10-21 18:09:39'),
(971,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','33d875c7-634d-469e-af4b-6a391d2a69a9','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:39','2026-10-21 18:09:39'),
(972,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a03e97a1-c5f8-4464-a117-8caa81d5cf08','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:40','2026-10-21 18:09:40'),
(973,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a098af46-f917-4ea8-b50c-46205848b569','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:40','2026-10-21 18:09:40'),
(974,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','86fcd6b3-9e92-4220-96da-a14adb1bb7fc','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:40','2026-10-21 18:09:40'),
(975,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','de796728-f0d6-47b5-86f8-d16bc380c9fa','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:41','2026-10-21 18:09:41'),
(976,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1630d589-b953-4b51-bb04-d853107474ae','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:41','2026-10-21 18:09:41'),
(977,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8883b738-6887-40cf-82d8-70cef86dd198','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:42','2026-10-21 18:09:42'),
(978,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e1c86961-aed9-4c2f-8b25-6de19873eb09','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:42','2026-10-21 18:09:42'),
(979,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','bf8d2da8-8ac4-4724-95c8-ae97d3d4296f','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:42','2026-10-21 18:09:42'),
(980,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','cdfce7f2-a91c-4b49-9e9f-a8ad9da2aa69','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:44','2026-10-21 18:09:44'),
(981,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','43e34442-e5ae-4bb3-bea7-f0d298401981','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:44','2026-10-21 18:09:44'),
(982,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9f6af336-a3d6-495c-bb88-0740a0bce4f6','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:44','2026-10-21 18:09:44'),
(983,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a0642912-ccb9-4980-877a-049ad87dc524','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:44','2026-10-21 18:09:44'),
(984,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','78395ebd-39c1-40bb-bf60-76f399a80a96','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:45','2026-10-21 18:09:45'),
(985,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','79457415-2402-463c-8db6-d5c796d899ba','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:45','2026-10-21 18:09:45'),
(986,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f2208be5-07d0-4789-a924-51d1c6fcec9d','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:46','2026-10-21 18:09:46'),
(987,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1352c68f-fc72-4311-bf96-299ef742876e','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:46','2026-10-21 18:09:46'),
(988,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','56a06f96-b730-4372-8d55-bd7ecd164bb7','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:47','2026-10-21 18:09:47'),
(989,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9c3cd7fa-2a5d-44bc-b5f5-a5bf5ee8b335','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:47','2026-10-21 18:09:47'),
(990,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e0f62bf6-4b89-4b5d-b0e8-be059cd1f373','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:48','2026-10-21 18:09:48'),
(991,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f74cd483-7e07-4876-a7ee-f5943028ee9c','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:49','2026-10-21 18:09:49'),
(992,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c3d68a8c-4360-437e-857b-52a9e93d6206','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:49','2026-10-21 18:09:49'),
(993,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','39eda2e0-e9b1-48d8-9fc7-da37944df030','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:49','2026-10-21 18:09:49'),
(994,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','69174073-d131-4415-9515-ef4935771ea0','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:50','2026-10-21 18:09:50'),
(995,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ef5cf9eb-877b-4bd7-91d9-d0d9715d30d5','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:50','2026-10-21 18:09:50'),
(996,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6cf6e282-1a24-4217-9d28-5aac56c66888','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:50','2026-10-21 18:09:50'),
(997,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','23ee7008-4bd2-436a-a8ef-f56505dc6bb1','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:51','2026-10-21 18:09:51'),
(998,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7ecc2d1e-6c2f-4374-a123-fb11142716d8','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:51','2026-10-21 18:09:51'),
(999,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','884ce6da-ec2f-48f8-80fd-fcf56bff6b86','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:52','2026-10-21 18:09:52'),
(1000,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f417494a-3abd-467c-8f13-d1bec9d09e97','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:52','2026-10-21 18:09:52'),
(1001,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','2225ade7-7739-41a8-b6d8-55531bb17ab8','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:53','2026-10-21 18:09:53'),
(1002,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','aea06aa2-1f69-4dd8-9b72-e279bae7fa10','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:53','2026-10-21 18:09:53'),
(1003,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8355bc2e-06b8-410a-bec6-2fc42e5d0014','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:54','2026-10-21 18:09:54'),
(1004,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c8d5485a-5af8-4e99-a4e4-02cd33105d69','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:54','2026-10-21 18:09:54'),
(1005,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','654f98df-cb5b-448a-a734-01dbd8720afa','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:55','2026-10-21 18:09:55'),
(1006,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a0d989c2-b8a9-425b-8834-075c0dd65d0a','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:55','2026-10-21 18:09:55'),
(1007,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0e429f64-f375-4ed8-ab1e-32b1f7444bf8','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:55','2026-10-21 18:09:55'),
(1008,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9b2b5d51-5ba3-4ea9-b32e-85981ba47fef','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:56','2026-10-21 18:09:56'),
(1009,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ef19a78f-fda5-42c3-b5bc-6beab351f5d7','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:56','2026-10-21 18:09:56'),
(1010,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7b7b975e-fa37-4e4d-a282-0d68e7a2bd27','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:56','2026-10-21 18:09:56'),
(1011,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6d1bbbac-5377-4571-b88c-65c172e26e6a','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:57','2026-10-21 18:09:57'),
(1012,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8b85eff6-aca1-4191-a454-7ca7ddd152cb','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:58','2026-10-21 18:09:58'),
(1013,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','602264be-3d61-4864-895f-a71ba4608b2b','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:59','2026-10-21 18:09:59'),
(1014,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','423fe59c-2fd3-438a-a9f9-b5ea904c8bb1','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:59','2026-10-21 18:09:59'),
(1015,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0730739a-69a2-48f8-84f0-379090ef0ba6','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:09:59','2026-10-21 18:09:59'),
(1016,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6be8d176-3795-41cf-86a6-bf4d43179c79','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:00','2026-10-21 18:10:00'),
(1017,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','40f7a924-456b-4757-8598-90f0361aacfe','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:00','2026-10-21 18:10:00'),
(1018,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c263508a-2e33-40dd-bf9e-31d549253577','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:00','2026-10-21 18:10:00'),
(1019,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','961171d4-9fc4-48bb-b579-18e5d07d9b13','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:01','2026-10-21 18:10:01'),
(1020,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3a57c8a7-8b15-438a-8415-132069642e26','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:01','2026-10-21 18:10:01'),
(1021,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','25bd658c-530b-4c62-9131-f7e21394f117','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:02','2026-10-21 18:10:02'),
(1022,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6aa84b64-96bf-40a3-862f-bfd5ca9ae26b','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:03','2026-10-21 18:10:03'),
(1023,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5813bf4c-41ba-42fe-811a-c4f29912c0db','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:03','2026-10-21 18:10:03'),
(1024,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0ca0b21e-7d8d-47a6-86ec-a2043fea0c33','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:04','2026-10-21 18:10:04'),
(1025,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ea88c565-3efa-40d5-bca9-b0ad67707240','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:04','2026-10-21 18:10:04'),
(1026,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','75520611-00b5-40f1-a058-46b355b2ae95','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:04','2026-10-21 18:10:04'),
(1027,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','03c5599f-fc94-4163-a791-142322f8a022','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:04','2026-10-21 18:10:04'),
(1028,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0de41199-59d4-4580-9fc7-414a182b6207','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:05','2026-10-21 18:10:05'),
(1029,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','00289576-a0b9-4f7e-8f69-5d49181d432c','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:05','2026-10-21 18:10:05'),
(1030,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d5f3d39e-9311-4591-9b49-8823e4296e9e','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:06','2026-10-21 18:10:06'),
(1031,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','89b6cffd-a3ac-40d3-80ca-65dae48dc93c','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:06','2026-10-21 18:10:06'),
(1032,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b2e08052-b892-473f-a69f-f5e74980e3f9','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:07','2026-10-21 18:10:07'),
(1033,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','cec50408-a5b5-4f3b-a4ef-2690083d2e6c','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:08','2026-10-21 18:10:08'),
(1034,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8f096d10-0134-4c37-8b82-1aadd788ac13','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:08','2026-10-21 18:10:08'),
(1035,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f7622fa5-6289-4e34-8b6d-a58e951edc81','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:08','2026-10-21 18:10:08'),
(1036,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1775e9a5-f739-4cee-8e49-1612d128b7ac','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:09','2026-10-21 18:10:09'),
(1037,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','52371280-aaa5-4478-8f8f-79bafceae52b','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:09','2026-10-21 18:10:09'),
(1038,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c816f7b7-482e-4909-b0a7-84b5d22268f7','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:10','2026-10-21 18:10:10'),
(1039,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','fb57777f-c04d-4192-a5ed-116d94034e87','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:10','2026-10-21 18:10:10'),
(1040,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c1354040-f5f7-4288-921b-54017a63e0c4','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:11','2026-10-21 18:10:11'),
(1041,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','070c6eda-0f09-4b59-929b-57d9e7e0120e','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:11','2026-10-21 18:10:11'),
(1042,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d93c86ba-a492-4b94-aeee-d1279884e271','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:12','2026-10-21 18:10:12'),
(1043,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1c597226-1554-46d9-b3da-b3fcbfb4dc18','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:12','2026-10-21 18:10:12'),
(1044,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6d9d7157-1adc-4691-907f-f46ed88e2018','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:13','2026-10-21 18:10:13'),
(1045,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4493211d-503f-468d-8ace-899dacc300d2','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:14','2026-10-21 18:10:14'),
(1046,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','606c5976-c02a-41a2-a3c1-ddaeea8b0956','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:14','2026-10-21 18:10:14'),
(1047,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7bafecdc-daaf-4d77-a011-7453152a53ed','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:14','2026-10-21 18:10:14'),
(1048,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','94a815a6-1b49-46cc-9550-cffb182a216e','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:15','2026-10-21 18:10:15'),
(1049,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','27adb650-9fe5-400c-ba56-9091fa6e603d','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:15','2026-10-21 18:10:15'),
(1050,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0a3aefef-9f62-4581-bf0c-52c79ebf556f','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:15','2026-10-21 18:10:15'),
(1051,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','bc42f137-9ad6-4739-a23d-65439b26efce','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:17','2026-10-21 18:10:17'),
(1052,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e83e774a-07ce-4fd0-8811-ca239ee74c58','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:17','2026-10-21 18:10:17'),
(1053,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','000620ad-ecf6-4168-9823-1a897006512f','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:18','2026-10-21 18:10:18'),
(1054,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','89dc4f9b-22cb-43f9-8f99-a4655d4532b1','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:18','2026-10-21 18:10:18'),
(1055,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','575f3b52-8c33-4f0d-86ec-2d9271c99800','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:18','2026-10-21 18:10:18'),
(1056,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','681c7471-d42b-4d42-acc7-9846812e13db','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:19','2026-10-21 18:10:19'),
(1057,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','bb4604b5-c5e3-48d3-b92f-20d11cb3971a','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:20','2026-10-21 18:10:20'),
(1058,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','51945cf8-f057-41d4-bf29-af0fd579d4e0','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:20','2026-10-21 18:10:20'),
(1059,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b5d2d374-2cfe-4948-970d-66fa00ab5f7f','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:20','2026-10-21 18:10:20'),
(1060,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f7c0245a-f79d-45ba-91ba-7b84d2c9b89c','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:21','2026-10-21 18:10:21'),
(1061,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f2af72b6-287e-4cbc-8b49-ff3c9309f438','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:22','2026-10-21 18:10:22'),
(1062,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a01b12c0-5bfe-4c5b-a639-f21f38b99f74','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:22','2026-10-21 18:10:22'),
(1063,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5eb6ed79-a103-42c3-b046-e47e25f34798','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:22','2026-10-21 18:10:22'),
(1064,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b9f984d8-176a-4803-9891-02834fec7873','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:23','2026-10-21 18:10:23'),
(1065,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','25f50c64-2fe4-4932-a260-ed5409ab685b','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:23','2026-10-21 18:10:23'),
(1066,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b00200a5-d029-4d10-b0b6-d019a6dd1eaa','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:24','2026-10-21 18:10:24'),
(1067,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9d71998e-f095-4e0d-aba4-afc60a6cb1d2','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:24','2026-10-21 18:10:24'),
(1068,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d6d162cb-3847-4e39-9c72-cee3e9c40d93','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:25','2026-10-21 18:10:25'),
(1069,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','caea7889-08b7-470c-8ed5-f551ac20b1b4','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:25','2026-10-21 18:10:25'),
(1070,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','bcc63be0-0beb-4ee8-b6c3-eea92c916a51','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:25','2026-10-21 18:10:25'),
(1071,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','efa76b4e-4905-48bb-a3e3-56407d0da628','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:26','2026-10-21 18:10:26'),
(1072,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','de64a76f-992c-457a-a602-3c755366818e','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:26','2026-10-21 18:10:26'),
(1073,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5515f090-5c11-4d43-a6c0-6281c8e5f0fb','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:27','2026-10-21 18:10:27'),
(1074,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d282e81a-a972-4ae4-ba53-46cb3e5d7412','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:27','2026-10-21 18:10:27'),
(1075,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ac778270-6887-47d7-b3f7-f3381fc7bd17','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:28','2026-10-21 18:10:28'),
(1076,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','89b106e5-5527-463e-bfff-f639696d5f58','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:28','2026-10-21 18:10:28'),
(1077,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','759b486e-0959-4fd3-b95a-26296d53cb6b','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:29','2026-10-21 18:10:29'),
(1078,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7017cdac-ae79-4e5a-ac29-0a5a82f8b413','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:29','2026-10-21 18:10:29'),
(1079,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3eba9ef7-919c-4ffe-a854-997a1f66ad93','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:30','2026-10-21 18:10:30'),
(1080,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4940f439-2137-49ff-b6b9-f1b79aa68750','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:30','2026-10-21 18:10:30'),
(1081,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','db109e90-1467-4a89-a994-8b8b86d109a5','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:30','2026-10-21 18:10:30'),
(1082,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e014d63b-436e-4d38-9d59-83dbdba19535','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:31','2026-10-21 18:10:31'),
(1083,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b7334a73-69fe-47ab-a00d-9690e79eebb7','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:32','2026-10-21 18:10:32'),
(1084,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','21f33082-710c-4c0d-bac5-f8f0cc1bcc1e','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:32','2026-10-21 18:10:32'),
(1085,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c59c0ec1-aa31-4283-ae5d-656147b96c37','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:32','2026-10-21 18:10:32'),
(1086,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5433a669-5451-4f42-a803-6beb7f4d021e','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:33','2026-10-21 18:10:33'),
(1087,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','eb514576-629b-411e-84a0-c92f1a9c6d3a','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:33','2026-10-21 18:10:33'),
(1088,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','bb9a90af-c969-446a-afd6-838b8d71ba43','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:34','2026-10-21 18:10:34'),
(1089,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5d6de87b-bbd3-484b-b2b9-72abadf25c35','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:34','2026-10-21 18:10:34'),
(1090,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5f716a48-4472-47d3-96a9-5564fff6222d','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:35','2026-10-21 18:10:35'),
(1091,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7d5e36ee-6b75-4dbd-b975-5fb996c7c61a','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:35','2026-10-21 18:10:35'),
(1092,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1e598d33-8cc8-4d07-a8db-23861bdfa98c','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:35','2026-10-21 18:10:35'),
(1093,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a933d6c5-d1b3-4f6e-8cb6-bfc02ca6d0ae','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:36','2026-10-21 18:10:36'),
(1094,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','74a52ce8-870f-499b-94e0-b3c39ea43a98','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:36','2026-10-21 18:10:36'),
(1095,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e33e780f-f5eb-4dce-b30f-3eaf5c0ccdfc','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:37','2026-10-21 18:10:37'),
(1096,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','018e34b2-77c9-4c6d-bd85-ad4440f8f33e','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:38','2026-10-21 18:10:38'),
(1097,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','42e28a98-def8-47ab-ba32-63257c38bb76','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:38','2026-10-21 18:10:38'),
(1098,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4727b164-87cd-4ed8-ac79-ac6347324030','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:39','2026-10-21 18:10:39'),
(1099,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','2415db37-1be3-4a33-b5d2-b8dd88453656','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:40','2026-10-21 18:10:40'),
(1100,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','293475cb-579d-4c46-9f25-43830c2a2962','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:40','2026-10-21 18:10:40'),
(1101,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c35d2607-69c6-4938-a628-9144904f26c9','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:40','2026-10-21 18:10:40'),
(1102,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','bb0e4ba5-a5a3-4273-8b7b-a6e879965c8d','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:40','2026-10-21 18:10:40'),
(1103,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4b1d6e1a-0ca8-42cf-9adf-cbd53f85ac4e','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:41','2026-10-21 18:10:41'),
(1104,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8e627f7b-47ca-42f3-b5d5-7907f53bf959','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:41','2026-10-21 18:10:41'),
(1105,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','751843b7-dda7-424a-aedf-1d937da12a54','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:42','2026-10-21 18:10:42'),
(1106,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','487de350-ec86-4ab9-89ff-ff0a1c40dbcd','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:42','2026-10-21 18:10:42'),
(1107,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e1d48402-e459-49e8-9231-55fb6129e046','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:43','2026-10-21 18:10:43'),
(1108,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a7dafad8-9e12-4a8d-9cf1-7bacdc5ee30a','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:44','2026-10-21 18:10:44'),
(1109,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9aca2fd6-a8fc-40aa-8d5a-eec753de7276','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:45','2026-10-21 18:10:45'),
(1110,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6bf4aa3a-1153-410a-9b39-d2aa5ab0847f','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:45','2026-10-21 18:10:45'),
(1111,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f9803c17-5186-461a-85c0-b2b1a18b02ad','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:45','2026-10-21 18:10:45'),
(1112,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','95680f37-7cba-49d6-9f54-af9ca4cc2e3a','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:45','2026-10-21 18:10:45'),
(1113,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b65d72c6-e28a-4ad9-836c-9a3fc501556b','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:46','2026-10-21 18:10:46'),
(1114,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e88dae38-0875-4c03-beda-1272c1fcac72','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:46','2026-10-21 18:10:46'),
(1115,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','34cb6e3d-03d8-4341-9de4-631162660a7c','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:47','2026-10-21 18:10:47'),
(1116,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8f03ea11-5607-460c-8715-e74c6e2616c3','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:47','2026-10-21 18:10:47'),
(1117,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a14c1d37-b144-4f31-9d23-8ddf12fbf7b0','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:48','2026-10-21 18:10:48'),
(1118,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5e610dbe-f0d2-4696-9778-85548092ec35','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:49','2026-10-21 18:10:49'),
(1119,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d0e4fed0-1c6d-4339-8a5c-6a2d67700809','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:49','2026-10-21 18:10:49'),
(1120,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','62c57859-a280-4d13-a600-06c4acbd2e4a','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:49','2026-10-21 18:10:49'),
(1121,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','17ccb312-e846-452e-acc9-a36a6c274ba0','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:50','2026-10-21 18:10:50'),
(1122,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','2621712d-f8a0-4390-85cb-401ac65ff512','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:50','2026-10-21 18:10:50'),
(1123,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','552397f1-69ac-4c76-94ea-7ca17314bf34','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:51','2026-10-21 18:10:51'),
(1124,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','038f0f40-3bdf-4a46-b8d3-60c44ae29395','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:51','2026-10-21 18:10:51'),
(1125,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','22d79003-5c06-46fc-9e45-3e5f8092d9a2','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:51','2026-10-21 18:10:51'),
(1126,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7109d3ed-b835-4c28-b052-4df81041d811','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:52','2026-10-21 18:10:52'),
(1127,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f62c4d82-ce0b-4328-8865-155149c007e1','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:52','2026-10-21 18:10:52'),
(1128,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ceb9b325-9be5-47b8-9e85-3bc1fd23c252','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:53','2026-10-21 18:10:53'),
(1129,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','73f5ce70-0fcc-4220-be9b-97ec2b0f870d','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:54','2026-10-21 18:10:54'),
(1130,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','213782b4-3a51-4e35-ba79-f1e9b020a04d','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:54','2026-10-21 18:10:54'),
(1131,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9f196464-72f5-4239-b444-aad648845601','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:54','2026-10-21 18:10:54'),
(1132,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ae174868-9793-4b47-9cbc-a28f9979828f','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:55','2026-10-21 18:10:55'),
(1133,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f6ec1a0a-cdf5-440a-bfa2-45da05f3791c','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:55','2026-10-21 18:10:55'),
(1134,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','997a2a2e-93e5-4fa9-b27d-8cb390cf4064','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:55','2026-10-21 18:10:55'),
(1135,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b4294f7c-4f16-4d20-bce8-602481cfd5ab','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:56','2026-10-21 18:10:56'),
(1136,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1c9dbfb5-7139-442b-b5f8-e9a6715991b2','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:56','2026-10-21 18:10:56'),
(1137,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','eebb5a5f-619c-4825-8f34-7cd7dac39e7b','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:57','2026-10-21 18:10:57'),
(1138,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c572f135-efb5-4f7e-ab73-0fad482684f6','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:57','2026-10-21 18:10:57'),
(1139,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f5bed1db-6ca5-4ab6-aaf9-f3594d01499f','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:58','2026-10-21 18:10:58'),
(1140,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f8a4c150-0dd7-43a7-a380-92159e5021cd','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:59','2026-10-21 18:10:59'),
(1141,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9a8ccbb1-6e87-4e68-a5ca-76aa7e0c3011','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:59','2026-10-21 18:10:59'),
(1142,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4831cca4-340e-4710-97aa-f36e57010ee4','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:10:59','2026-10-21 18:10:59'),
(1143,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e52e5388-21b4-45b4-969f-12a4cdf00fd6','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:00','2026-10-21 18:11:00'),
(1144,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','142fa4bb-e2e7-4346-a39e-1488a2bce2c6','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:00','2026-10-21 18:11:00'),
(1145,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6741e833-2f4c-4a41-bec0-f5a5dd53e667','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:01','2026-10-21 18:11:01'),
(1146,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','584f8fab-34d5-41f8-a8cc-64449b47059d','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:01','2026-10-21 18:11:01'),
(1147,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e243ea89-e8bc-4947-8677-4856d0b1b9e3','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:01','2026-10-21 18:11:01'),
(1148,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','49ab2291-d8fc-44eb-a472-7b788311072c','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:02','2026-10-21 18:11:02'),
(1149,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3f745270-4696-44db-a6ac-9031d2eade1b','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:02','2026-10-21 18:11:02'),
(1150,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5193d600-0849-4750-becd-d5118b637807','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:03','2026-10-21 18:11:03'),
(1151,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3d03e9d0-30c8-46e7-8f82-983a7d5539a6','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:04','2026-10-21 18:11:04'),
(1152,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','fa249875-84bb-4173-9885-0622aa354bec','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:04','2026-10-21 18:11:04'),
(1153,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','01bf2a16-11e8-4c71-a609-51cd26d684aa','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:04','2026-10-21 18:11:04'),
(1154,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','63bb344a-06e5-47a9-b5f9-13d81139c61c','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:05','2026-10-21 18:11:05'),
(1155,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4280bf00-f4aa-410e-a59d-7f4e5556e602','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:05','2026-10-21 18:11:05'),
(1156,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','599f5e2e-1224-4e11-bb76-9f4b9bccb078','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:05','2026-10-21 18:11:05'),
(1157,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b905148e-7555-4f5c-a761-35f191c6bd48','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:06','2026-10-21 18:11:06'),
(1158,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','960d9d7a-8af9-4704-aa4f-fa8f442ffba5','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:06','2026-10-21 18:11:06'),
(1159,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e0a341f7-9583-47e2-8b3a-dc9aabbf216a','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:07','2026-10-21 18:11:07'),
(1160,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','82c59efa-1015-4886-aa23-04df160dd1f0','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:08','2026-10-21 18:11:08'),
(1161,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','fcf47cbc-9904-4b7d-ae76-b43bb680a864','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:08','2026-10-21 18:11:08'),
(1162,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f9da94f2-8924-4e8b-8136-512ea59ee398','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:08','2026-10-21 18:11:08'),
(1163,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5f1f14d9-fdd4-4c06-8653-e86aaf43ec58','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:09','2026-10-21 18:11:09'),
(1164,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','274095da-4fd7-4f1b-b57e-d3e0bd55c10a','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:09','2026-10-21 18:11:09'),
(1165,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e26183ef-175d-4539-8a54-1776dcc85c6b','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:10','2026-10-21 18:11:10'),
(1166,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','49965c55-8981-4307-a7b5-d754343afed0','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:10','2026-10-21 18:11:10'),
(1167,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b4f8a717-6134-4397-8c3f-51244a855279','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:10','2026-10-21 18:11:10'),
(1168,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c1a05a41-1725-4010-bdff-1ca969ae8724','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:11','2026-10-21 18:11:11'),
(1169,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0eeed985-659f-4a2f-b699-2cd95b59b70f','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:11','2026-10-21 18:11:11'),
(1170,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0bae5eb4-465e-4d5b-bf23-c51b68291368','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:12','2026-10-21 18:11:12'),
(1171,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','cf9901c6-c2db-48fc-b2fe-2ded46864791','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:13','2026-10-21 18:11:13'),
(1172,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','912201ef-2c10-492c-beb2-39cacea9e9c6','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:13','2026-10-21 18:11:13'),
(1173,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','700b007a-0e96-481e-aa9d-f2561d990809','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:13','2026-10-21 18:11:13'),
(1174,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4871462d-4817-458d-9ae8-2ef9e5f03ff2','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:14','2026-10-21 18:11:14'),
(1175,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f9f43360-7c74-4f88-bf07-19edb219bd58','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:14','2026-10-21 18:11:14'),
(1176,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','71c38752-b73b-4380-800a-aa9764be8d45','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:15','2026-10-21 18:11:15'),
(1177,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1cc3c578-dcde-4108-a88f-03d99c33c373','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:15','2026-10-21 18:11:15'),
(1178,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','45e90967-6466-49b7-a18a-a0855e18b30b','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:15','2026-10-21 18:11:15'),
(1179,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','28f14841-7b8b-4e83-bc6e-56f478e4ef5a','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:16','2026-10-21 18:11:16'),
(1180,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','504baebb-14a0-41fd-b744-35a1ca37cdd1','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:16','2026-10-21 18:11:16'),
(1181,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','90c7a07f-7744-4dcb-bdd4-184c8704efe1','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:17','2026-10-21 18:11:17'),
(1182,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7b309898-ff1d-4025-97f5-c75b4396054c','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:18','2026-10-21 18:11:18'),
(1183,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f883ba11-02b9-4f78-8e87-fe6a50036ebe','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:18','2026-10-21 18:11:18'),
(1184,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8d8575b6-1970-4654-b619-49c3e2002716','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:19','2026-10-21 18:11:19'),
(1185,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','24c5c612-fb11-4011-9cf0-540698f91ab1','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:19','2026-10-21 18:11:19'),
(1186,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','46727989-076b-4058-9f6b-5cb7463bae01','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:19','2026-10-21 18:11:19'),
(1187,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','2d1eac55-102b-40aa-8648-00f117da6f65','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:19','2026-10-21 18:11:19'),
(1188,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','aeeaf275-7603-4ce3-bf90-d59dedc2a6e5','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:20','2026-10-21 18:11:20'),
(1189,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c6036e67-21fe-459f-b30b-d04bc75dad59','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:20','2026-10-21 18:11:20'),
(1190,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3ed4579e-cb8e-4b60-bd6b-72e891da6df9','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:21','2026-10-21 18:11:21'),
(1191,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7518bdbc-2c99-4839-b053-dd0178bac7e1','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:21','2026-10-21 18:11:21'),
(1192,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','87a9df0e-2348-40fe-a57a-0eff3213ac64','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:22','2026-10-21 18:11:22'),
(1193,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f9a74562-2da1-4cbb-9093-470b735acf35','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:23','2026-10-21 18:11:23'),
(1194,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d6c2247b-6946-42cf-a548-533106125172','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:23','2026-10-21 18:11:23'),
(1195,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','013bf657-3638-4060-92d6-7a94fee50ff6','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:23','2026-10-21 18:11:23'),
(1196,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3f8d969d-58ea-4692-8ad1-c56f442e12ce','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:24','2026-10-21 18:11:24'),
(1197,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','2a6c603f-fccf-4fa8-abff-29cbc3125309','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:24','2026-10-21 18:11:24'),
(1198,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3bd2df41-612d-4a0e-93de-cab42f9b0c21','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:25','2026-10-21 18:11:25'),
(1199,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7a297e8d-e997-4f7a-b02a-69c0429dd05c','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:25','2026-10-21 18:11:25'),
(1200,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','db7d0aec-9b15-40f9-a3ca-7390679b4e29','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:25','2026-10-21 18:11:25'),
(1201,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','dc63c1b7-4bca-42ec-a9d5-a4a3d701aed7','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:26','2026-10-21 18:11:26'),
(1202,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e6e239ae-dfcc-4e80-9983-dc872777aacb','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:26','2026-10-21 18:11:26'),
(1203,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f97074fa-1d3e-410b-95e1-08dfe6f9341e','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:27','2026-10-21 18:11:27'),
(1204,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5139d4a7-e304-4119-ab3d-4d1df1647960','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:28','2026-10-21 18:11:28'),
(1205,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','428cd237-ff3e-49d5-bb20-69193fb36964','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:28','2026-10-21 18:11:28'),
(1206,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6a536078-70ba-4edc-b0d0-7f64ae3ad035','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:28','2026-10-21 18:11:28'),
(1207,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7ea578b6-1480-4b89-9e9c-5df70a26bd4f','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:29','2026-10-21 18:11:29'),
(1208,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','02354376-a9e7-4d8e-aace-76de563b99c1','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:29','2026-10-21 18:11:29'),
(1209,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6ad9ea97-a62e-4ceb-8385-eea913170928','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:29','2026-10-21 18:11:29'),
(1210,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6a45ef02-f9a0-401d-a5c0-e210227446d5','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:30','2026-10-21 18:11:30'),
(1211,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9a8b79b0-cb28-47e4-9bd3-7a2e2486476b','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:30','2026-10-21 18:11:30'),
(1212,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','345e15da-c204-4672-be9f-70130f8fa3f3','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:31','2026-10-21 18:11:31'),
(1213,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','36d004f1-d19c-478e-948f-a20a2ad2dd10','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:32','2026-10-21 18:11:32'),
(1214,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1b391004-d465-4595-add7-fe64c13e028a','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:32','2026-10-21 18:11:32'),
(1215,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3c629407-448a-4936-b185-40b2aafb75d4','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:33','2026-10-21 18:11:33'),
(1216,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','85d414c5-2b4a-47a6-8c81-bb3c1800e4cc','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:33','2026-10-21 18:11:33'),
(1217,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b23456e0-606f-4d96-b4c5-2dc9bf848e9e','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:33','2026-10-21 18:11:33'),
(1218,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6a743300-ca5e-4004-9116-ea54c5f81eb8','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:33','2026-10-21 18:11:33'),
(1219,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3c58c305-e7f6-40ed-bb9b-622e621a6199','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:34','2026-10-21 18:11:34'),
(1220,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','167d01b4-f46c-4972-a919-95813cba7256','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:35','2026-10-21 18:11:35'),
(1221,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1ceac817-16c6-4e29-827b-1872ed7f4e22','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:35','2026-10-21 18:11:35'),
(1222,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','86a098f1-d068-493f-a5a7-55ba51a9cb92','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:36','2026-10-21 18:11:36'),
(1223,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','07203859-cbc7-4561-9b42-d6fa9f16a9fd','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:36','2026-10-21 18:11:36'),
(1224,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4c43198f-8e0a-44f3-a5f8-e20d4fd0ade2','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:37','2026-10-21 18:11:37'),
(1225,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3b8f21d8-6442-4211-8fc2-b65b1fc8497d','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:37','2026-10-21 18:11:37'),
(1226,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','02285e93-400e-49fc-b508-bf8469d96761','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:37','2026-10-21 18:11:37'),
(1227,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1dfba3a0-5391-4434-b345-428b558ac103','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:38','2026-10-21 18:11:38'),
(1228,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','149bb457-57fd-4496-932f-1dd9e9746bb9','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:38','2026-10-21 18:11:38'),
(1229,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','83be69ed-0373-4fb0-bf99-b621c3e520b5','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:38','2026-10-21 18:11:38'),
(1230,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f8a13bd9-2a39-4d4c-9d4b-6d0897f6dbbb','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:39','2026-10-21 18:11:39'),
(1231,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','534b8f34-953e-4abf-90bc-6cf45a999a35','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:39','2026-10-21 18:11:39'),
(1232,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ca9baaeb-cc41-40d0-934f-763e014da40d','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:40','2026-10-21 18:11:40'),
(1233,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','46027fad-14bd-48d9-8530-fdfa49385d9e','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:40','2026-10-21 18:11:40'),
(1234,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d62d580a-9967-41c0-92d8-3d3e445b849b','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:41','2026-10-21 18:11:41'),
(1235,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','298bbab9-2b71-4124-8703-7b33a6b1751b','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:41','2026-10-21 18:11:41'),
(1236,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b7e0b876-fa41-4364-9b78-2cfd2486f526','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:42','2026-10-21 18:11:42'),
(1237,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0e1d5228-29bd-45ab-8ec3-41679815db23','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:43','2026-10-21 18:11:43'),
(1238,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5e60b162-3ccf-4bd5-aa54-dfeddd219610','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:43','2026-10-21 18:11:43'),
(1239,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','fac6f0af-84bc-4aa3-ba4b-dd7b4d02b326','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:43','2026-10-21 18:11:43'),
(1240,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d7ea2fc9-b697-492d-9882-57b803dd1c5b','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:43','2026-10-21 18:11:43'),
(1241,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9a2a295e-7611-4707-ae36-623c5e07b43a','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:44','2026-10-21 18:11:44'),
(1242,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ab81e8f7-63a6-4943-a02e-af5e6c9fa016','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:44','2026-10-21 18:11:44'),
(1243,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d5c37cc4-5b9c-40ef-8e37-84b2bccf3fae','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:45','2026-10-21 18:11:45'),
(1244,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','123e29aa-6497-48e7-8568-763f03e60fdf','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:45','2026-10-21 18:11:45'),
(1245,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1a7e8909-5cbf-468e-b992-32671fb6cbd0','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:46','2026-10-21 18:11:46'),
(1246,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d5087b0e-ed0e-453a-8866-b0e813376157','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:47','2026-10-21 18:11:47'),
(1247,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7fe96179-8ded-4dbf-9571-c30959566a73','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:47','2026-10-21 18:11:47'),
(1248,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','33140434-7cce-4d97-b16e-6464f86d1f24','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:47','2026-10-21 18:11:47'),
(1249,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8135f6ef-dfb0-4c23-b331-70a06d855106','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:48','2026-10-21 18:11:48'),
(1250,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1dd95328-143b-4e57-b254-09b95b4c1f78','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:48','2026-10-21 18:11:48'),
(1251,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1b117116-02bd-4436-88d0-b6eb47a40009','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:48','2026-10-21 18:11:48'),
(1252,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','679a58b2-b21a-47dd-9fba-3dbe96ea188c','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:49','2026-10-21 18:11:49'),
(1253,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1f44a17e-34a3-48c7-a03b-f13e0f016990','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:49','2026-10-21 18:11:49'),
(1254,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d7e01d84-a606-4737-a3e7-b0990d777b3f','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:50','2026-10-21 18:11:50'),
(1255,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','dab0f26f-f7c7-4aaa-88de-a2fb2f56953d','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:50','2026-10-21 18:11:50'),
(1256,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a551996d-dbd8-468f-8254-a3799998b8e8','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:51','2026-10-21 18:11:51'),
(1257,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','535f5ebb-681d-4598-bc09-a5d6d0379a79','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:51','2026-10-21 18:11:51'),
(1258,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d0ab6561-e923-40b4-9cc8-1871b9a657b9','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:52','2026-10-21 18:11:52'),
(1259,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','46127c56-cd7f-4ca6-b919-1550009b2f15','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:52','2026-10-21 18:11:52'),
(1260,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1f291376-9058-4d81-a0d6-73862873cc96','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:53','2026-10-21 18:11:53'),
(1261,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ccd95e7e-ac30-4c6a-aaf2-d61a66cf1d79','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:53','2026-10-21 18:11:53'),
(1262,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0417cfa2-2cbc-4ca5-88e0-cea69aed46c9','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:53','2026-10-21 18:11:53'),
(1263,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7239eeb7-df5c-4e45-9492-65323f367c97','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:54','2026-10-21 18:11:54'),
(1264,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c4c3178a-18f2-4ec0-8dbc-6469cab2023e','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:54','2026-10-21 18:11:54'),
(1265,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a1e978b3-fa9f-4f52-a2aa-07306861c07d','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:55','2026-10-21 18:11:55'),
(1266,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','840c1e33-b135-4640-bbc4-9f7854e78cb7','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:56','2026-10-21 18:11:56'),
(1267,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','30e3b28b-4e21-47c6-8dd9-31a2b68b2427','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:56','2026-10-21 18:11:56'),
(1268,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','497838bf-ca70-44db-b6dc-4c9c90157f98','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:56','2026-10-21 18:11:56'),
(1269,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','bb1deebb-46c8-4e96-b271-cd5d09c33751','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:57','2026-10-21 18:11:57'),
(1270,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','34ed2f3c-2251-4e8c-9336-ab66147718fe','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:57','2026-10-21 18:11:57'),
(1271,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','2c792351-f493-4e98-a2c0-eb421700115b','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:58','2026-10-21 18:11:58'),
(1272,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ef10cfe3-90fe-4b42-ad46-103bcc72060c','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:58','2026-10-21 18:11:58'),
(1273,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7d3b0681-c712-452a-bc76-e682ea59cadc','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:59','2026-10-21 18:11:59'),
(1274,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','57865a98-7cc2-4bc7-9a4b-ac5af5b57c63','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:59','2026-10-21 18:11:59'),
(1275,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','58820e42-1447-40b1-a60f-fc9f26d74e46','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:11:59','2026-10-21 18:11:59'),
(1276,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7a9810be-a9ab-4222-ad12-21e3f11e4fa7','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:00','2026-10-21 18:12:00'),
(1277,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b57e4af1-09d6-495b-b0da-826ec0a4ea5e','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:00','2026-10-21 18:12:00'),
(1278,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b8a025ce-9db3-4f05-88ed-6fa0a5f984b5','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:01','2026-10-21 18:12:01'),
(1279,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b96c2e11-3ff9-4d8f-8a81-914bb2f8cb96','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:02','2026-10-21 18:12:02'),
(1280,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7c9c60fe-608c-4c31-94a7-3808113597b6','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:02','2026-10-21 18:12:02'),
(1281,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8da62129-f1f0-4423-8735-5541b53b9e45','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:02','2026-10-21 18:12:02'),
(1282,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','717bcc32-944d-4be9-a702-f17a5c304138','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:02','2026-10-21 18:12:02'),
(1283,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8a65bb36-fdf5-4a9b-8337-97330a88fb41','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:03','2026-10-21 18:12:03'),
(1284,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5f8b2c3e-00f4-49b2-bc74-1a91682fda0e','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:04','2026-10-21 18:12:04'),
(1285,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','47e02cc1-2cd4-4d33-adbb-2b12a0ca0be8','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:04','2026-10-21 18:12:04'),
(1286,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','53c102fb-9d73-4656-a99c-56ee64da7b78','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:05','2026-10-21 18:12:05'),
(1287,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5657c6e4-50f1-486a-9a71-e856596eee6a','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:05','2026-10-21 18:12:05'),
(1288,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','138b5440-683a-40d8-acf2-ff2633e0895c','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:06','2026-10-21 18:12:06'),
(1289,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','dd48b618-827f-4b91-8fab-01cf34f16543','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:06','2026-10-21 18:12:06'),
(1290,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','48e97d93-a889-40fb-a4bd-b37be186f1af','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:06','2026-10-21 18:12:06'),
(1291,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a3cbfa26-12e3-43e0-846c-99c2633abbda','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:07','2026-10-21 18:12:07'),
(1292,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7685364b-eb46-40fb-b185-d03fe8eae57b','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:07','2026-10-21 18:12:07'),
(1293,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b72082fc-27b0-4720-bc59-cb3d422e8595','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:08','2026-10-21 18:12:08'),
(1294,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ff54d2ab-2ee4-4581-99a0-92d140469d34','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:08','2026-10-21 18:12:08'),
(1295,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e84d8b11-201c-468e-a874-c7da2d20e0b1','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:09','2026-10-21 18:12:09'),
(1296,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','47988a68-feda-470c-a497-2e5b20047928','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:09','2026-10-21 18:12:09'),
(1297,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','82c392cf-9ee8-4f21-8ab4-5375798aedf8','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:10','2026-10-21 18:12:10'),
(1298,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','62e867a4-ea8c-4da3-99b0-48ab182b1af7','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:10','2026-10-21 18:12:10'),
(1299,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','53d11524-31c4-48d7-aac5-2f1d379295d4','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:11','2026-10-21 18:12:11'),
(1300,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','48a1bbe8-4bfb-488f-9f82-5089c800adac','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:11','2026-10-21 18:12:11'),
(1301,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','526f8e68-b6fe-4674-9116-f2a910888ed8','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:12','2026-10-21 18:12:12'),
(1302,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','52bb8d88-286a-4732-9c6a-323ab766a9ed','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:12','2026-10-21 18:12:12'),
(1303,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1486c2b8-c2b1-40d0-b512-8eb431e93852','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:12','2026-10-21 18:12:12'),
(1304,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8bbcac14-0197-44a4-902f-ab9f5bc46eca','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:13','2026-10-21 18:12:13'),
(1305,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','63344ceb-ef0e-446c-9fee-b8a80d1ec8b5','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:13','2026-10-21 18:12:13'),
(1306,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7a977bbe-87b9-4390-a0b9-8e4cc39062a4','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:13','2026-10-21 18:12:13'),
(1307,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','b9717033-31ce-4177-9b01-a4b5565ad8a4','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:14','2026-10-21 18:12:14'),
(1308,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d10d398d-c4d7-468e-9c84-f0c60592c3f7','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:15','2026-10-21 18:12:15'),
(1309,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','57abf923-1eeb-4faf-99c5-3bd9b3ff2279','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:15','2026-10-21 18:12:15'),
(1310,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','dfc3591c-e945-45b6-821b-6753a61f2e8b','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:16','2026-10-21 18:12:16'),
(1311,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','209bc370-356d-4348-bc33-70fda12edfe9','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:16','2026-10-21 18:12:16'),
(1312,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d3aaecd4-91cc-4b2d-afdb-8293022852e4','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:17','2026-10-21 18:12:17'),
(1313,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7c169ae6-91f2-43fa-8993-6d3459c38185','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:17','2026-10-21 18:12:17'),
(1314,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','33b2de7b-d851-4111-be76-cc1215005f15','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:17','2026-10-21 18:12:17'),
(1315,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','bc567543-da77-421d-8713-3f67e3d1e470','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:18','2026-10-21 18:12:18'),
(1316,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','fe21ddfa-7f18-4519-8346-32929ea5571c','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:18','2026-10-21 18:12:18'),
(1317,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','16ede183-408f-42ca-819d-a74587aa38a5','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:18','2026-10-21 18:12:18'),
(1318,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3e7b5733-6f84-467e-ad7d-a68899df9acd','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:19','2026-10-21 18:12:19'),
(1319,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4c4384ef-6550-44ac-a273-31b447c307aa','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:20','2026-10-21 18:12:20'),
(1320,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','1d4669e5-4c06-44fc-834f-b2f1699b5e31','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:20','2026-10-21 18:12:20'),
(1321,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','60c6aeef-1a69-41c0-a921-f7a3607d40a8','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:21','2026-10-21 18:12:21'),
(1322,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7bf5c2db-d251-4e45-9d6d-7b3dbed7855d','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:21','2026-10-21 18:12:21'),
(1323,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','24c88362-2907-49c9-ad6c-73f73098a00d','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:22','2026-10-21 18:12:22'),
(1324,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6286ee99-05b2-47d8-80a9-ced554a0c8cc','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:22','2026-10-21 18:12:22'),
(1325,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3e4807f7-bf70-451f-ba26-813477f98abb','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:22','2026-10-21 18:12:22'),
(1326,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8064ee51-5e88-4491-806e-bcd9ae916e99','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:23','2026-10-21 18:12:23'),
(1327,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0fb81e4c-cfe5-4b07-9139-5f56ae5a103e','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:23','2026-10-21 18:12:23'),
(1328,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c8a7967c-035d-4ddc-999c-aa09a069dc9a','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:24','2026-10-21 18:12:24'),
(1329,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','602374f6-3d75-4f74-bff0-2a1fa0a594ce','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:24','2026-10-21 18:12:24'),
(1330,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c2ae5f4f-0e90-41ee-9fa3-0eb34b48a766','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:25','2026-10-21 18:12:25'),
(1331,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9060155f-899b-4532-a0cd-1f0569d039c9','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:25','2026-10-21 18:12:25'),
(1332,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d137c926-def8-4bdb-972e-71ca0142196c','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:26','2026-10-21 18:12:26'),
(1333,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','929c4f73-6e76-4185-a415-27cf6415d9ea','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:27','2026-10-21 18:12:27'),
(1334,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<script>/*xss0001*/</script>','19ec27e7-ce35-4d5c-9916-d69b9b9bb165','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:34','2026-10-21 18:12:34'),
(1335,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<SCRIPT>/*xss0002*/</SCRIPT>','eb361ba9-adb0-4281-8496-e5004dcebedf','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:34','2026-10-21 18:12:34'),
(1336,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<ScRiPt>/*xss0003*/</sCrIpT>','c620fa14-08bd-4eaf-8116-99d3a1e9e9ab','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:34','2026-10-21 18:12:34'),
(1337,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<script >/*xss0004*/</script>','5c8f4709-43d3-4a48-9979-b2d86593866a','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:34','2026-10-21 18:12:34'),
(1338,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<script/xss0006>','eb68b2de-bae5-4922-9914-fd394f5b5cc3','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:35','2026-10-21 18:12:35'),
(1339,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<script\n>/*xss0005*/</script>','b0d0c64a-2ad2-4221-9459-054104e8a3a2','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:35','2026-10-21 18:12:35'),
(1340,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<svg onload=\"/*xss0008*/\">','13173ffa-4608-4d4c-8443-ae757c627a5e','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:36','2026-10-21 18:12:36'),
(1341,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<img src=x onerror=\"/*xss0007*/\">','7f533599-af0e-42f1-a7b6-5aed09c17663','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:36','2026-10-21 18:12:36'),
(1342,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<body onload=\"/*xss0009*/\">','abc4b69c-34c7-4033-91f2-3ebff7362796','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:37','2026-10-21 18:12:37'),
(1343,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<body onload=\"/*xss0009*/\">','da1bb547-c62e-4332-bf95-7cb0c4fad6f0','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:37','2026-10-21 18:12:37'),
(1344,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<textarea autofocus onfocus=\"/*xss0012*/\">','81b5da4e-98fd-478e-ae2b-b3faf8f6afbd','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:38','2026-10-21 18:12:38'),
(1345,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<select autofocus onfocus=\"/*xss0011*/\">','3275b0e6-4baa-4789-b13d-557dc63d9dec','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:38','2026-10-21 18:12:38'),
(1346,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<video src=x onerror=\"/*xss0013*/\">','bc9f382a-221e-40c5-b67e-41ce5f3d512d','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:39','2026-10-21 18:12:39'),
(1347,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<audio src=x onerror=\"/*xss0014*/\">','61ef7c3d-932a-4696-bbe4-f24968c1f869','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:39','2026-10-21 18:12:39'),
(1348,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<details open ontoggle=\"/*xss0016*/\">','06ad7694-1827-498f-a87a-fa5ac3b74ca1','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:40','2026-10-21 18:12:40'),
(1349,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<iframe src=\"javascript:/*xss0015*/\">','cc203968-42d0-45f4-9aed-a7ea47c1a7db','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:40','2026-10-21 18:12:40'),
(1350,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<marquee onstart=\"/*xss0017*/\">','cd666b37-ce50-456d-b9bc-4baf73584915','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:40','2026-10-21 18:12:40'),
(1351,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<a onmouseover=\"/*xss0018*/\">x</a>','1331584e-e734-4c78-b637-0779f6fd509f','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:40','2026-10-21 18:12:40'),
(1352,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.comjavascript:/*xss0019*/','b85e6343-88ff-4b53-a2c6-0ca28fe63a80','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:41','2026-10-21 18:12:41'),
(1353,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.comJaVaScRiPt:/*xss0020*/','adbdb00e-e337-46c4-8ef9-c14c22ac39ee','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:41','2026-10-21 18:12:41'),
(1354,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.comdata:text/html,<script>/*xss0021*/</script>','0f132d29-8f1a-45c1-9e19-35cc27475a7e','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:43','2026-10-21 18:12:43'),
(1355,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com&#106;avascript:/*xss0022*/','7504d5c0-f671-4531-9987-c7737a000d3b','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:43','2026-10-21 18:12:43'),
(1356,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" onmouseover=\"/*xss0023*/','27ac07b7-3127-422d-94e7-bcafa41f7e01','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:43','2026-10-21 18:12:43'),
(1357,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\' onmouseover=\'/*xss0024*/','dd68bff5-a164-44dd-85d8-677e357ceb94','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:43','2026-10-21 18:12:43'),
(1358,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\"><script>/*xss0025*/</script>','064b5ccb-8d7c-4c0e-a311-0b08e1224a98','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:44','2026-10-21 18:12:44'),
(1359,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'><script>/*xss0026*/</script>','8dd4be39-9f6b-4b53-8233-c308d180de12','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:44','2026-10-21 18:12:44'),
(1360,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com` onmouseover=`/*xss0028*/','24683fdd-76d8-45f6-b4e9-7c3414e10e9c','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:45','2026-10-21 18:12:45'),
(1361,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\" autofocus onfocus=\"/*xss0027*/','9dee4ec0-f01d-4813-b4cf-cd83ed413204','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:45','2026-10-21 18:12:45'),
(1362,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com%3Cscript%3E/*xss0029*/%3C/script%3E','4ded9a6e-7b52-4748-8eda-518a3a808cc6','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:46','2026-10-21 18:12:46'),
(1363,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com%253Cscript%253E/*xss0030*/%253C/script%253E','3948fa6c-d885-460a-93a0-4f071d95e616','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:46','2026-10-21 18:12:46'),
(1364,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com&lt;script&gt;/*xss0031*/&lt;/script&gt;','ff367286-7a7a-4f09-bc89-03a30e4e2b08','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:48','2026-10-21 18:12:48'),
(1365,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<scr<script>ipt>/*xss0032*/</scr</script>ipt>','692b9853-0e36-4e7b-ad4a-4e8e6d3d3cc2','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:48','2026-10-21 18:12:48'),
(1366,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<scr\0ipt>/*xss0033*/</scr\0ipt>','ceaea111-1403-4b30-9f8c-9fc9b42ab59b','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:48','2026-10-21 18:12:48'),
(1367,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<scr\0ipt>/*xss0033*/</scr\0ipt>','5ea0d5b3-56f8-42ba-88d9-d0706f0ebd0f','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:48','2026-10-21 18:12:48'),
(1368,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.comjavascript:/*-/*`/*\\`/*\'/*\"/**/(/* */oNcliCk=/*xss0036*/ )//','f3181bdc-2e8f-47df-900e-0379e104341a','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:49','2026-10-21 18:12:49'),
(1369,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com\'\"><img src=x onerror=\"/*xss0035*/\">','d8a0b6d7-43c5-4109-b05f-8e90766e0c9d','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:49','2026-10-21 18:12:49'),
(1370,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<div style=\"background:url(javascript:/*xss0038*/)\">','f072cd2b-1469-49fe-9778-f164c5b5abc9','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:50','2026-10-21 18:12:50'),
(1371,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<style>@import \'javascript:/*xss0037*/\';</style>','4c294918-bcf6-45d7-89f7-66d21f850cc6','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:50','2026-10-21 18:12:50'),
(1372,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<svg><animate onbegin=\"/*xss0040*/\" attributeName=\"x\" dur=\"1s\">','92994700-6d70-47d1-8082-c84620c174ea','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:51','2026-10-21 18:12:51'),
(1373,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<svg><script>/*xss0039*/</script></svg>','a610215e-5050-4ac0-b779-f07b83a82bb9','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:51','2026-10-21 18:12:51'),
(1374,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<meta http-equiv=\"refresh\" content=\"0;url=javascript:/*xss0041*/\">','b42d68b1-2ba1-4795-9ccf-0d8b713b2ced','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:52','2026-10-21 18:12:52'),
(1375,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<form action=\"javascript:/*xss0042*/\"><input type=submit></form>','9f3c5614-d3dd-4634-892e-5bc6466168b9','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:52','2026-10-21 18:12:52'),
(1376,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<object data=\"javascript:/*xss0043*/\">','3c9f5d96-5168-4259-9c67-356dc1aa1789','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:53','2026-10-21 18:12:53'),
(1377,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com<embed src=\"javascript:/*xss0044*/\">','4b474514-7616-45cd-b33e-d77b94a7e4fa','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:53','2026-10-21 18:12:53'),
(1378,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9bd343ed-7e56-4482-9744-cd68036f7202','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:54','2026-10-21 18:12:54'),
(1379,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','330ec55f-6d37-4a1f-87bc-cc0e5bbdc484','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:54','2026-10-21 18:12:54'),
(1380,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9f5abfdc-4538-474e-9e25-8fb8e91c353d','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:55','2026-10-21 18:12:55'),
(1381,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0bbdf263-63d8-4f9f-a493-1845ce4bb991','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:55','2026-10-21 18:12:55'),
(1382,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4d1685b9-bace-4e59-9a94-2b5c7519c1e9','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:56','2026-10-21 18:12:56'),
(1383,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','7d59ec9b-740e-4537-a954-ed0153efd3f7','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:56','2026-10-21 18:12:56'),
(1384,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3107a7a9-7402-4bd4-bec4-26abda8113bb','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:56','2026-10-21 18:12:56'),
(1385,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','92e21a12-eea7-4aa5-96a4-d921557642bc','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:56','2026-10-21 18:12:56'),
(1386,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','27cee37e-466a-4980-8531-915bf55387e5','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:57','2026-10-21 18:12:57'),
(1387,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','4a48d89e-a672-4bff-b9e4-624db1734bbd','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:57','2026-10-21 18:12:57'),
(1388,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c7adb9a6-4227-42ab-b453-7c3d13b39734','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:59','2026-10-21 18:12:59'),
(1389,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','2d077162-8569-4a17-8d99-3dff2570e8a5','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:59','2026-10-21 18:12:59'),
(1390,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','954ce660-ef79-46aa-8278-f60dd3d7a3f2','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:12:59','2026-10-21 18:12:59'),
(1391,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','ea73a77a-6225-4851-ab82-4aca5977ba95','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:00','2026-10-21 18:13:00'),
(1392,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6a16a2b5-6077-4191-8118-c6ad91a267d1','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:00','2026-10-21 18:13:00'),
(1393,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a2ce3a50-752d-4b37-9e4f-6744a2005e75','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:00','2026-10-21 18:13:00'),
(1394,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','45601566-b6b7-41e0-9584-5c81649d2a1c','49.146.57.217, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:01','2026-10-21 18:13:01'),
(1395,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','a873beb3-31b0-464d-bb91-ec1e291a0b90','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:01','2026-10-21 18:13:01'),
(1396,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3c6c21b3-804e-43d4-8d23-a85608843f30','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:02','2026-10-21 18:13:02'),
(1397,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','c955ce1c-6231-405e-bdd9-7afa976d9dfc','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:02','2026-10-21 18:13:02'),
(1398,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','2f2863aa-d3fe-454f-ac03-ecb133037f94','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:03','2026-10-21 18:13:03'),
(1399,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','9f4e3cc5-9df8-470a-8a30-8a42e7bb7470','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:04','2026-10-21 18:13:04'),
(1400,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','25dcd8b1-2a0e-49e4-aabb-5466c987aa1b','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:04','2026-10-21 18:13:04'),
(1401,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','e5b88f9b-3375-43d4-b8c3-448f3cb9ac18','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:04','2026-10-21 18:13:04'),
(1402,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','32f50ac2-552c-41d8-b97a-bc428117b620','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:05','2026-10-21 18:13:05'),
(1403,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','651f21c5-b283-4237-a38a-2961c5e86873','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:05','2026-10-21 18:13:05'),
(1404,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','fa56cdd0-2079-44b1-a16e-0211d71c9b89','49.146.57.217, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:05','2026-10-21 18:13:05'),
(1405,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','061b2b85-e700-4e0a-97a7-6507166952a6','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:06','2026-10-21 18:13:06'),
(1406,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','f3438aee-8521-4e17-8b6b-a97bce6e62eb','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:06','2026-10-21 18:13:06'),
(1407,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','3a236462-9f68-42d6-b759-75d8e67abb2a','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:07','2026-10-21 18:13:07'),
(1408,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','12986489-a94b-4b48-8ad2-29ffd3cccf81','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:08','2026-10-21 18:13:08'),
(1409,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0374bf6c-0a34-46d2-9327-5690d45e1360','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:08','2026-10-21 18:13:08'),
(1410,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','35d0e29a-44db-42e0-9fc6-2de1171e492a','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:10','2026-10-21 18:13:10'),
(1411,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','64ed636b-236e-4c83-bb04-582096379eb2','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:10','2026-10-21 18:13:10'),
(1412,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','fc39cf04-b0df-4326-b673-e84364910584','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:10','2026-10-21 18:13:10'),
(1413,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','d66afadd-eac3-4c8f-b5df-b7625c54a548','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:10','2026-10-21 18:13:10'),
(1414,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','8f5a5fc8-7746-41a8-974e-0e7aca1ded17','49.146.57.217, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:11','2026-10-21 18:13:11'),
(1415,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','0d5fec45-7e18-4096-a55c-e56f3d30b7fa','49.146.57.217, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:11','2026-10-21 18:13:11'),
(1416,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','fd874a8d-bc6b-469b-81dc-39a194d88d48','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:12','2026-10-21 18:13:12'),
(1417,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5f2db796-de79-4b6c-9c6b-ad0eeb08c763','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:12','2026-10-21 18:13:12'),
(1418,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','5cbacae2-5f87-4002-9d63-51948133e898','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:14','2026-10-21 18:13:14'),
(1419,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','6e10ad7a-9e57-4aa5-8caa-b47bc7b4e161','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:14','2026-10-21 18:13:14'),
(1420,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','571a4170-c75e-418b-baa5-7ad9ca32d34f','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:14','2026-10-21 18:13:14'),
(1421,NULL,'login_failure','login_attempt',NULL,NULL,'test@example.com','029b62ee-ce53-49e4-9843-f075d048f209','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScanner/1.0','Login failed: invalid credentials or inactive account.','2026-10-21 18:13:14','2026-10-21 18:13:14'),
(1422,NULL,'login_failure','login_attempt',NULL,NULL,'owner@lightdiamond.test','3a68a19a-cd5f-40df-8e78-710ebf4dadb3','49.146.57.217, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-21 18:40:37','2026-10-21 18:40:37'),
(1423,2,'login_success','login','users',2,NULL,'f3cc518b-d7e5-4edd-b075-9bfa0eef0f84','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-22 03:45:27','2026-10-22 03:45:27'),
(1424,1,'login_success','login','users',1,NULL,'48595736-9a63-43e1-be7f-829cbd79c81a','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-22 03:59:08','2026-10-22 03:59:08'),
(1425,1,'user_created','user_created','users',99,NULL,NULL,NULL,NULL,'Created user \'jayvee\' with role_id=1','2026-10-22 04:03:03','2026-10-22 04:03:03'),
(1426,2,'login_success','login','users',2,NULL,'00e20853-9036-4be0-b0bc-a1b91aa74ed8','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-22 04:10:06','2026-10-22 04:10:06'),
(1427,2,'user_provisioned','user_provisioned','users',100,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'employee2\' for employee_id=94','2026-10-22 04:23:53','2026-10-22 04:23:53'),
(1428,NULL,'login_success','login','users',100,NULL,'7f9212b7-72e7-4dd8-8be4-cb11ac97d6ba','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-22 04:25:51','2026-10-22 04:25:51'),
(1429,2,'login_success','login','users',2,NULL,'44e58574-73c2-4949-a564-7f0170f13415','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-22 04:41:53','2026-10-22 04:41:53'),
(1430,2,'salary_updated','salary_updated','salary',107,NULL,NULL,NULL,NULL,'Updated from salary_id=106 to new salary_id=107, rate=800 from 2026-10-30','2026-10-22 04:42:50','2026-10-22 04:42:50'),
(1431,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','2da9399f-ca44-42f1-a608-f0d9aeb22db9','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-22 04:45:12','2026-10-22 04:45:12'),
(1432,1,'login_success','login','users',1,NULL,'1c6ff17f-56ca-45fb-aa28-8b5db7b50fe5','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-22 04:45:28','2026-10-22 04:45:28'),
(1433,1,'password_reset','password_reset','users',100,NULL,NULL,NULL,NULL,'Password reset by BusinessOwner (user_id=1) for user \'employee2\'','2026-10-22 05:06:15','2026-10-22 05:06:15'),
(1434,2,'login_success','login','users',2,NULL,'eab04a84-ccbd-4afc-980f-901dbcfb7423','122.3.73.126, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-22 05:06:41','2026-10-22 05:06:41'),
(1435,2,'salary_archived','salary_archived','salary',82,NULL,NULL,NULL,NULL,'Archived salary_id=82','2026-10-22 05:17:57','2026-10-22 05:17:57'),
(1436,NULL,'login_failure','login_attempt',NULL,NULL,'employee@test','ee3c5c50-8bef-43cd-a917-7d5f2c8617d6','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-22 05:33:24','2026-10-22 05:33:24'),
(1437,NULL,'login_success','login','users',100,NULL,'c1c0de49-b2b3-4549-ae20-1f004cf44357','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-22 05:33:36','2026-10-22 05:33:36'),
(1438,2,'login_success','login','users',2,NULL,'d51746a7-b17a-44ee-951f-6c5c2cbb5b56','122.3.73.126, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 06:06:31','2026-10-24 06:06:31'),
(1439,1,'login_success','login','users',1,NULL,'b3f17fdd-07a0-47e0-ae8f-08c4e2392e4d','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 06:07:02','2026-10-24 06:07:02'),
(1440,1,'user_updated','user_updated','users',100,NULL,NULL,NULL,NULL,'Updated user_id=100: username=\'employee1\', role_id=3, status=\'Active\'','2026-10-24 06:09:01','2026-10-24 06:09:01'),
(1441,1,'user_status_changed','user_status_changed','users',100,NULL,NULL,NULL,NULL,'Status changed to \'Inactive\' for user_id=100','2026-10-24 06:10:23','2026-10-24 06:10:23'),
(1442,1,'user_status_changed','user_status_changed','users',100,NULL,NULL,NULL,NULL,'Status changed to \'Active\' for user_id=100','2026-10-24 06:10:32','2026-10-24 06:10:32'),
(1443,1,'user_status_changed','user_status_changed','users',100,NULL,NULL,NULL,NULL,'Status changed to \'Inactive\' for user_id=100','2026-10-24 06:10:36','2026-10-24 06:10:36'),
(1444,1,'user_status_changed','user_status_changed','users',100,NULL,NULL,NULL,NULL,'Status changed to \'Active\' for user_id=100','2026-10-24 06:10:40','2026-10-24 06:10:40'),
(1445,1,'user_status_changed','user_status_changed','users',100,NULL,NULL,NULL,NULL,'Status changed to \'Inactive\' for user_id=100','2026-10-24 06:10:46','2026-10-24 06:10:46'),
(1446,1,'user_status_changed','user_status_changed','users',100,NULL,NULL,NULL,NULL,'Status changed to \'Active\' for user_id=100','2026-10-24 06:11:02','2026-10-24 06:11:02'),
(1447,1,'user_archived','user_archived','users',100,NULL,NULL,NULL,NULL,'Archived user_id=100','2026-10-24 06:11:56','2026-10-24 06:11:56'),
(1448,NULL,'login_failure','login_attempt',NULL,NULL,'employee1','8620b3ec-2e34-4272-b189-31b34b0ae81e','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-24 06:12:50','2026-10-24 06:12:50'),
(1449,NULL,'login_failure','login_attempt',NULL,NULL,'employee1','e953beb7-75ba-42bf-a344-2fa1475c4c87','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-24 06:12:59','2026-10-24 06:12:59'),
(1450,1,'login_success','login','users',1,NULL,'e70aed53-29d0-426d-a795-4487939f45ee','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 06:13:16','2026-10-24 06:13:16'),
(1451,2,'login_success','login','users',2,NULL,'08f12529-019a-4560-9629-b7ddfa2b6930','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 06:13:57','2026-10-24 06:13:57'),
(1452,2,'user_provisioned','user_provisioned','users',101,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'nash.acosta\' for employee_id=95','2026-10-24 06:21:18','2026-10-24 06:21:18'),
(1453,1,'login_success','login','users',1,NULL,'bf0b4f1e-85fc-4c16-b8f4-1b66f0e2b8f2','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 06:26:33','2026-10-24 06:26:33'),
(1454,2,'login_success','login','users',2,NULL,'486414f1-8867-4f19-8124-a372ec2424c3','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 06:30:00','2026-10-24 06:30:00'),
(1455,2,'upload_document','upload_document','employee_document',4,NULL,NULL,NULL,NULL,'{\"employee_id\":94,\"document_id\":4,\"description\":\"Uploaded: scene.jpg\"}','2026-10-24 06:37:20','2026-10-24 06:37:20'),
(1456,2,'attendance_adjusted','adjust_attendance','attendance',582,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-05\",\"reason\":\"yes\",\"old\":{\"time_in\":\"07:00:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:00:00\",\"time_out\":\"18:00:00\",\"overtime_minutes\":120}}','2026-10-24 07:08:19','2026-10-24 07:08:19'),
(1457,2,'attendance_policy_flag_reviewed','review_attendance_policy_flag','attendance_policy_flag',5,NULL,NULL,NULL,NULL,'Flag 5 reviewed as Reviewed. Action taken: Cleaning the toilet.','2026-10-24 07:09:42','2026-10-24 07:09:42'),
(1458,1,'login_success','login','users',1,NULL,'b450a8f5-61f2-4b5e-b105-b82b092ada0d','49.149.0.209, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 07:25:42','2026-10-24 07:25:42'),
(1459,1,'user_updated','user_updated','users',85,NULL,NULL,NULL,NULL,'Updated user_id=85: username=\'ronan.delacruz\', role_id=2, status=\'Active\'','2026-10-24 07:26:06','2026-10-24 07:26:06'),
(1460,NULL,'login_failure','login_attempt',NULL,NULL,'ronanDelacruz@lightdiamond.com','cf29a779-1d65-4274-abce-211fa73bd347','49.149.0.209, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-24 07:26:25','2026-10-24 07:26:25'),
(1461,NULL,'login_failure','login_attempt',NULL,NULL,'ronanDelacruz@lightdiamond.com','b9f56497-6cee-4f7f-b584-3921b3e955f6','49.149.0.209, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-24 07:26:40','2026-10-24 07:26:40'),
(1462,NULL,'login_success','login','users',85,NULL,'d06dda41-4629-40f1-a3bd-2d76b285c163','49.149.0.209, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 07:27:03','2026-10-24 07:27:03'),
(1463,1,'login_success','login','users',1,NULL,'3a084152-7573-4ef1-b6c6-07fe4c65f766','49.149.0.209, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 07:39:24','2026-10-24 07:39:24'),
(1464,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','8af9b342-06a5-4389-aaaf-4da2a254d699','49.149.0.209, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-24 07:50:40','2026-10-24 07:50:40'),
(1465,2,'login_success','login','users',2,NULL,'407b4c6a-640b-4044-8ca0-1ffc1a7e8b25','49.149.0.209, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 07:55:44','2026-10-24 07:55:44'),
(1466,1,'login_success','login','users',1,NULL,'858cc8d7-4a48-4dce-86dd-4cfeb110ab42','49.149.0.209, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 07:55:57','2026-10-24 07:55:57'),
(1467,2,'salary_created','salary_created','salary',109,NULL,NULL,NULL,NULL,'Created salary_id=109 for employee_id=80 at rate=900 from 2026-10-24','2026-10-24 08:01:53','2026-10-24 08:01:53'),
(1468,2,'salary_updated','salary_updated','salary',110,NULL,NULL,NULL,NULL,'Updated from salary_id=109 to new salary_id=110, rate=500 from 2026-11-25','2026-10-24 08:04:51','2026-10-24 08:04:51'),
(1469,2,'salary_updated','salary_updated','salary',111,NULL,NULL,NULL,NULL,'Updated from salary_id=105 to new salary_id=111, rate=500.00 from 2026-10-30','2026-10-24 08:06:53','2026-10-24 08:06:53'),
(1470,NULL,'login_success','login','users',3,NULL,'a88b6e51-e20f-4715-97b3-4bf693989c4e','49.149.0.209, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 08:25:35','2026-10-24 08:25:35'),
(1471,1,'login_success','login','users',1,NULL,'9f2ed8ce-5d55-4535-964d-d068c1f69746','49.149.0.209, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 08:26:30','2026-10-24 08:26:30'),
(1472,1,'user_updated','user_updated','users',85,NULL,NULL,NULL,NULL,'Updated user_id=85: username=\'ronan.delacruz\', role_id=3, status=\'Active\'','2026-10-24 08:26:54','2026-10-24 08:26:54'),
(1473,NULL,'login_success','login','users',85,NULL,'071ab7f8-f028-4f3d-882e-92be3b7f3988','49.149.0.209, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 08:27:36','2026-10-24 08:27:36'),
(1474,2,'login_success','login','users',2,NULL,'9d9c1d9c-c770-40d1-bc4c-aac7edfbc7ba','49.149.0.209, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 08:33:42','2026-10-24 08:33:42'),
(1475,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','5a7f439f-bdc3-4c38-bd1b-f9ff800e2c9e','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-24 10:10:07','2026-10-24 10:10:07'),
(1476,2,'login_success','login','users',2,NULL,'f5b2c23a-31a0-41f4-85f2-d8781bb1699e','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 10:10:14','2026-10-24 10:10:14'),
(1477,2,'login_success','login','users',2,NULL,'c8782a0d-7145-4cdf-9b9a-13ace0786462','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 12:44:05','2026-10-24 12:44:05'),
(1478,1,'login_success','login','users',1,NULL,'3c8a2ac3-1c68-4235-b3de-2ffd48cf90ff','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 12:45:16','2026-10-24 12:45:16'),
(1479,2,'login_success','login','users',2,NULL,'de5012c4-4e3b-42df-a6e7-84893a410890','49.149.26.158, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 12:46:33','2026-10-24 12:46:33'),
(1480,2,'login_success','login','users',2,NULL,'91640c0b-a195-4c6e-a3ec-c6a5343260c1','49.149.26.158, 152.233.33.162','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 16:44:50','2026-10-24 16:44:50'),
(1481,2,'user_updated','user_updated','users',98,NULL,NULL,NULL,NULL,'Updated user_id=98: username=\'manny.linsaw\', role_id=3, status=\'Active\'','2026-10-24 16:45:18','2026-10-24 16:45:18'),
(1482,2,'login_success','login','users',2,NULL,'752c3c0a-050b-4e6a-a226-763931edc216','49.149.26.158, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 17:23:38','2026-10-24 17:23:38'),
(1483,NULL,'login_success','login','users',94,NULL,'29faa99f-d624-4127-a0b8-79f0576f832e','49.149.0.209, 152.233.15.120','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Mobile Safari/537.36','User logged in successfully.','2026-10-24 18:39:05','2026-10-24 18:39:05'),
(1484,2,'login_success','login','users',2,NULL,'e83b1653-523a-4010-bd93-f49fb29a1933','49.149.0.209, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 18:39:35','2026-10-24 18:39:35'),
(1485,NULL,'login_failure','login_attempt',NULL,NULL,'jianearielleee@gmail.com','5d1765c5-4cb3-45e1-9e31-eed7de6671ba','49.149.0.209, 152.233.15.120','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-24 18:40:43','2026-10-24 18:40:43'),
(1486,2,'user_updated','user_updated','users',94,NULL,NULL,NULL,NULL,'Updated user_id=94: username=\'lovely.paguntalan\', role_id=3, status=\'Active\'','2026-10-24 18:43:11','2026-10-24 18:43:11'),
(1487,NULL,'login_success','login','users',94,NULL,'c6dd7c48-c7d7-4791-808e-6cd94e0daf58','49.149.0.209, 152.233.15.123','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 18:43:36','2026-10-24 18:43:36'),
(1488,NULL,'login_success','login','users',94,NULL,'3b52c205-cc0f-49a5-846c-cde5960c1425','49.149.0.209, 152.233.68.97','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 18:46:38','2026-10-24 18:46:38'),
(1489,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@test.com','27fcd3f7-f0a9-4a0d-8b55-49c1e030de23','165.99.251.95, 152.233.68.98','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/155.0.8059.43 Safari/537.36 [FB_IAB/FB4A;FBAV/584.1.0.61.98;]','Login failed: invalid credentials or inactive account.','2026-10-24 22:08:55','2026-10-24 22:08:55'),
(1490,2,'login_success','login','users',2,NULL,'8801bbed-1bce-4a90-86b7-3886b3ea76fc','165.99.251.95, 152.233.68.98','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/155.0.8059.43 Safari/537.36 [FB_IAB/FB4A;FBAV/584.1.0.61.98;]','User logged in successfully.','2026-10-24 22:09:30','2026-10-24 22:09:30'),
(1491,2,'login_success','login','users',2,NULL,'c1c09dc0-b369-4944-bb54-22bfc745b738','165.99.251.95, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-24 22:14:47','2026-10-24 22:14:47'),
(1492,2,'login_success','login','users',2,NULL,'0d80b2a3-75ba-4708-80e4-e87ce39bd257','111.90.245.254, 152.233.68.98','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','User logged in successfully.','2026-10-25 00:36:51','2026-10-25 00:36:51'),
(1493,2,'login_success','login','users',2,NULL,'a8bbd741-1db0-4e71-81b9-2fe46fb5a5c5','111.90.243.96, 152.233.68.98','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','User logged in successfully.','2026-10-25 03:02:21','2026-10-25 03:02:21'),
(1494,2,'login_success','login','users',2,NULL,'c066007a-fd4d-4f7a-9e9f-d6b3d1413736','175.158.240.57, 152.233.33.165','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','User logged in successfully.','2026-10-25 04:37:56','2026-10-25 04:37:56'),
(1495,2,'login_success','login','users',2,NULL,'4765c4d4-28e9-4724-bea4-9ee6643b53ee','175.158.240.57, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 04:45:22','2026-10-25 04:45:22'),
(1496,2,'user_updated','user_updated','users',95,NULL,NULL,NULL,NULL,'Updated user_id=95: username=\'dave.dalipe\', role_id=3, status=\'Active\'','2026-10-25 04:59:03','2026-10-25 04:59:03'),
(1497,2,'password_reset','password_reset','users',95,NULL,NULL,NULL,NULL,'Password reset by HRHead (user_id=2) for user \'dave.dalipe\'','2026-10-25 04:59:47','2026-10-25 04:59:47'),
(1498,NULL,'login_success','login','users',95,NULL,'6760e650-4a35-4042-bc8f-044a38aa58d3','175.158.240.57, 152.233.33.162','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:00:22','2026-10-25 05:00:22'),
(1499,2,'login_success','login','users',2,NULL,'f4d7e893-6443-4248-9d49-97fb975935ee','175.158.240.57, 152.233.33.165','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:00:50','2026-10-25 05:00:50'),
(1500,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','2f10c087-6e48-4998-95aa-278a43c8e50e','165.99.250.41, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 05:08:25','2026-10-25 05:08:25'),
(1501,2,'login_success','login','users',2,NULL,'4b07fa48-0bcf-4123-bf80-f8ebfb2403e6','165.99.250.41, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:08:32','2026-10-25 05:08:32'),
(1502,2,'login_success','login','users',2,NULL,'60efd217-cd39-4f10-9d42-3724b9339269','111.90.244.225, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:09:19','2026-10-25 05:09:19'),
(1503,2,'user_updated','user_updated','users',93,NULL,NULL,NULL,NULL,'Updated user_id=93: username=\'isabela.tayong\', role_id=3, status=\'Active\'','2026-10-25 05:13:45','2026-10-25 05:13:45'),
(1504,2,'password_reset','password_reset','users',93,NULL,NULL,NULL,NULL,'Password reset by HRHead (user_id=2) for user \'isabela.tayong\'','2026-10-25 05:14:38','2026-10-25 05:14:38'),
(1505,2,'login_success','login','users',2,NULL,'c0da82d1-a441-4cb2-9fb4-f1dbe554492c','175.158.236.136, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:15:20','2026-10-25 05:15:20'),
(1506,2,'password_reset','password_reset','users',93,NULL,NULL,NULL,NULL,'Password reset by HRHead (user_id=2) for user \'isabela.tayong\'','2026-10-25 05:15:44','2026-10-25 05:15:44'),
(1507,NULL,'login_success','login','users',93,NULL,'81f93682-1426-4ab2-aefd-af330d55a87f','175.158.236.136, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:16:10','2026-10-25 05:16:10'),
(1508,2,'login_success','login','users',2,NULL,'a0cd52a2-132a-4031-aff7-faef4548fa2f','175.158.236.136, 152.233.33.165','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:20:18','2026-10-25 05:20:18'),
(1509,2,'user_updated','user_updated','users',92,NULL,NULL,NULL,NULL,'Updated user_id=92: username=\'joshua.pugay\', role_id=3, status=\'Active\'','2026-10-25 05:24:31','2026-10-25 05:24:31'),
(1510,2,'password_reset','password_reset','users',92,NULL,NULL,NULL,NULL,'Password reset by HRHead (user_id=2) for user \'joshua.pugay\'','2026-10-25 05:25:30','2026-10-25 05:25:30'),
(1511,NULL,'login_success','login','users',92,NULL,'671962a3-74e5-42d5-a26a-ad5484ec4d98','175.158.236.136, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:26:05','2026-10-25 05:26:05'),
(1512,2,'login_success','login','users',2,NULL,'a699fe64-9d80-4d64-afc1-625c799d61e5','175.158.236.136, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:29:41','2026-10-25 05:29:41'),
(1513,2,'user_updated','user_updated','users',91,NULL,NULL,NULL,NULL,'Updated user_id=91: username=\'irish.bansilao\', role_id=3, status=\'Active\'','2026-10-25 05:31:21','2026-10-25 05:31:21'),
(1514,2,'password_reset','password_reset','users',91,NULL,NULL,NULL,NULL,'Password reset by HRHead (user_id=2) for user \'irish.bansilao\'','2026-10-25 05:31:50','2026-10-25 05:31:50'),
(1515,2,'user_updated','user_updated','users',85,NULL,NULL,NULL,NULL,'Updated user_id=85: username=\'ronan.delacruz\', role_id=3, status=\'Active\'','2026-10-25 05:32:54','2026-10-25 05:32:54'),
(1516,NULL,'login_success','login','users',91,NULL,'05fb0ba5-903b-46ff-ba83-5fb0cc760de2','175.158.236.136, 152.233.33.163','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:35:00','2026-10-25 05:35:00'),
(1517,2,'login_success','login','users',2,NULL,'c9c8fc2c-0e8b-4156-9961-43497660f368','175.158.236.136, 152.233.33.162','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:35:43','2026-10-25 05:35:43'),
(1518,NULL,'login_success','login','users',85,NULL,'36da1d54-ca25-4560-84c0-774040e1666e','175.158.236.136, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:36:58','2026-10-25 05:36:58'),
(1519,2,'login_success','login','users',2,NULL,'ddd77213-ba7e-429f-a6ae-f3e767cdc000','175.158.236.136, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:39:48','2026-10-25 05:39:48'),
(1520,2,'login_success','login','users',2,NULL,'b9dd51c3-4c2f-4bf7-927c-dfbe7af0d020','175.158.236.136, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:40:11','2026-10-25 05:40:11'),
(1521,2,'payroll_cancelled','cancel_payroll_run','payroll_run',12,NULL,NULL,NULL,NULL,'{\"previous_status\":\"Draft\",\"reason\":\"Revise\"}','2026-10-25 05:40:33','2026-10-25 05:40:33'),
(1522,2,'user_updated','user_updated','users',90,NULL,NULL,NULL,NULL,'Updated user_id=90: username=\'albert.indo\', role_id=3, status=\'Active\'','2026-10-25 05:40:57','2026-10-25 05:40:57'),
(1523,2,'password_reset','password_reset','users',90,NULL,NULL,NULL,NULL,'Password reset by HRHead (user_id=2) for user \'albert.indo\'','2026-10-25 05:42:16','2026-10-25 05:42:16'),
(1524,2,'payroll_cancelled','cancel_payroll_run','payroll_run',13,NULL,NULL,NULL,NULL,'{\"previous_status\":\"Draft\",\"reason\":\"Revise\"}','2026-10-25 05:43:46','2026-10-25 05:43:46'),
(1525,2,'payroll_cancelled','cancel_payroll_run','payroll_run',11,NULL,NULL,NULL,NULL,'{\"previous_status\":\"Draft\",\"reason\":\"Revise\"}','2026-10-25 05:43:57','2026-10-25 05:43:57'),
(1526,2,'payroll_cancelled','cancel_payroll_run','payroll_run',9,NULL,NULL,NULL,NULL,'{\"previous_status\":\"Draft\",\"reason\":\"Revise\"}','2026-10-25 05:44:33','2026-10-25 05:44:33'),
(1527,2,'login_success','login','users',2,NULL,'1da0f075-54bf-4af2-b730-1be1ca87effe','175.158.236.136, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:45:06','2026-10-25 05:45:06'),
(1528,2,'user_updated','user_updated','users',85,NULL,NULL,NULL,NULL,'Updated user_id=85: username=\'ronan.delacruz\', role_id=3, status=\'Active\'','2026-10-25 05:45:31','2026-10-25 05:45:31'),
(1529,2,'login_success','login','users',2,NULL,'4f33dbcc-84e1-4049-bf41-02bd7a7db905','175.158.236.136, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:45:43','2026-10-25 05:45:43'),
(1530,NULL,'login_success','login','users',85,NULL,'a5ab11fc-d98a-42a5-b3df-475ce4119a38','175.158.236.136, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:46:33','2026-10-25 05:46:33'),
(1531,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','601693a1-d171-4c10-a2d2-d43e639f551a','175.158.236.136, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 05:46:57','2026-10-25 05:46:57'),
(1532,NULL,'login_success','login','users',85,NULL,'5046850b-43b8-4b5d-9a7e-85d0d0c655e6','175.158.236.136, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:49:02','2026-10-25 05:49:02'),
(1533,2,'login_success','login','users',2,NULL,'01fc21a1-7e9b-42b6-b1b9-d8c01ac754f0','175.158.236.136, 152.233.33.164','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 05:50:12','2026-10-25 05:50:12'),
(1534,2,'user_updated','user_updated','users',87,NULL,NULL,NULL,NULL,'Updated user_id=87: username=\'amara.laurence\', role_id=3, status=\'Active\'','2026-10-25 05:59:05','2026-10-25 05:59:05'),
(1535,2,'password_reset','password_reset','users',87,NULL,NULL,NULL,NULL,'Password reset by HRHead (user_id=2) for user \'amara.laurence\'','2026-10-25 06:01:22','2026-10-25 06:01:22'),
(1536,NULL,'login_success','login','users',87,NULL,'3ced922d-a6b2-4549-b0b3-51f77497f447','175.158.236.136, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 06:01:49','2026-10-25 06:01:49'),
(1537,2,'login_success','login','users',2,NULL,'edf5f876-3718-4fe5-9922-738cfc292a8b','175.158.236.136, 152.233.33.165','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 06:06:19','2026-10-25 06:06:19'),
(1538,2,'user_updated','user_updated','users',88,NULL,NULL,NULL,NULL,'Updated user_id=88: username=\'linda.lebuna\', role_id=3, status=\'Active\'','2026-10-25 06:10:19','2026-10-25 06:10:19'),
(1539,2,'password_reset','password_reset','users',88,NULL,NULL,NULL,NULL,'Password reset by HRHead (user_id=2) for user \'linda.lebuna\'','2026-10-25 06:10:43','2026-10-25 06:10:43'),
(1540,NULL,'login_success','login','users',88,NULL,'cfb8b16b-6f7d-4b75-8fc9-2acbb5ef9f2e','175.158.236.136, 152.233.33.163','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 06:12:18','2026-10-25 06:12:18'),
(1541,2,'login_success','login','users',2,NULL,'8b9ea160-a7fe-485f-8e98-bf03a6aa3eae','175.158.236.136, 152.233.33.163','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 06:16:41','2026-10-25 06:16:41'),
(1542,2,'user_updated','user_updated','users',86,NULL,NULL,NULL,NULL,'Updated user_id=86: username=\'melanie.vidal\', role_id=3, status=\'Active\'','2026-10-25 06:18:47','2026-10-25 06:18:47'),
(1543,2,'user_updated','user_updated','users',86,NULL,NULL,NULL,NULL,'Updated user_id=86: username=\'melanie.vidal\', role_id=3, status=\'Active\'','2026-10-25 06:19:00','2026-10-25 06:19:00'),
(1544,2,'user_updated','user_updated','users',86,NULL,NULL,NULL,NULL,'Updated user_id=86: username=\'melanie.vidal\', role_id=3, status=\'Active\'','2026-10-25 06:19:05','2026-10-25 06:19:05'),
(1545,2,'password_reset','password_reset','users',86,NULL,NULL,NULL,NULL,'Password reset by HRHead (user_id=2) for user \'melanie.vidal\'','2026-10-25 06:19:26','2026-10-25 06:19:26'),
(1546,NULL,'login_success','login','users',86,NULL,'27cfb47d-acf2-4a55-9898-d375ab549af1','175.158.236.136, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 06:19:49','2026-10-25 06:19:49'),
(1547,1,'login_success','login','users',1,NULL,'3bb534b9-1e3e-4269-8292-5a0b4d465d79','175.158.236.136, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 06:25:04','2026-10-25 06:25:04'),
(1548,2,'login_success','login','users',2,NULL,'04a14303-2209-42d4-b7de-1ff4d4c49103','175.158.236.136, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 06:25:24','2026-10-25 06:25:24'),
(1549,1,'login_success','login','users',1,NULL,'c41aa2af-4e8e-4055-8f49-56a2edbc9695','175.158.236.136, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 06:25:50','2026-10-25 06:25:50'),
(1550,2,'login_success','login','users',2,NULL,'54e2d435-7364-4b5e-ae6e-75868d3d6b89','175.158.236.136, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 06:26:21','2026-10-25 06:26:21'),
(1551,1,'login_success','login','users',1,NULL,'c62fd331-d25b-4cd9-92f1-234b72ec6899','175.158.236.136, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 06:30:58','2026-10-25 06:30:58'),
(1552,2,'login_success','login','users',2,NULL,'f3aff10c-ab69-421e-be9f-2bd04dff96dd','175.158.236.136, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 06:34:37','2026-10-25 06:34:37'),
(1553,2,'payroll_cancelled','cancel_payroll_run','payroll_run',4,NULL,NULL,NULL,NULL,'{\"previous_status\":\"Returned\",\"reason\":\"Revise\"}','2026-10-25 06:56:30','2026-10-25 06:56:30'),
(1554,2,'payroll_cancelled','cancel_payroll_run','payroll_run',10,NULL,NULL,NULL,NULL,'{\"previous_status\":\"Returned\",\"reason\":\"Revision\"}','2026-10-25 06:57:01','2026-10-25 06:57:01'),
(1555,2,'login_success','login','users',2,NULL,'84c646d9-95d2-4ca9-874e-7ffd063f568a','111.90.244.123, 152.233.68.98','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','User logged in successfully.','2026-10-25 07:23:07','2026-10-25 07:23:07'),
(1556,2,'login_success','login','users',2,NULL,'10e50681-46c9-459e-9458-c7089321fec7','165.99.250.41, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 08:11:02','2026-10-25 08:11:02'),
(1557,2,'login_success','login','users',2,NULL,'1abdbed7-7aa7-4dff-96bd-f323356378f9','165.99.250.41, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 08:50:28','2026-10-25 08:50:28'),
(1558,2,'login_success','login','users',2,NULL,'3d389693-50ef-4840-9527-66182d60b8a5','165.99.250.46, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 08:51:42','2026-10-25 08:51:42'),
(1559,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','a743edbc-b9eb-40e2-a035-ef363ded4561','165.99.250.41, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 08:52:08','2026-10-25 08:52:08'),
(1560,1,'login_success','login','users',1,NULL,'223465fc-effe-4cd8-9c07-55833ffedef2','165.99.250.41, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 08:52:26','2026-10-25 08:52:26'),
(1561,NULL,'login_failure','login_attempt',NULL,NULL,'GFGFG','e7ccdcd9-4a67-46d6-b16d-e39df82ef72e','165.99.250.41, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','Login failed: invalid credentials or inactive account.','2026-10-25 08:53:05','2026-10-25 08:53:05'),
(1562,1,'login_success','login','users',1,NULL,'b36a53bb-a5dd-4f0f-b632-4e9d14e0cca0','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 08:53:15','2026-10-25 08:53:15'),
(1563,NULL,'login_success','login','users',92,NULL,'e95b97e6-0c0b-4206-901f-1dc72274f8cf','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 08:53:39','2026-10-25 08:53:39'),
(1564,2,'login_success','login','users',2,NULL,'de14b8d9-c310-4f38-8279-489e4c94b0e5','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 08:53:59','2026-10-25 08:53:59'),
(1565,NULL,'login_failure','login_attempt',NULL,NULL,'owner@lightdiamond.ph','84d99492-f749-4e89-a186-98241967c023','165.99.250.41, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','Login failed: invalid credentials or inactive account.','2026-10-25 08:54:02','2026-10-25 08:54:02'),
(1566,1,'login_success','login','users',1,NULL,'5a61b839-1951-4cc5-8908-5368d71071ce','165.99.250.41, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','User logged in successfully.','2026-10-25 08:54:24','2026-10-25 08:54:24'),
(1567,1,'login_success','login','users',1,NULL,'ff0c5861-33ac-4f03-8d53-2361357a33ec','165.99.250.41, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','User logged in successfully.','2026-10-25 08:55:57','2026-10-25 08:55:57'),
(1568,1,'password_reset','password_reset','users',85,NULL,NULL,NULL,NULL,'Password reset by BusinessOwner (user_id=1) for user \'ronan.delacruz\'','2026-10-25 08:56:19','2026-10-25 08:56:19'),
(1569,2,'login_success','login','users',2,NULL,'4243fd33-8d61-45ab-9d38-4cb78b004149','165.99.250.41, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 08:57:07','2026-10-25 08:57:07'),
(1570,NULL,'login_success','login','users',85,NULL,'4eadfe8e-4a8b-4b6e-9535-1474957be6d7','165.99.250.41, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 08:57:53','2026-10-25 08:57:53'),
(1571,1,'user_created','user_created','users',119,NULL,NULL,NULL,NULL,'Created user \'test\' with role_id=1','2026-10-25 09:00:07','2026-10-25 09:00:07'),
(1572,1,'login_success','login','users',1,NULL,'7af0eff8-9b10-4da8-9208-19bc13e7a3b3','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:00:23','2026-10-25 09:00:23'),
(1573,2,'login_success','login','users',2,NULL,'9edf3df2-53fe-4913-a0aa-0375bc96341d','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:00:46','2026-10-25 09:00:46'),
(1574,1,'user_updated','user_updated','users',119,NULL,NULL,NULL,NULL,'Updated user_id=119: username=\'test1\', role_id=1, status=\'Active\'','2026-10-25 09:01:18','2026-10-25 09:01:18'),
(1575,1,'login_success','login','users',1,NULL,'d3fd0ec3-3dd0-4e06-a766-95d4e249f503','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:01:45','2026-10-25 09:01:45'),
(1576,1,'user_updated','user_updated','users',119,NULL,NULL,NULL,NULL,'Updated user_id=119: username=\'test12\', role_id=1, status=\'Active\'','2026-10-25 09:02:25','2026-10-25 09:02:25'),
(1577,1,'user_status_changed','user_status_changed','users',119,NULL,NULL,NULL,NULL,'Status changed to \'Inactive\' for user_id=119','2026-10-25 09:02:32','2026-10-25 09:02:32'),
(1578,1,'user_status_changed','user_status_changed','users',119,NULL,NULL,NULL,NULL,'Status changed to \'Active\' for user_id=119','2026-10-25 09:02:36','2026-10-25 09:02:36'),
(1579,1,'user_archived','user_archived','users',119,NULL,NULL,NULL,NULL,'Archived user_id=119','2026-10-25 09:02:42','2026-10-25 09:02:42'),
(1580,1,'user_updated','user_updated','users',84,NULL,NULL,NULL,NULL,'Updated user_id=84: username=\'alden.jay\', role_id=3, status=\'Active\'','2026-10-25 09:03:12','2026-10-25 09:03:12'),
(1581,1,'user_status_changed','user_status_changed','users',99,NULL,NULL,NULL,NULL,'Status changed to \'Inactive\' for user_id=99','2026-10-25 09:03:34','2026-10-25 09:03:34'),
(1582,1,'user_status_changed','user_status_changed','users',99,NULL,NULL,NULL,NULL,'Status changed to \'Active\' for user_id=99','2026-10-25 09:03:45','2026-10-25 09:03:45'),
(1583,1,'user_archived','user_archived','users',85,NULL,NULL,NULL,NULL,'Archived user_id=85','2026-10-25 09:04:09','2026-10-25 09:04:09'),
(1584,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','bf3a4d4d-a696-40a7-9161-aac7a6954440','165.99.250.41, 152.233.33.165','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','Login failed: invalid credentials or inactive account.','2026-10-25 09:04:26','2026-10-25 09:04:26'),
(1585,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','d70f1266-098c-45c0-a3a4-63237388526d','165.99.250.41, 152.233.33.161','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','Login failed: invalid credentials or inactive account.','2026-10-25 09:04:40','2026-10-25 09:04:40'),
(1586,1,'login_success','login','users',1,NULL,'08c853f1-1d7d-43db-9b7e-f55dd827da31','165.99.250.41, 152.233.33.163','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','User logged in successfully.','2026-10-25 09:05:03','2026-10-25 09:05:03'),
(1587,2,'login_success','login','users',2,NULL,'620ae6aa-79f1-4ef5-bbf0-fd65a9e3db2b','165.99.250.41, 152.233.33.165','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:05:19','2026-10-25 09:05:19'),
(1588,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','2b731d36-9fa5-4cae-b1be-cccb383323df','165.99.250.41, 152.233.33.163','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 09:05:56','2026-10-25 09:05:56'),
(1589,2,'login_success','login','users',2,NULL,'47ff5376-bc9c-4c61-b6a0-137d44807ba5','165.99.250.41, 152.233.33.161','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:06:00','2026-10-25 09:06:00'),
(1590,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','a8e24aa5-13dd-4b7b-9f99-9108f641a9b5','165.99.250.41, 152.233.33.161','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 09:06:14','2026-10-25 09:06:14'),
(1591,1,'user_created','user_created','users',120,NULL,NULL,NULL,NULL,'Created user \'test\' with role_id=2','2026-10-25 09:06:17','2026-10-25 09:06:17'),
(1592,1,'login_success','login','users',1,NULL,'caa834c4-b302-4ebf-88ba-4394b62dc852','165.99.250.41, 152.233.33.165','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:06:44','2026-10-25 09:06:44'),
(1593,NULL,'login_failure','login_attempt',NULL,NULL,'test','3a387452-531c-49b8-804a-6c5017f4acfb','165.99.250.41, 152.233.33.163','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','Login failed: invalid credentials or inactive account.','2026-10-25 09:06:45','2026-10-25 09:06:45'),
(1594,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','68ccbe06-4190-4405-bd10-4605709dbf00','165.99.250.41, 152.233.33.161','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','Login failed: invalid credentials or inactive account.','2026-10-25 09:06:59','2026-10-25 09:06:59'),
(1595,1,'login_success','login','users',1,NULL,'a6167907-cefb-49e1-bc68-87c6c49ee69e','165.99.250.41, 152.233.33.165','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','User logged in successfully.','2026-10-25 09:07:08','2026-10-25 09:07:08'),
(1596,1,'user_status_changed','user_status_changed','users',120,NULL,NULL,NULL,NULL,'Status changed to \'Inactive\' for user_id=120','2026-10-25 09:07:40','2026-10-25 09:07:40'),
(1597,1,'user_status_changed','user_status_changed','users',120,NULL,NULL,NULL,NULL,'Status changed to \'Active\' for user_id=120','2026-10-25 09:07:47','2026-10-25 09:07:47'),
(1598,2,'login_success','login','users',2,NULL,'1cb924ce-6726-44cd-983c-75226f791d85','165.99.250.41, 152.233.33.163','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:07:57','2026-10-25 09:07:57'),
(1599,NULL,'login_success','login','users',91,NULL,'c0723b44-a480-4316-8451-63c6139787fc','165.99.250.41, 152.233.33.164','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','User logged in successfully.','2026-10-25 09:09:07','2026-10-25 09:09:07'),
(1600,NULL,'login_failure','login_attempt',NULL,NULL,'jianegambao22@gmail.com','4fb63fde-2c72-4b25-bc2a-a4927a7d2b08','165.99.250.41, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 09:10:38','2026-10-25 09:10:38'),
(1601,NULL,'login_success','login','users',95,NULL,'06c2c6b0-0748-4740-a4bc-c324a806a0e6','165.99.250.41, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:10:57','2026-10-25 09:10:57'),
(1602,2,'login_success','login','users',2,NULL,'b5eb03e2-b6d2-4cfd-b72e-34a735230fde','165.99.250.41, 152.233.33.162','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','User logged in successfully.','2026-10-25 09:11:10','2026-10-25 09:11:10'),
(1603,2,'user_provisioned','user_provisioned','users',121,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'juan.delacruz\' for employee_id=96','2026-10-25 09:11:42','2026-10-25 09:11:42'),
(1604,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','6c6c7ddb-6cde-40d1-ac9d-212f89b44d02','165.99.250.41, 152.233.33.165','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 09:12:31','2026-10-25 09:12:31'),
(1605,1,'login_success','login','users',1,NULL,'2f9e4e0c-3ed9-4ed7-be01-a6b9bafd62a9','165.99.250.41, 152.233.33.161','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:12:45','2026-10-25 09:12:45'),
(1606,2,'login_success','login','users',2,NULL,'aa29a45f-054c-4b88-a39b-2589c23eef7b','165.99.250.41, 152.233.33.163','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:13:15','2026-10-25 09:13:15'),
(1607,NULL,'login_failure','login_attempt',NULL,NULL,'jianegamboa24@gmail.com','c1c2517a-8f96-4c73-a9ec-6507cef07314','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 09:13:52','2026-10-25 09:13:52'),
(1608,2,'user_provisioned','user_provisioned','users',123,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'test.test\' for employee_id=98','2026-10-25 09:14:01','2026-10-25 09:14:01'),
(1609,NULL,'login_failure','login_attempt',NULL,NULL,'jianegamboa24@gmail.com','9063e790-79fc-4eb9-bcaf-e9cab3bd93f3','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 09:14:08','2026-10-25 09:14:08'),
(1610,2,'login_success','login','users',2,NULL,'b362e2a8-79ca-460f-b9b6-56ac23583f02','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:14:53','2026-10-25 09:14:53'),
(1611,2,'user_updated','user_updated','users',121,NULL,NULL,NULL,NULL,'Updated user_id=121: username=\'juan.delacruz\', role_id=3, status=\'Active\'','2026-10-25 09:15:57','2026-10-25 09:15:57'),
(1612,2,'password_reset','password_reset','users',121,NULL,NULL,NULL,NULL,'Password reset by HRHead (user_id=2) for user \'juan.delacruz\'','2026-10-25 09:17:03','2026-10-25 09:17:03'),
(1613,NULL,'login_success','login','users',121,NULL,'4d1dfdf2-2b4d-4329-b3eb-d797ce1b5664','165.99.250.41, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:17:07','2026-10-25 09:17:07'),
(1614,1,'user_updated','user_updated','users',123,NULL,NULL,NULL,NULL,'Updated user_id=123: username=\'test.test\', role_id=3, status=\'Active\'','2026-10-25 09:19:34','2026-10-25 09:19:34'),
(1615,2,'upload_document','upload_document','employee_document',5,NULL,NULL,NULL,NULL,'{\"employee_id\":86,\"document_id\":5,\"description\":\"Uploaded: Screenshot 2026-10-23 111844.png\"}','2026-10-25 09:19:36','2026-10-25 09:19:36'),
(1616,1,'user_status_changed','user_status_changed','users',121,NULL,NULL,NULL,NULL,'Status changed to \'Inactive\' for user_id=121','2026-10-25 09:19:48','2026-10-25 09:19:48'),
(1617,1,'user_status_changed','user_status_changed','users',121,NULL,NULL,NULL,NULL,'Status changed to \'Active\' for user_id=121','2026-10-25 09:19:54','2026-10-25 09:19:54'),
(1618,1,'user_archived','user_archived','users',121,NULL,NULL,NULL,NULL,'Archived user_id=121','2026-10-25 09:20:02','2026-10-25 09:20:02'),
(1619,1,'login_success','login','users',1,NULL,'4c225c5d-67c9-4f91-9fa4-614abc1240b8','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:20:56','2026-10-25 09:20:56'),
(1620,1,'user_created','user_created','users',124,NULL,NULL,NULL,NULL,'Created user \'aldentest\' with role_id=3','2026-10-25 09:23:11','2026-10-25 09:23:11'),
(1621,1,'user_updated','user_updated','users',124,NULL,NULL,NULL,NULL,'Updated user_id=124: username=\'aldentest2\', role_id=3, status=\'Active\'','2026-10-25 09:23:28','2026-10-25 09:23:28'),
(1622,1,'user_status_changed','user_status_changed','users',124,NULL,NULL,NULL,NULL,'Status changed to \'Inactive\' for user_id=124','2026-10-25 09:23:38','2026-10-25 09:23:38'),
(1623,1,'user_status_changed','user_status_changed','users',124,NULL,NULL,NULL,NULL,'Status changed to \'Active\' for user_id=124','2026-10-25 09:23:42','2026-10-25 09:23:42'),
(1624,1,'user_archived','user_archived','users',124,NULL,NULL,NULL,NULL,'Archived user_id=124','2026-10-25 09:23:50','2026-10-25 09:23:50'),
(1625,2,'upload_document','upload_document','employee_document',6,NULL,NULL,NULL,NULL,'{\"employee_id\":1,\"document_id\":6,\"description\":\"Uploaded: images (1).jpg\"}','2026-10-25 09:24:00','2026-10-25 09:24:00'),
(1626,2,'login_success','login','users',2,NULL,'f24a787f-98c1-458b-a862-aa81db8d4e9a','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:24:10','2026-10-25 09:24:10'),
(1627,2,'attendance_adjusted','adjust_attendance','attendance',402,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-08-27\",\"reason\":\"TESTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT\",\"old\":{\"time_in\":\"07:04:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:04:00\",\"time_out\":\"21:25:00\",\"overtime_minutes\":321}}','2026-10-25 09:25:21','2026-10-25 09:25:21'),
(1628,2,'user_provisioned','user_provisioned','users',125,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'aaron.candido\' for employee_id=99','2026-10-25 09:27:55','2026-10-25 09:27:55'),
(1629,1,'login_success','login','users',1,NULL,'7a850add-be9f-4282-b2cd-8c28e0b575f8','165.99.250.41, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:29:31','2026-10-25 09:29:31'),
(1630,2,'login_success','login','users',2,NULL,'3a2f398a-0606-4025-9cbd-042f98e74ba2','165.99.250.41, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:33:43','2026-10-25 09:33:43'),
(1631,2,'login_success','login','users',2,NULL,'84566ca5-9be4-49d1-bbab-5ea306343f25','165.99.250.41, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:34:23','2026-10-25 09:34:23'),
(1632,2,'user_provisioned','user_provisioned','users',126,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'ariannejoy.carian\' for employee_id=100','2026-10-25 09:36:41','2026-10-25 09:36:41'),
(1633,NULL,'login_success','login','users',126,NULL,'c6a81680-2930-4840-93bf-bd22726a36f5','165.99.250.41, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:37:14','2026-10-25 09:37:14'),
(1634,2,'upload_document','upload_document','employee_document',7,NULL,NULL,NULL,NULL,'{\"employee_id\":86,\"document_id\":7,\"description\":\"Uploaded: Screenshot 2026-10-08 010912.png\"}','2026-10-25 09:37:59','2026-10-25 09:37:59'),
(1635,1,'login_success','login','users',1,NULL,'5ad90af9-8c4a-47cd-8ae2-7545e6a1a44b','165.99.250.41, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:38:07','2026-10-25 09:38:07'),
(1636,2,'login_success','login','users',2,NULL,'2807e3db-f498-41d2-9e8f-7236173a3400','165.99.250.41, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:38:39','2026-10-25 09:38:39'),
(1637,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','61edf484-bcc8-4d52-ad97-ce713d08c646','165.99.250.41, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 09:40:24','2026-10-25 09:40:24'),
(1638,1,'login_success','login','users',1,NULL,'2f84b24e-da1b-4935-9516-c32afde7a32d','165.99.250.41, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:40:31','2026-10-25 09:40:31'),
(1639,1,'user_created','user_created','users',128,NULL,NULL,NULL,NULL,'Created user \'michaelAgustin\' with role_id=1','2026-10-25 09:41:51','2026-10-25 09:41:51'),
(1640,1,'login_success','login','users',1,NULL,'81be7844-b651-44a5-9f34-10fff0b23301','165.99.250.41, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:42:04','2026-10-25 09:42:04'),
(1641,NULL,'login_failure','login_attempt',NULL,NULL,'michaelAgustin','7de231a5-a152-4381-b921-cfb45de73229','165.99.250.41, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 09:42:44','2026-10-25 09:42:44'),
(1642,NULL,'login_success','login','users',128,NULL,'5bf3c65f-68e9-44de-8cfd-62e195e88814','165.99.250.41, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:42:55','2026-10-25 09:42:55'),
(1643,1,'login_success','login','users',1,NULL,'a93ac639-169a-4b1e-8696-7ed32502cc2f','165.99.250.41, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:43:26','2026-10-25 09:43:26'),
(1644,1,'user_status_changed','user_status_changed','users',128,NULL,NULL,NULL,NULL,'Status changed to \'Inactive\' for user_id=128','2026-10-25 09:43:35','2026-10-25 09:43:35'),
(1645,NULL,'login_failure','login_attempt',NULL,NULL,'michaelagustin@gmail.com','825e0928-d39f-44c9-b5dc-042e99851a57','165.99.250.41, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 09:43:56','2026-10-25 09:43:56'),
(1646,1,'login_success','login','users',1,NULL,'245d992c-613c-421d-8d7b-309ce0efcce8','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','User logged in successfully.','2026-10-25 09:44:19','2026-10-25 09:44:19'),
(1647,1,'login_success','login','users',1,NULL,'86d72467-3ad1-4c5d-8d71-dcfefdccca00','165.99.250.41, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:45:17','2026-10-25 09:45:17'),
(1648,NULL,'login_failure','login_attempt',NULL,NULL,'jianegamboa342@gmail.com','004ed697-b82a-40f2-98be-af34ab053379','165.99.250.41, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 09:45:59','2026-10-25 09:45:59'),
(1649,NULL,'login_success','login','users',88,NULL,'a8f26ca7-e936-4be1-ba57-44d7e3782b18','165.99.250.41, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:46:19','2026-10-25 09:46:19'),
(1650,NULL,'login_failure','login_attempt',NULL,NULL,'jianegamboa32@gmail.com','a8b7a111-8eef-4e90-975d-0d17b0e0e0d0','165.99.250.41, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 09:46:51','2026-10-25 09:46:51'),
(1651,NULL,'login_success','login','users',126,NULL,'5e0157c7-93f3-44fa-b344-28c4ede34e74','165.99.250.41, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:47:07','2026-10-25 09:47:07'),
(1652,2,'login_success','login','users',2,NULL,'208c19df-2c5c-4c0c-93e6-dcbb194f6bba','165.99.250.41, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:47:38','2026-10-25 09:47:38'),
(1653,1,'login_success','login','users',1,NULL,'27a56168-8420-4f89-a391-81667bb0ca53','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','User logged in successfully.','2026-10-25 09:48:03','2026-10-25 09:48:03'),
(1654,2,'login_success','login','users',2,NULL,'e946ecc2-3c4c-411f-977a-bb850a38e68c','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','User logged in successfully.','2026-10-25 09:48:17','2026-10-25 09:48:17'),
(1655,2,'salary_created','salary_created','salary',118,NULL,NULL,NULL,NULL,'Created salary_id=118 for employee_id=1 at rate=1000 from 2026-10-25','2026-10-25 09:48:34','2026-10-25 09:48:34'),
(1656,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','b88c8110-110f-4bdd-aacf-acd64a8cbdce','165.99.250.41, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 09:48:38','2026-10-25 09:48:38'),
(1657,2,'login_success','login','users',2,NULL,'12133800-416d-45af-84a4-4df0f0cdec2e','165.99.250.41, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:48:48','2026-10-25 09:48:48'),
(1658,2,'salary_created','salary_created','salary',119,NULL,NULL,NULL,NULL,'Created salary_id=119 for employee_id=99 at rate=500 from 2026-11-25','2026-10-25 09:48:59','2026-10-25 09:48:59'),
(1659,2,'salary_updated','salary_updated','salary',120,NULL,NULL,NULL,NULL,'Updated from salary_id=107 to new salary_id=120, rate=2800.00 from 2026-11-30','2026-10-25 09:49:21','2026-10-25 09:49:21'),
(1660,2,'salary_archived','salary_archived','salary',120,NULL,NULL,NULL,NULL,'Archived salary_id=120','2026-10-25 09:49:34','2026-10-25 09:49:34'),
(1661,2,'salary_archived','salary_archived','salary',103,NULL,NULL,NULL,NULL,'Archived salary_id=103','2026-10-25 09:50:33','2026-10-25 09:50:33'),
(1662,NULL,'login_failure','login_attempt',NULL,NULL,'jianegamboa27@gmail.com','821b972e-405d-427a-b853-faa5cfb79473','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','Login failed: invalid credentials or inactive account.','2026-10-25 09:53:54','2026-10-25 09:53:54'),
(1663,NULL,'login_success','login','users',86,NULL,'136e8206-2494-4cbc-811a-7d3110bf3791','165.99.250.41, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 09:54:10','2026-10-25 09:54:10'),
(1664,NULL,'login_success','login','users',94,NULL,'a66c68e1-55c6-4616-b9a0-762848278c9b','165.99.250.41, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','User logged in successfully.','2026-10-25 09:54:30','2026-10-25 09:54:30'),
(1665,NULL,'login_failure','login_attempt',NULL,NULL,'hrehead@demo.test','aaa700ff-0315-4576-9001-302fbf970f61','165.99.250.41, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-25 10:05:37','2026-10-25 10:05:37'),
(1666,2,'login_success','login','users',2,NULL,'25aee81e-8604-414d-8d1b-744228548c68','165.99.250.41, 152.233.33.161','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 10:05:55','2026-10-25 10:05:55'),
(1667,1,'login_success','login','users',1,NULL,'dd9436a7-1561-4980-b9fc-ab683314a0c9','165.99.250.43, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 10:09:26','2026-10-25 10:09:26'),
(1668,2,'login_success','login','users',2,NULL,'f79ae73c-19d3-4793-bfed-98738b0260fc','165.99.250.43, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 10:12:22','2026-10-25 10:12:22'),
(1669,2,'login_success','login','users',2,NULL,'720d469e-ab07-43c3-9708-751f5df9b979','165.99.250.41, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 10:14:23','2026-10-25 10:14:23'),
(1670,1,'login_success','login','users',1,NULL,'a02029df-ab32-47b9-9fa6-402e1973c177','165.99.250.43, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 10:18:02','2026-10-25 10:18:02'),
(1671,1,'login_success','login','users',1,NULL,'4dfff724-7318-4cc6-9d84-7b1b50f03c8c','165.99.250.43, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-25 10:20:18','2026-10-25 10:20:18'),
(1672,NULL,'login_failure','login_attempt',NULL,NULL,'ronanDelacruz@lightdiamond.com','96949e4e-84f5-478c-a292-4057b550dcd7','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-26 08:45:36','2026-10-26 08:45:36'),
(1673,NULL,'login_failure','login_attempt',NULL,NULL,'jianearielleee@lightdiamond.com','8ef541e8-9369-4dc6-9366-6d85526efa05','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-26 08:45:49','2026-10-26 08:45:49'),
(1674,NULL,'login_success','login','users',91,NULL,'7eb82020-dd04-41e4-9c8c-361d9bd25023','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-26 08:46:30','2026-10-26 08:46:30'),
(1675,2,'login_success','login','users',2,NULL,'2d191de5-8997-4268-9b53-736668effa88','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-27 03:21:10','2026-10-27 03:21:10'),
(1676,2,'login_success','login','users',2,NULL,'4556d121-bdc5-43af-89de-ceff6c03c674','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-27 03:46:59','2026-10-27 03:46:59'),
(1677,NULL,'login_success','login','users',94,NULL,'d22807a0-c22c-40f3-9c85-b666430a4f5c','122.3.73.126, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36','User logged in successfully.','2026-10-27 05:19:33','2026-10-27 05:19:33'),
(1678,2,'login_success','login','users',2,NULL,'51466367-8acf-4310-9b97-3416b81a4834','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-27 08:41:26','2026-10-27 08:41:26'),
(1679,2,'user_provisioned','user_provisioned','users',129,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'sample.sample\' for employee_id=101','2026-10-27 08:48:39','2026-10-27 08:48:39'),
(1680,2,'login_success','login','users',2,NULL,'db68c99e-4cd3-4161-a754-5355a55ef08e','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 05:54:40','2026-10-28 05:54:40'),
(1681,1,'login_success','login','users',1,NULL,'3a4700e4-1180-4ef6-98e4-460e84ff773a','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 06:10:23','2026-10-28 06:10:23'),
(1682,NULL,'login_success','login','users',91,NULL,'29c7660b-8987-48e1-afff-99c88953b3a4','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 06:19:15','2026-10-28 06:19:15'),
(1683,2,'login_success','login','users',2,NULL,'4eb9440f-62aa-4197-990d-355947d3987a','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 06:20:14','2026-10-28 06:20:14'),
(1684,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','0547c4e2-5954-4346-a9b6-63cc63675947','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-28 06:21:53','2026-10-28 06:21:53'),
(1685,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','6ec531fb-ba7b-4f0b-a696-d46c27d8c0d7','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-10-28 06:22:13','2026-10-28 06:22:13'),
(1686,NULL,'login_success','login','users',94,NULL,'37de37c7-4fd4-4aef-b6fd-320f9e3cecbe','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 06:23:07','2026-10-28 06:23:07'),
(1687,2,'login_success','login','users',2,NULL,'b25af55b-2237-4a9a-b610-c51eb189213a','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 06:26:51','2026-10-28 06:26:51'),
(1688,2,'login_success','login','users',2,NULL,'edeec05d-abe5-44ae-9c84-2618e4cfa489','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 08:32:03','2026-10-28 08:32:03'),
(1689,2,'login_success','login','users',2,NULL,'5cdc48d3-2bd2-43a1-8fb7-ddef620f3c4d','175.158.240.19, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 08:32:21','2026-10-28 08:32:21'),
(1690,1,'login_success','login','users',1,NULL,'4104e019-4a10-4caf-915a-b563f64c5e70','122.3.73.126, 152.233.33.163','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 08:47:03','2026-10-28 08:47:03'),
(1691,1,'login_success','login','users',1,NULL,'3f8d18ae-da4e-4223-8bfc-6976af910521','122.3.73.126, 152.233.33.165','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 09:49:12','2026-10-28 09:49:12'),
(1692,1,'user_updated','user_updated','users',128,NULL,NULL,NULL,NULL,'Updated user_id=128: username=\'michaelAgustin\', role_id=2, status=\'Inactive\'','2026-10-28 09:51:28','2026-10-28 09:51:28'),
(1693,NULL,'login_success','login','users',3,NULL,'e4afbb15-52da-4ec3-8bc4-d53bfb5df0d6','122.3.73.126, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 10:35:01','2026-10-28 10:35:01'),
(1694,NULL,'login_success','login','users',94,NULL,'f36324ac-23b9-4722-888a-1a47a6134053','122.3.73.126, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 10:36:50','2026-10-28 10:36:50'),
(1695,2,'login_success','login','users',2,NULL,'84951ce4-6f2f-45ab-abca-7e794d8e3315','122.3.73.126, 152.233.33.162','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 10:42:35','2026-10-28 10:42:35'),
(1696,1,'login_success','login','users',1,NULL,'97ba69d4-60ae-4dff-a08b-20f001fcb011','122.3.73.126, 152.233.33.161','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 10:43:00','2026-10-28 10:43:00'),
(1697,2,'login_success','login','users',2,NULL,'943af9b2-9a76-47eb-83dc-6ad52adb1960','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 10:54:29','2026-10-28 10:54:29'),
(1698,1,'login_success','login','users',1,NULL,'7d4c9ec2-caf1-41dd-8306-a197001efc5d','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-28 11:07:46','2026-10-28 11:07:46'),
(1699,2,'login_success','login','users',2,NULL,'9db9197e-b4d2-4f3e-8cab-df9bd029006c','49.149.28.36, 152.233.33.164','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 07:14:54','2026-10-29 07:14:54'),
(1700,1,'login_success','login','users',1,NULL,'f3c59c58-d98f-4998-b365-b9ffe4a5eb21','49.149.28.36, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 08:52:03','2026-10-29 08:52:03'),
(1701,2,'login_success','login','users',2,NULL,'94fd80b0-8cb3-416a-a987-44a410672681','49.149.28.36, 152.233.33.164','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 09:06:16','2026-10-29 09:06:16'),
(1702,2,'login_success','login','users',2,NULL,'09a7cad1-eb10-446f-aa17-b09b3705d733','49.149.28.36, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 10:29:37','2026-10-29 10:29:37'),
(1703,2,'login_success','login','users',2,NULL,'00a07a41-40be-4b56-a2b4-0bf81c7cea41','49.149.28.36, 152.233.33.165','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 12:07:39','2026-10-29 12:07:39'),
(1704,NULL,'login_success','login','users',94,NULL,'6a737b68-a3ef-48ff-8f41-59e5cebcb53e','49.149.28.36, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 13:02:33','2026-10-29 13:02:33'),
(1705,1,'login_success','login','users',1,NULL,'9dc6cac0-0b39-4158-afe3-9dd75f239f9b','49.149.28.36, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 13:57:36','2026-10-29 13:57:36'),
(1706,2,'login_success','login','users',2,NULL,'7a773388-7e1a-46a2-a42a-1344b623168d','49.149.28.36, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 14:04:23','2026-10-29 14:04:23'),
(1707,1,'login_success','login','users',1,NULL,'9c9cf8db-ac32-4c50-b1f1-8abd37bb3c46','49.149.28.36, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 14:22:05','2026-10-29 14:22:05'),
(1708,2,'login_success','login','users',2,NULL,'1286a795-afaf-4887-b45c-b01cfffb4c54','49.149.28.36, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 14:30:03','2026-10-29 14:30:03'),
(1709,2,'login_success','login','users',2,NULL,'c78e44b9-9674-4e93-b363-cfae9aa74db0','49.149.28.36, 152.233.33.164','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 14:36:13','2026-10-29 14:36:13'),
(1710,1,'login_success','login','users',1,NULL,'4c0209e7-2e77-4cda-8b2e-08e9ff3b10bc','49.149.28.36, 152.233.33.164','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 14:36:34','2026-10-29 14:36:34'),
(1711,2,'login_success','login','users',2,NULL,'f72dd705-1d81-4651-bb6a-2fc06bd8e54f','49.149.28.36, 152.233.33.164','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 14:51:48','2026-10-29 14:51:48'),
(1712,1,'login_success','login','users',1,NULL,'ad73c536-4587-48c0-a8ac-180512f5d0ab','49.149.28.36, 152.233.33.161','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 14:53:36','2026-10-29 14:53:36'),
(1713,2,'login_success','login','users',2,NULL,'9cc57c6c-c7d5-4ed6-81bf-8147751553a2','49.149.28.36, 152.233.33.162','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 14:54:19','2026-10-29 14:54:19'),
(1714,2,'salary_updated','salary_updated','salary',123,NULL,NULL,NULL,NULL,'Updated from salary_id=122 to new salary_id=123, rate=600 from 2026-10-30','2026-10-29 14:59:34','2026-10-29 14:59:34'),
(1715,2,'salary_archived','salary_archived','salary',123,NULL,NULL,NULL,NULL,'Archived salary_id=123','2026-10-29 15:25:48','2026-10-29 15:25:48'),
(1716,2,'login_success','login','users',2,NULL,'fe6a59ec-3d86-4d13-b4f9-1d46d8329c6b','49.149.28.36, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 16:27:42','2026-10-29 16:27:42'),
(1717,2,'login_success','login','users',2,NULL,'237e89f5-9921-4e49-b03c-915e7536ff92','49.149.28.36, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 18:41:34','2026-10-29 18:41:34'),
(1718,1,'login_success','login','users',1,NULL,'db2d1886-fd66-405e-8ae8-9d01464ae95c','49.149.28.36, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-29 19:19:27','2026-10-29 19:19:27'),
(1719,2,'login_success','login','users',2,NULL,'74d7e534-96a1-4904-9bdf-27c871f47b7c','49.149.28.36, 152.233.33.165','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-30 12:31:54','2026-10-30 12:31:54'),
(1720,2,'login_success','login','users',2,NULL,'e00adecc-342c-4674-9d13-51985978b321','49.149.28.36, 152.233.33.164','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-10-30 13:06:11','2026-10-30 13:06:11'),
(1721,2,'login_success','login','users',2,NULL,'35b80a24-c43f-428c-8471-72c98576e3f6','180.191.139.34, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-01 04:30:01','2026-11-01 04:30:01'),
(1722,1,'login_success','login','users',1,NULL,'518c0632-900e-4518-bbe0-5832644829a1','180.191.139.34, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-01 04:31:28','2026-11-01 04:31:28'),
(1723,2,'login_success','login','users',2,NULL,'514884c9-6e43-48a6-9827-2741e98a2eae','180.191.139.34, 152.233.33.164','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-01 04:31:58','2026-11-01 04:31:58'),
(1724,1,'login_success','login','users',1,NULL,'f698f0b4-b749-422f-b714-aa32bf9b42cf','180.191.139.34, 152.233.33.164','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-01 04:32:22','2026-11-01 04:32:22'),
(1725,1,'login_success','login','users',1,NULL,'756bcb75-9783-440e-a34d-7bbc6c1b7f29','165.99.251.95, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 06:20:30','2026-11-04 06:20:30'),
(1726,1,'user_status_changed','user_status_changed','users',129,NULL,NULL,NULL,NULL,'Status changed to \'Active\' for user_id=129','2026-11-04 06:51:05','2026-11-04 06:51:05'),
(1727,1,'user_unarchived','user_unarchived','users',124,NULL,NULL,NULL,NULL,'Unarchived user_id=124 — status restored to Inactive','2026-11-04 06:51:27','2026-11-04 06:51:27'),
(1728,1,'user_updated','user_updated','users',129,NULL,NULL,NULL,NULL,'Updated user_id=129: username=\'Sample\', role_id=3, status=\'Active\'','2026-11-04 06:51:46','2026-11-04 06:51:46'),
(1729,1,'user_archived','user_archived','users',129,NULL,NULL,NULL,NULL,'Archived user_id=129','2026-11-04 06:52:04','2026-11-04 06:52:04'),
(1730,1,'user_unarchived','user_unarchived','users',85,NULL,NULL,NULL,NULL,'Unarchived user_id=85 — status restored to Inactive','2026-11-04 06:52:48','2026-11-04 06:52:48'),
(1731,2,'login_success','login','users',2,NULL,'0760030a-c6f0-4f7f-a668-52aa5f14339c','110.54.205.234, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 06:53:06','2026-11-04 06:53:06'),
(1732,1,'login_success','login','users',1,NULL,'78fabc90-b686-47f8-bcca-2be25af447a3','110.54.205.234, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 06:54:14','2026-11-04 06:54:14'),
(1733,1,'user_archived','user_archived','users',85,NULL,NULL,NULL,NULL,'Archived user_id=85','2026-11-04 06:54:34','2026-11-04 06:54:34'),
(1734,2,'login_success','login','users',2,NULL,'477c1b33-ce18-43b1-9a80-a7a185ad9d49','110.54.205.234, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 06:54:49','2026-11-04 06:54:49'),
(1735,1,'login_success','login','users',1,NULL,'1e162a8c-c40d-470d-8ca2-1ba5c67f5a8e','110.54.205.234, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 06:55:36','2026-11-04 06:55:36'),
(1736,1,'user_unarchived','user_unarchived','users',121,NULL,NULL,NULL,NULL,'Unarchived user_id=121 — status restored to Inactive','2026-11-04 06:55:56','2026-11-04 06:55:56'),
(1737,1,'user_unarchived','user_unarchived','users',85,NULL,NULL,NULL,NULL,'Unarchived user_id=85 — status restored to Inactive','2026-11-04 06:56:29','2026-11-04 06:56:29'),
(1738,2,'login_success','login','users',2,NULL,'b7d7e0b3-05dd-45c7-9e1c-79b829e4a4e2','110.54.205.234, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 06:58:00','2026-11-04 06:58:00'),
(1739,2,'user_provisioned','user_provisioned','users',130,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'cheche.gonzales\' for employee_id=102','2026-11-04 07:10:21','2026-11-04 07:10:21'),
(1740,NULL,'login_failure','login_attempt',NULL,NULL,'alejandradangan','47cca07d-f80e-46eb-aa58-ec1aabfd3bac','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:10:54','2026-11-04 07:10:54'),
(1741,NULL,'login_success','login','users',130,NULL,'9e8758a3-57d6-4557-850e-10e827f859b2','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 07:11:06','2026-11-04 07:11:06'),
(1742,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','c9d03e90-1822-4eeb-8b84-af1760fa0a1c','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:11:53','2026-11-04 07:11:53'),
(1743,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','58551d58-6ad2-4164-b318-94e4e25a61d5','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:12:01','2026-11-04 07:12:01'),
(1744,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','ce0f7da3-b254-45de-a0cf-414de3de40f4','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:12:08','2026-11-04 07:12:08'),
(1745,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','56d74012-85fb-482c-8090-9510b9bccfe6','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:12:11','2026-11-04 07:12:11'),
(1746,1,'login_success','login','users',1,NULL,'303833ae-f0a3-4bc7-92ad-0202198aa7bc','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 07:12:18','2026-11-04 07:12:18'),
(1747,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','784b7cad-2866-441d-8a7a-0425eba76eec','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:12:44','2026-11-04 07:12:44'),
(1748,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','532192ad-0a31-499d-9321-10ee851db0f3','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:13:00','2026-11-04 07:13:00'),
(1749,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','cfbd4187-1c0b-4f20-bfd0-d4580582a861','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:13:12','2026-11-04 07:13:12'),
(1750,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','67060c2e-2f2e-4683-a241-a555e0c96655','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','Login failed: invalid credentials or inactive account.','2026-11-04 07:14:11','2026-11-04 07:14:11'),
(1751,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','83e1df44-c07c-4c04-83d3-0d4a25d83fe8','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0','Login failed: invalid credentials or inactive account.','2026-11-04 07:14:33','2026-11-04 07:14:33'),
(1752,1,'login_success','login','users',1,NULL,'1d81816d-97a8-4589-a6d4-9aa53d837c02','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 07:14:45','2026-11-04 07:14:45'),
(1753,1,'password_reset','password_reset','users',2,NULL,NULL,NULL,NULL,'Password reset by BusinessOwner (user_id=1) for user \'hrhead\'','2026-11-04 07:15:22','2026-11-04 07:15:22'),
(1754,2,'login_success','login','users',2,NULL,'8742513b-18c5-44fc-81a3-4554e1fe3d94','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 07:15:51','2026-11-04 07:15:51'),
(1755,2,'upload_document','upload_document','employee_document',8,NULL,NULL,NULL,NULL,'{\"employee_id\":102,\"document_id\":8,\"description\":\"Uploaded: _dfd-lvl1-Manage Attendance.drawio.png\"}','2026-11-04 07:21:11','2026-11-04 07:21:11'),
(1756,2,'attendance_adjusted','adjust_attendance','attendance',572,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-24\",\"reason\":\"c\",\"old\":{\"time_in\":\"06:44:00\",\"time_out\":\"16:30:00\",\"overtime_minutes\":46},\"new\":{\"time_in\":\"06:44:00\",\"time_out\":\"17:30:00\",\"overtime_minutes\":106}}','2026-11-04 07:27:58','2026-11-04 07:27:58'),
(1757,NULL,'login_failure','login_attempt',NULL,NULL,'alejandradangan@gmail.com','238bd85d-955d-45b9-a434-52e44102cfef','110.54.205.234, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:31:00','2026-11-04 07:31:00'),
(1758,NULL,'login_success','login','users',130,NULL,'e8505ce0-abf8-4261-b7d7-0b4a6ebf8427','110.54.205.234, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 07:31:24','2026-11-04 07:31:24'),
(1759,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','7f7b0b76-c8de-441b-928c-53ccb845ca92','110.54.205.234, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:32:45','2026-11-04 07:32:45'),
(1760,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','5c549dc7-1d56-44b1-b406-6a2ab1914332','110.54.205.234, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:33:10','2026-11-04 07:33:10'),
(1761,2,'login_success','login','users',2,NULL,'14835469-ca54-47c1-b1fc-c3d8acfc6620','110.54.205.234, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 07:33:42','2026-11-04 07:33:42'),
(1762,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','d395d181-7fea-4477-b75d-907eb65ba0ed','110.54.205.234, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:34:09','2026-11-04 07:34:09'),
(1763,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','8c157655-10ba-4524-aec3-f7c3a95f41f7','110.54.205.234, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:34:30','2026-11-04 07:34:30'),
(1764,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','68d8461c-b848-4e95-989d-7fe8647fbd7f','110.54.205.234, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:35:11','2026-11-04 07:35:11'),
(1765,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','dc2ce82a-96b7-4fb1-86eb-83e9f473bf8a','110.54.205.234, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:35:26','2026-11-04 07:35:26'),
(1766,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','6d34339b-02b1-4a38-812d-f32bd27db2b3','110.54.205.234, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:36:35','2026-11-04 07:36:35'),
(1767,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','874a9fc0-1ca0-46a9-b169-1d84deab15d3','110.54.205.234, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:37:04','2026-11-04 07:37:04'),
(1768,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','c93a97f8-a1a9-4258-941c-44e56a11a3fd','110.54.205.234, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:37:41','2026-11-04 07:37:41'),
(1769,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','7640e748-5a6e-4224-92d2-0d1c94b71a6e','110.54.205.234, 152.233.68.105','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','Login failed: invalid credentials or inactive account.','2026-11-04 07:38:53','2026-11-04 07:38:53'),
(1770,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','a807bdbe-043d-45b3-b1a1-cdddb54ae44b','110.54.205.234, 152.233.15.120','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','Login failed: invalid credentials or inactive account.','2026-11-04 07:41:44','2026-11-04 07:41:44'),
(1771,1,'login_success','login','users',1,NULL,'9537f729-72ef-493f-836f-4cdb9663d120','49.149.10.112, 152.233.15.121','Mozilla/5.0 (Linux; Android 16; Infinix X6886 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/156.0.8078.47 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/585.0.0.53.94;]','User logged in successfully.','2026-11-04 07:44:42','2026-11-04 07:44:42'),
(1772,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','3c5dca91-e0f6-42e0-8be1-76ca491ac7c4','110.54.205.234, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-04 07:46:04','2026-11-04 07:46:04'),
(1773,1,'login_success','login','users',1,NULL,'e8e40ae2-1007-46a5-aac0-e833cc283fb7','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 07:49:10','2026-11-04 07:49:10'),
(1774,2,'login_success','login','users',2,NULL,'6466ab7e-674f-4214-8010-927e6f8c8b4b','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 07:49:39','2026-11-04 07:49:39'),
(1775,1,'login_success','login','users',1,NULL,'7c008531-c54d-4008-8a5e-8cecc4021363','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 07:49:57','2026-11-04 07:49:57'),
(1776,2,'login_success','login','users',2,NULL,'abd9c458-19c9-4941-8996-5853b8310f78','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 07:50:32','2026-11-04 07:50:32'),
(1777,NULL,'login_success','login','users',130,NULL,'7d3e301a-5129-4b00-ad2c-3d8ae61bca65','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 07:51:20','2026-11-04 07:51:20'),
(1778,2,'login_success','login','users',2,NULL,'517c1537-49f8-4235-a755-bfd51ca3175e','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 07:54:30','2026-11-04 07:54:30'),
(1779,1,'login_success','login','users',1,NULL,'69b59ed6-260c-4dce-a514-c41ec91241cc','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 07:54:57','2026-11-04 07:54:57'),
(1780,2,'login_success','login','users',2,NULL,'98b7004e-f61a-4fca-b01e-96a4043ff0d3','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 07:55:42','2026-11-04 07:55:42'),
(1781,2,'attendance_adjusted','adjust_attendance','attendance',622,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-24\",\"reason\":\"s\",\"old\":{\"time_in\":\"07:17:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:17:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":43}}','2026-11-04 07:56:26','2026-11-04 07:56:26'),
(1782,2,'attendance_adjusted','adjust_attendance','attendance',598,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-26\",\"reason\":\"x\",\"old\":{\"time_in\":\"06:53:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:53:00\",\"time_out\":\"17:57:00\",\"overtime_minutes\":124}}','2026-11-04 07:56:58','2026-11-04 07:56:58'),
(1783,2,'attendance_adjusted','adjust_attendance','attendance',624,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-26\",\"reason\":\"c\",\"old\":{\"time_in\":\"06:49:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:49:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":71}}','2026-11-04 07:57:28','2026-11-04 07:57:28'),
(1784,2,'attendance_adjusted','adjust_attendance','attendance',649,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-25\",\"reason\":\"c\",\"old\":{\"time_in\":\"06:51:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:51:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":69}}','2026-11-04 08:01:06','2026-11-04 08:01:06'),
(1785,NULL,'login_success','login','users',130,NULL,'00391ef2-1d96-4392-b798-e5f0a01f856f','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:09:32','2026-11-04 08:09:32'),
(1786,2,'login_success','login','users',2,NULL,'63f47baf-b72c-4991-aab7-853ddcef178c','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:10:13','2026-11-04 08:10:13'),
(1787,NULL,'login_success','login','users',130,NULL,'8457f51e-f9b9-45f8-b7fd-dc34b9c07b8f','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:10:46','2026-11-04 08:10:46'),
(1788,2,'login_success','login','users',2,NULL,'8ca44ab4-26ae-4e5b-b9eb-c19f992a4270','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:11:15','2026-11-04 08:11:15'),
(1789,1,'login_success','login','users',1,NULL,'22c6b3de-b028-4960-a088-8eaa318cf5d3','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:11:54','2026-11-04 08:11:54'),
(1790,NULL,'login_success','login','users',130,NULL,'3ff35064-f79b-4d85-aafd-77cd7e60ab75','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:12:38','2026-11-04 08:12:38'),
(1791,2,'login_success','login','users',2,NULL,'0350994d-eacf-4c52-98c6-6fc256223b58','110.54.205.234, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:13:31','2026-11-04 08:13:31'),
(1792,2,'payroll_cancelled','cancel_payroll_run','payroll_run',22,NULL,NULL,NULL,NULL,'{\"previous_status\":\"Computed\",\"reason\":\"Errror\"}','2026-11-04 08:17:14','2026-11-04 08:17:14'),
(1793,2,'attendance_adjusted','adjust_attendance','attendance',575,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-28\",\"reason\":\"scaxz\",\"old\":{\"time_in\":\"07:03:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:03:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":57}}','2026-11-04 08:18:51','2026-11-04 08:18:51'),
(1794,2,'attendance_adjusted','adjust_attendance','attendance',88,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-07-01\",\"reason\":\"d\",\"old\":{\"time_in\":\"16:39:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"16:39:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":0}}','2026-11-04 08:19:27','2026-11-04 08:19:27'),
(1795,2,'attendance_adjusted','adjust_attendance','attendance',169,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-07-03\",\"reason\":\"d\",\"old\":{\"time_in\":\"06:46:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:46:00\",\"time_out\":\"17:19:00\",\"overtime_minutes\":93}}','2026-11-04 08:19:57','2026-11-04 08:19:57'),
(1796,1,'login_success','login','users',1,NULL,'abc6287b-e038-4c43-b1bf-42c5855c0619','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:22:06','2026-11-04 08:22:06'),
(1797,2,'login_success','login','users',2,NULL,'9aaaa315-cade-41cd-af5e-05538832046d','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:22:32','2026-11-04 08:22:32'),
(1798,1,'login_success','login','users',1,NULL,'e03b8c74-1520-4e5f-8ae0-e544f2c474a4','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:25:08','2026-11-04 08:25:08'),
(1799,1,'user_status_changed','user_status_changed','users',128,NULL,NULL,NULL,NULL,'Status changed to \'Active\' for user_id=128','2026-11-04 08:25:27','2026-11-04 08:25:27'),
(1800,1,'user_archived','user_archived','users',128,NULL,NULL,NULL,NULL,'Archived user_id=128','2026-11-04 08:25:34','2026-11-04 08:25:34'),
(1801,2,'login_success','login','users',2,NULL,'c92605e4-f4be-45a9-a867-ded1d31630ec','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:25:45','2026-11-04 08:25:45'),
(1802,1,'login_success','login','users',1,NULL,'9a45b751-3f34-40fb-93d2-4748258bd43c','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:26:40','2026-11-04 08:26:40'),
(1803,1,'user_archived','user_archived','users',126,NULL,NULL,NULL,NULL,'Archived user_id=126','2026-11-04 08:27:02','2026-11-04 08:27:02'),
(1804,2,'login_success','login','users',2,NULL,'d97d7687-2d77-4fb5-92b7-04abbfb5329f','110.54.205.234, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:27:24','2026-11-04 08:27:24'),
(1805,2,'payroll_cancelled','cancel_payroll_run','payroll_run',23,NULL,NULL,NULL,NULL,'{\"previous_status\":\"Computed\",\"reason\":\"error\"}','2026-11-04 08:40:39','2026-11-04 08:40:39'),
(1806,2,'payroll_cancelled','cancel_payroll_run','payroll_run',24,NULL,NULL,NULL,NULL,'{\"previous_status\":\"Computed\",\"reason\":\"error\"}','2026-11-04 08:44:15','2026-11-04 08:44:15'),
(1807,1,'login_success','login','users',1,NULL,'b97021d6-1809-43ca-bb1a-abbfd8f29b34','110.54.205.234, 152.233.33.161','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:47:40','2026-11-04 08:47:40'),
(1808,2,'login_success','login','users',2,NULL,'d39e9ccd-6017-4c59-bbee-4b8f5d1d3f46','110.54.205.234, 152.233.33.164','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:48:56','2026-11-04 08:48:56'),
(1809,1,'login_success','login','users',1,NULL,'ff431aba-6e5f-4334-bac4-cb253f5f930e','49.146.57.182, 152.233.33.163','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:52:32','2026-11-04 08:52:32'),
(1810,1,'login_success','login','users',1,NULL,'92dff8b8-ed61-419f-b532-5a6e885d1aac','110.54.205.234, 152.233.33.165','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:57:35','2026-11-04 08:57:35'),
(1811,2,'login_success','login','users',2,NULL,'a64ef20d-583e-412d-ad3e-9581c2f5138a','110.54.205.234, 152.233.33.162','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 08:58:12','2026-11-04 08:58:12'),
(1812,2,'salary_created','salary_created','salary',125,NULL,NULL,NULL,NULL,'Created salary_id=125 for employee_id=87 at rate=600 from 2026-11-05','2026-11-04 08:58:50','2026-11-04 08:58:50'),
(1813,NULL,'login_success','login','users',130,NULL,'10e4f6da-5469-4819-a9d9-806ce5c949d2','110.54.205.234, 152.233.33.163','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 09:11:21','2026-11-04 09:11:21'),
(1814,2,'login_success','login','users',2,NULL,'9fdd82e4-19a3-444f-aabc-ee34b1112d9f','110.54.205.234, 152.233.33.164','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 09:12:44','2026-11-04 09:12:44'),
(1815,1,'login_success','login','users',1,NULL,'ac176cc4-d6c0-4173-b871-5f30ad9b7a4f','110.54.205.234, 152.233.33.161','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 09:13:06','2026-11-04 09:13:06'),
(1816,2,'login_success','login','users',2,NULL,'3b2b1061-f49f-42e6-9a53-0dfb80356af0','110.54.205.234, 152.233.33.161','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-04 09:13:49','2026-11-04 09:13:49'),
(1817,1,'login_success','login','users',1,NULL,'33bdd52b-1e6f-4540-b399-994d39898547','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-05 03:15:05','2026-11-05 03:15:05'),
(1818,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','c22b6711-01b5-4c4c-bd5b-e6462b06257f','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 03:15:35','2026-11-05 03:15:35'),
(1819,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','91ae3183-73c9-453c-b51c-84bada51f0af','49.146.57.217, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 03:15:53','2026-11-05 03:15:53'),
(1820,2,'login_success','login','users',2,NULL,'1bcd7f38-7464-4e48-a870-cdc8398e91ef','165.99.251.95, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-05 03:51:18','2026-11-05 03:51:18'),
(1821,NULL,'login_success','login','users',130,NULL,'5d7cfc7d-344e-4ef3-b7f7-e597403995fb','165.99.251.95, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-05 04:35:51','2026-11-05 04:35:51'),
(1822,NULL,'login_failure','login_attempt',NULL,NULL,'almairahmaindan18@gmail.com','c4fcac3d-fe8d-4c52-9c4c-d5a790d6c5da','165.99.251.95, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 04:36:33','2026-11-05 04:36:33'),
(1823,NULL,'login_failure','login_attempt',NULL,NULL,'almairahmaindan18@gmail.com','f9b56d1f-dd69-41f4-b838-be72bf434a61','165.99.251.95, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 04:36:47','2026-11-05 04:36:47'),
(1824,NULL,'login_failure','login_attempt',NULL,NULL,'almairahmaindan18@gmail.com','4b72b761-4d4d-4cfa-89f4-75c2984bb221','165.99.251.95, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 04:37:47','2026-11-05 04:37:47'),
(1825,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','9898acae-0576-4eb5-b72e-17eee1b45e1b','165.99.251.95, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 04:38:07','2026-11-05 04:38:07'),
(1826,NULL,'login_success','login','users',91,NULL,'b63bff9d-6c26-4037-94a1-2fbfcf97d914','165.99.251.95, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-05 04:38:27','2026-11-05 04:38:27'),
(1827,NULL,'login_success','login','users',91,NULL,'ac9f9480-15db-45ce-93d0-4ec9b8934b13','165.99.250.95, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-05 04:41:23','2026-11-05 04:41:23'),
(1828,2,'login_success','login','users',2,NULL,'64cd1326-a50a-4b2f-a76e-0281df6c7a00','165.99.250.95, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-05 04:42:27','2026-11-05 04:42:27'),
(1829,NULL,'login_success','login','users',90,NULL,'565e9b03-baf0-4601-a2f4-45e0605748b6','165.99.250.95, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-05 04:45:06','2026-11-05 04:45:06'),
(1830,2,'login_success','login','users',2,NULL,'e54db177-d69a-44db-b241-5d55baf63353','165.99.251.95, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-05 04:55:54','2026-11-05 04:55:54'),
(1831,2,'attendance_adjusted','adjust_attendance','attendance',674,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-26\",\"reason\":\"sample\",\"old\":{\"time_in\":\"07:00:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:00:00\",\"time_out\":\"17:07:00\",\"overtime_minutes\":307}}','2026-11-05 05:08:06','2026-11-05 05:08:06'),
(1832,1,'login_success','login','users',1,NULL,'66c48251-aa30-4f9f-8e29-8c940f0dfc79','165.99.251.95, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-05 05:57:43','2026-11-05 05:57:43'),
(1833,2,'login_success','login','users',2,NULL,'4b780f22-1e6a-4ea5-9a03-1229acf38ecf','165.99.251.95, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-05 06:00:08','2026-11-05 06:00:08'),
(1834,1,'login_success','login','users',1,NULL,'7f9a9e57-ab18-4354-80c9-1bf14b8f2705','165.99.251.95, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-05 06:01:41','2026-11-05 06:01:41'),
(1835,2,'login_success','login','users',2,NULL,'dc526531-bc40-4589-a015-232d34ec73cc','165.99.251.95, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-05 06:02:21','2026-11-05 06:02:21'),
(1836,NULL,'login_success','login','users',91,NULL,'5c189912-099a-4340-a178-dd25c0fd0fc3','165.99.251.95, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-05 06:10:55','2026-11-05 06:10:55'),
(1837,NULL,'login_success','login','users',94,NULL,'2a24bf75-667c-497e-8f4f-80800d2ae806','165.99.251.95, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-05 06:12:37','2026-11-05 06:12:37'),
(1838,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','caff0102-8a1c-4797-a2d8-3d222a46ed4c','49.149.192.85, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 16:48:28','2026-11-05 16:48:28'),
(1839,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','641f7660-7e5a-472d-bf59-f87a17de434e','49.149.192.85, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 16:48:39','2026-11-05 16:48:39'),
(1840,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','2b7e5271-af6e-44dc-8e04-0247793e9b6e','49.149.192.85, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 16:48:49','2026-11-05 16:48:49'),
(1841,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','ec0601c8-0c09-477d-b217-d035226a56d9','49.149.192.85, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 16:48:55','2026-11-05 16:48:55'),
(1842,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','52ea9846-2b87-4032-b3f4-28714739c2dc','49.149.192.85, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 16:49:32','2026-11-05 16:49:32'),
(1843,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','a5bd1b02-b56d-46a7-85b8-15183591dc50','49.149.192.85, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 16:50:41','2026-11-05 16:50:41'),
(1844,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','958819b5-3ed1-44bc-90a1-15abc2fd2ec7','49.149.192.85, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 16:50:56','2026-11-05 16:50:56'),
(1845,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','e6d8487d-470b-4420-8536-bd5ed2232863','49.149.192.85, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 16:52:17','2026-11-05 16:52:17'),
(1846,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','4b6d3f78-37fc-462d-b061-90fe8093eb9e','49.149.192.85, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 16:52:29','2026-11-05 16:52:29'),
(1847,NULL,'login_failure','login_attempt',NULL,NULL,'golbinalden@gmail.com','53596e6b-ac4d-419c-962a-9aedd7d45efa','49.149.192.85, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-05 16:53:15','2026-11-05 16:53:15'),
(1848,1,'login_success','login','users',1,NULL,'11ef403b-e911-407e-9a88-ffff11c8a9b0','49.149.10.112, 152.233.68.97','Mozilla/5.0 (Linux; Android 16; Infinix X6886 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/156.0.8078.47 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/586.0.0.55.92;]','User logged in successfully.','2026-11-05 23:49:47','2026-11-05 23:49:47'),
(1849,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','1d140b25-e756-4575-9c7a-4276cd7a5ec1','165.99.250.89, 152.233.15.123','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/156.0.8078.47 Safari/537.36 [FB_IAB/FB4A;FBAV/585.0.0.53.94;]','Login failed: invalid credentials or inactive account.','2026-11-06 00:07:39','2026-11-06 00:07:39'),
(1850,1,'login_success','login','users',1,NULL,'fb00b98c-b0b0-4f3b-a8f4-4def40b8d958','165.99.250.89, 152.233.15.123','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/156.0.8078.47 Safari/537.36 [FB_IAB/FB4A;FBAV/585.0.0.53.94;]','User logged in successfully.','2026-11-06 00:08:06','2026-11-06 00:08:06'),
(1851,1,'login_success','login','users',1,NULL,'dd5442e3-f91c-496f-b496-6fda467bd810','49.146.57.182, 152.233.68.105','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','User logged in successfully.','2026-11-06 00:13:48','2026-11-06 00:13:48'),
(1852,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','7745c15f-d458-45a0-9ea8-c73c89ab7e05','49.149.10.112, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-06 04:43:52','2026-11-06 04:43:52'),
(1853,1,'login_success','login','users',1,NULL,'44f761c7-a056-4a11-a888-246b22ad328a','49.149.192.85, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-06 14:42:08','2026-11-06 14:42:08'),
(1854,1,'login_success','login','users',1,NULL,'47dc2b35-3311-46bb-9d1c-4c001854aac8','49.149.192.85, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-06 16:27:22','2026-11-06 16:27:22'),
(1855,2,'login_success','login','users',2,NULL,'bfef1260-1c84-4624-bf92-e769a27d9fb3','165.99.251.89, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 04:13:45','2026-11-07 04:13:45'),
(1856,1,'login_success','login','users',1,NULL,'93d8cf6c-7e87-4aba-8784-0c2b8cb5f64d','165.99.251.89, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 04:14:39','2026-11-07 04:14:39'),
(1857,2,'login_success','login','users',2,NULL,'9df7d70d-ba3b-4224-89c1-5b0a228134a7','165.99.251.89, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 04:18:40','2026-11-07 04:18:40'),
(1858,2,'attendance_adjusted','adjust_attendance','attendance',92,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-07-06\",\"reason\":\"sample\",\"old\":{\"time_in\":\"06:20:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:20:00\",\"time_out\":\"17:28:00\",\"overtime_minutes\":128}}','2026-11-07 04:31:02','2026-11-07 04:31:02'),
(1859,2,'attendance_adjusted','adjust_attendance','attendance',174,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-07-10\",\"reason\":\"sample\",\"old\":{\"time_in\":\"06:56:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:56:00\",\"time_out\":\"19:30:00\",\"overtime_minutes\":214}}','2026-11-07 04:34:26','2026-11-07 04:34:26'),
(1860,1,'login_success','login','users',1,NULL,'0a3675ad-ef34-4550-afa4-c9393505d012','49.149.217.17, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 04:49:10','2026-11-07 04:49:10'),
(1861,2,'login_success','login','users',2,NULL,'9d712b96-0b5a-4942-b53a-7f4a50bda4c3','49.149.217.17, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 04:50:05','2026-11-07 04:50:05'),
(1862,1,'login_success','login','users',1,NULL,'f124ce2b-56af-4cd4-9d28-f34bdbb66282','49.149.217.17, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 07:30:06','2026-11-07 07:30:06'),
(1863,2,'login_success','login','users',2,NULL,'28c9b4f1-d923-4723-be56-a93a1c6cc137','49.149.217.17, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 08:04:13','2026-11-07 08:04:13'),
(1864,NULL,'login_success','login','users',130,NULL,'9551fd46-336b-4668-a6fc-315fbfcef028','49.149.217.17, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 08:10:35','2026-11-07 08:10:35'),
(1865,NULL,'login_success','login','users',94,NULL,'81feaf65-cdf2-4d14-b857-d7231383f145','49.149.217.17, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 08:10:50','2026-11-07 08:10:50'),
(1866,2,'login_success','login','users',2,NULL,'31c0ae71-3766-453a-9b0e-ac3e8a1b6316','49.149.217.17, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 08:27:50','2026-11-07 08:27:50'),
(1867,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','8a366631-667c-43f3-b39b-d0a446882a2a','103.208.88.7, 152.233.15.120','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','Login failed: invalid credentials or inactive account.','2026-11-07 10:40:24','2026-11-07 10:40:24'),
(1868,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','f9f687ef-5c37-415e-9c39-787c15b1b028','103.208.88.7, 152.233.15.120','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','Login failed: invalid credentials or inactive account.','2026-11-07 10:41:06','2026-11-07 10:41:06'),
(1869,NULL,'login_success','login','users',94,NULL,'65ca00bd-19e3-40a8-8211-5b1e9baab455','49.149.10.112, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 10:41:48','2026-11-07 10:41:48'),
(1870,2,'login_success','login','users',2,NULL,'5ac72d94-8ab3-4bd2-9c58-e98d83364f6f','103.208.88.7, 152.233.15.120','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','User logged in successfully.','2026-11-07 10:42:23','2026-11-07 10:42:23'),
(1871,NULL,'login_success','login','users',95,NULL,'c1735006-060a-4e33-9a27-9200d333975b','49.149.10.112, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 10:43:16','2026-11-07 10:43:16'),
(1872,NULL,'login_success','login','users',92,NULL,'e1a55961-6620-473e-85d0-ebabbea347b8','49.149.10.112, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 10:43:58','2026-11-07 10:43:58'),
(1873,NULL,'login_success','login','users',93,NULL,'959bd524-383f-4d61-b4f9-882b212b86b7','49.149.10.112, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 10:44:41','2026-11-07 10:44:41'),
(1874,NULL,'login_success','login','users',91,NULL,'ed56a0e9-567c-400e-b790-6881c5567125','49.149.10.112, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 10:45:14','2026-11-07 10:45:14'),
(1875,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','ffd6cbc6-6ff8-4ba9-9f3f-66bbbc41249f','110.54.207.8, 152.233.68.98','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','Login failed: invalid credentials or inactive account.','2026-11-07 10:45:54','2026-11-07 10:45:54'),
(1876,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','9eaf9cae-90c6-4e06-9dd9-7a52d9604292','110.54.207.8, 152.233.68.98','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','Login failed: invalid credentials or inactive account.','2026-11-07 10:46:19','2026-11-07 10:46:19'),
(1877,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','b2d64a77-6bd7-4de8-b85e-ed0d8275c102','110.54.207.8, 152.233.68.98','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','Login failed: invalid credentials or inactive account.','2026-11-07 10:46:19','2026-11-07 10:46:19'),
(1878,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','32c06af9-2c02-4651-8245-53efb0b8c4de','110.54.207.8, 152.233.68.98','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','Login failed: invalid credentials or inactive account.','2026-11-07 10:48:00','2026-11-07 10:48:00'),
(1879,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','c4ed6a2f-549d-4323-8325-2f06151aa180','110.54.207.8, 152.233.68.98','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','Login failed: invalid credentials or inactive account.','2026-11-07 10:48:22','2026-11-07 10:48:22'),
(1880,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','8f20da49-a9f4-42b6-985f-c3abfe2394a7','110.54.207.8, 152.233.68.97','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','Login failed: invalid credentials or inactive account.','2026-11-07 11:00:28','2026-11-07 11:00:28'),
(1881,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','9488d6f0-b84f-4f90-979c-c41dc157d0ca','110.54.207.8, 152.233.68.97','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','Login failed: invalid credentials or inactive account.','2026-11-07 11:00:58','2026-11-07 11:00:58'),
(1882,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','01e77625-723e-4a9a-a367-f072e1732edd','49.149.10.112, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-07 11:04:11','2026-11-07 11:04:11'),
(1883,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','922a04ab-bded-4654-aeb5-848e10d12a31','49.149.10.112, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-07 11:04:30','2026-11-07 11:04:30'),
(1884,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','a68fd9f4-1a13-4fab-8bf8-7227a909b904','49.149.10.112, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-07 11:04:54','2026-11-07 11:04:54'),
(1885,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','882ed7f2-6927-41c4-b29b-d155b37e88b9','49.149.10.112, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-07 11:05:29','2026-11-07 11:05:29'),
(1886,1,'login_success','login','users',1,NULL,'216af2f8-f45b-462e-9c0f-3e1b304bb5f6','49.149.10.112, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 11:06:00','2026-11-07 11:06:00'),
(1887,1,'user_status_changed','user_status_changed','users',85,NULL,NULL,NULL,NULL,'Status changed to \'Active\' for user_id=85','2026-11-07 11:06:35','2026-11-07 11:06:35'),
(1888,NULL,'login_success','login','users',85,NULL,'7f7388ee-9b64-46af-bc64-ea5c94d1b872','49.149.10.112, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 11:06:58','2026-11-07 11:06:58'),
(1889,1,'login_success','login','users',1,NULL,'67ea5d43-0011-4187-bc87-ea2c9faf8197','49.149.10.112, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 11:07:14','2026-11-07 11:07:14'),
(1890,1,'password_reset','password_reset','users',85,NULL,NULL,NULL,NULL,'Password reset by BusinessOwner (user_id=1) for user \'ronan.delacruz\'','2026-11-07 11:07:31','2026-11-07 11:07:31'),
(1891,NULL,'login_success','login','users',85,NULL,'e3e8fadc-0d78-405c-a07a-57f3078b85f1','49.149.10.112, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-07 11:07:56','2026-11-07 11:07:56'),
(1892,2,'login_success','login','users',2,NULL,'25292060-246b-40ee-b4de-af60e920d55d','165.99.251.89, 152.233.68.105','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/156.0.8078.47 Safari/537.36 [FB_IAB/FB4A;FBAV/585.0.0.53.94;]','User logged in successfully.','2026-11-07 12:36:38','2026-11-07 12:36:38'),
(1893,1,'login_success','login','users',1,NULL,'84f211ec-0b03-4919-9e83-c5390a6a24d7','49.149.192.85, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-08 17:55:18','2026-11-08 17:55:18'),
(1894,2,'login_success','login','users',2,NULL,'a8b253e9-a9e7-4ddf-88b4-869ff1ea308d','165.99.251.89, 152.233.68.97','Mozilla/5.0 (Linux; Android 16; SM-X210 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/156.0.8078.47 Safari/537.36 [FB_IAB/FB4A;FBAV/586.0.0.55.92;]','User logged in successfully.','2026-11-08 18:12:14','2026-11-08 18:12:14'),
(1895,2,'login_success','login','users',2,NULL,'48addf47-bbbb-4b99-aa5d-6db95780c6bc','49.145.192.181, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 01:24:15','2026-11-09 01:24:15'),
(1896,1,'login_success','login','users',1,NULL,'33f0b23e-d6c4-421a-93af-e12d6c22951b','49.145.192.181, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 01:29:00','2026-11-09 01:29:00'),
(1897,1,'user_archived','user_archived','users',123,NULL,NULL,NULL,NULL,'Archived user_id=123','2026-11-09 01:29:14','2026-11-09 01:29:14'),
(1898,1,'user_archived','user_archived','users',99,NULL,NULL,NULL,NULL,'Archived user_id=99','2026-11-09 01:29:24','2026-11-09 01:29:24'),
(1899,1,'user_archived','user_archived','users',4,NULL,NULL,NULL,NULL,'Archived user_id=4','2026-11-09 01:29:48','2026-11-09 01:29:48'),
(1900,1,'user_archived','user_archived','users',120,NULL,NULL,NULL,NULL,'Archived user_id=120','2026-11-09 01:30:10','2026-11-09 01:30:10'),
(1901,1,'user_status_changed','user_status_changed','users',121,NULL,NULL,NULL,NULL,'Status changed to \'Active\' for user_id=121','2026-11-09 01:31:01','2026-11-09 01:31:01'),
(1902,2,'login_success','login','users',2,NULL,'c40d5ffc-565a-4abb-9253-2aab0a63c18f','49.145.192.181, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 01:31:15','2026-11-09 01:31:15'),
(1903,1,'login_success','login','users',1,NULL,'7726d6e2-960e-49e1-9591-43176ebaff96','49.145.198.54, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 01:41:31','2026-11-09 01:41:31'),
(1904,2,'user_provisioned','user_provisioned','users',131,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'menen.delacruz\' for employee_id=103','2026-11-09 01:44:22','2026-11-09 01:44:22'),
(1905,2,'attendance_adjusted','adjust_attendance','attendance',924,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-12\",\"reason\":\"Missed Biometric Punch\",\"old\":{\"time_in\":\"07:04:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:04:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":296}}','2026-11-09 02:00:33','2026-11-09 02:00:33'),
(1906,2,'attendance_adjusted','adjust_attendance','attendance',743,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-09\",\"reason\":\"Missed Biometric Punch\",\"old\":{\"time_in\":\"07:35:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:35:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":25}}','2026-11-09 02:01:11','2026-11-09 02:01:11'),
(1907,2,'attendance_adjusted','adjust_attendance','attendance',798,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-12\",\"reason\":\"Overtime\",\"old\":{\"time_in\":\"06:51:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:51:00\",\"time_out\":\"19:00:00\",\"overtime_minutes\":189}}','2026-11-09 02:09:52','2026-11-09 02:09:52'),
(1908,2,'attendance_adjusted','adjust_attendance','attendance',848,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-12\",\"reason\":\"Missed Punch\",\"old\":{\"time_in\":\"06:44:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:44:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":76}}','2026-11-09 02:12:06','2026-11-09 02:12:06'),
(1909,2,'attendance_adjusted','adjust_attendance','attendance',822,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-12\",\"reason\":\"Overtime\",\"old\":{\"time_in\":\"06:53:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:53:00\",\"time_out\":\"20:00:00\",\"overtime_minutes\":247}}','2026-11-09 02:22:08','2026-11-09 02:22:08'),
(1910,2,'attendance_adjusted','adjust_attendance','attendance',921,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-09\",\"reason\":\"Missed biometric punch\",\"old\":{\"time_in\":\"07:15:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:15:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":285}}','2026-11-09 02:27:19','2026-11-09 02:27:19'),
(1911,2,'attendance_adjusted','adjust_attendance','attendance',819,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-09\",\"reason\":\"Missed Biometric Punch\",\"old\":{\"time_in\":\"06:46:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:46:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":74}}','2026-11-09 02:28:56','2026-11-09 02:28:56'),
(1912,NULL,'login_success','login','users',130,NULL,'4f0127d4-da1a-48bf-89cb-ec2278fbafb0','49.145.192.181, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 02:39:54','2026-11-09 02:39:54'),
(1913,2,'login_success','login','users',2,NULL,'5ab8b841-f62f-417a-824c-d886bf353051','49.145.192.181, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 02:41:05','2026-11-09 02:41:05'),
(1914,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','92572f08-d230-4c6d-a49c-fcd2c5fc0347','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-09 04:56:13','2026-11-09 04:56:13'),
(1915,1,'login_success','login','users',1,NULL,'fd035cea-e78d-409a-b5d5-dbb4663bf187','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 04:56:26','2026-11-09 04:56:26'),
(1916,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','0852e6b5-24b2-4efa-95ec-0ab47dee59c4','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-09 04:56:43','2026-11-09 04:56:43'),
(1917,1,'login_success','login','users',1,NULL,'5e48dbb5-55b9-4730-b373-201a256a8a41','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 04:56:49','2026-11-09 04:56:49'),
(1918,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','c135825a-47c2-49b2-8da5-6b1d4873a454','122.3.73.126, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-09 04:59:16','2026-11-09 04:59:16'),
(1919,NULL,'login_success','login','users',130,NULL,'85ea285d-83fe-4736-9092-e630fe16d5cb','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 05:32:19','2026-11-09 05:32:19'),
(1920,NULL,'login_success','login','users',94,NULL,'d7f1e54f-bad0-4e9f-8bd3-7beae89f1730','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 05:32:49','2026-11-09 05:32:49'),
(1921,NULL,'login_success','login','users',94,NULL,'76ef19d8-8e74-44f3-a771-034e864502a5','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 05:36:14','2026-11-09 05:36:14'),
(1922,2,'login_success','login','users',2,NULL,'e934e6ba-2df2-4bff-9e5e-102a0beff5f0','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 05:42:29','2026-11-09 05:42:29'),
(1923,1,'login_success','login','users',1,NULL,'3d7d524d-9c26-4752-a557-1a44aeff7ff8','122.3.73.126, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 05:46:18','2026-11-09 05:46:18'),
(1924,2,'login_success','login','users',2,NULL,'0a2109c1-589c-403e-806a-84087aca2a96','122.3.73.126, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 05:47:04','2026-11-09 05:47:04'),
(1925,2,'login_success','login','users',2,NULL,'99d69c60-6a61-406a-9c5a-4582bf07dbb5','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 08:17:33','2026-11-09 08:17:33'),
(1926,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','b1e1b7aa-d382-4d14-8137-be59d84271c3','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-09 08:23:49','2026-11-09 08:23:49'),
(1927,2,'login_success','login','users',2,NULL,'3ec943c7-bdbd-46a7-9cca-03d6990594d7','122.3.73.126, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 08:24:12','2026-11-09 08:24:12'),
(1928,1,'login_success','login','users',1,NULL,'b63c68d1-7335-4a50-a208-f72d2b3b1e3f','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 08:46:58','2026-11-09 08:46:58'),
(1929,2,'login_success','login','users',2,NULL,'6b151bcc-7418-46d7-ad2b-b8cce2eb93b1','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 08:55:22','2026-11-09 08:55:22'),
(1930,NULL,'login_success','login','users',91,NULL,'c46061b3-f24b-4c1d-9c7d-0a94c682fdd1','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 09:01:15','2026-11-09 09:01:15'),
(1931,NULL,'login_success','login','users',90,NULL,'8251bf61-c32e-4985-9142-a17edc245fcb','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 09:01:49','2026-11-09 09:01:49'),
(1932,NULL,'login_success','login','users',87,NULL,'39c788dd-763d-440d-91ce-88dde4f18b13','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 09:02:19','2026-11-09 09:02:19'),
(1933,NULL,'login_success','login','users',88,NULL,'570973a5-8118-47c8-97cc-337b92b031a4','122.3.73.126, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 09:03:21','2026-11-09 09:03:21'),
(1934,NULL,'login_success','login','users',86,NULL,'67b7b4a7-14f8-4189-add2-f3eb7bc9279c','122.3.73.126, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 09:04:28','2026-11-09 09:04:28'),
(1935,2,'login_success','login','users',2,NULL,'c98dfad5-cd54-458d-8ce6-e385cf14df68','122.3.73.126, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 09:11:17','2026-11-09 09:11:17'),
(1936,2,'login_success','login','users',2,NULL,'44f904a9-f5ff-447d-b055-d34ce3e1421e','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 09:26:09','2026-11-09 09:26:09'),
(1937,2,'attendance_adjusted','adjust_attendance','attendance',930,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-19\",\"reason\":\"missed\",\"old\":{\"time_in\":\"07:03:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:03:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":297}}','2026-11-09 09:37:08','2026-11-09 09:37:08'),
(1938,2,'attendance_adjusted','adjust_attendance','attendance',927,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-16\",\"reason\":\"missed punch\",\"old\":{\"time_in\":\"06:55:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:55:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":305}}','2026-11-09 09:37:44','2026-11-09 09:37:44'),
(1939,2,'attendance_adjusted','adjust_attendance','attendance',854,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-19\",\"reason\":\"missed punch\",\"old\":{\"time_in\":\"06:47:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:47:00\",\"time_out\":\"17:54:00\",\"overtime_minutes\":127}}','2026-11-09 09:38:28','2026-11-09 09:38:28'),
(1940,2,'attendance_adjusted','adjust_attendance','attendance',751,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-18\",\"reason\":\"missed punch\",\"old\":{\"time_in\":\"07:36:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:36:00\",\"time_out\":\"17:40:00\",\"overtime_minutes\":64}}','2026-11-09 09:38:59','2026-11-09 09:38:59'),
(1941,2,'attendance_adjusted','adjust_attendance','attendance',828,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2026-06-19\",\"reason\":\"missed punch\",\"old\":{\"time_in\":\"06:58:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:58:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":62}}','2026-11-09 09:40:26','2026-11-09 09:40:26'),
(1942,NULL,'login_success','login','users',130,NULL,'86f183ef-1eab-48b0-8422-7522833572e7','122.3.73.126, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 09:54:46','2026-11-09 09:54:46'),
(1943,2,'login_success','login','users',2,NULL,'8c4ac0cd-6773-4482-a705-01b042e9080a','122.3.73.126, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 09:56:29','2026-11-09 09:56:29'),
(1944,2,'login_success','login','users',2,NULL,'ecb3c8e3-c522-4fe0-b1b8-744e89101517','122.3.73.126, 152.233.15.123','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 09:59:18','2026-11-09 09:59:18'),
(1945,2,'salary_updated','salary_updated','salary',130,NULL,NULL,NULL,NULL,'Updated from salary_id=126 to new salary_id=130, rate=500 from 2026-11-09','2026-11-09 10:15:32','2026-11-09 10:15:32'),
(1946,NULL,'login_failure','login_attempt',NULL,NULL,'jufren.cervantes@tacurong.sti.edu','7f3fe74c-090b-4981-b038-277fc547e541','119.93.144.66, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-09 10:15:43','2026-11-09 10:15:43'),
(1947,1,'login_success','login','users',1,NULL,'7001301a-8954-4f04-940a-f576b47373d3','122.3.73.126, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 10:19:40','2026-11-09 10:19:40'),
(1948,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','7f44479d-a02f-40e5-8c17-f039f7f3fae3','49.149.116.41, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-09 13:17:05','2026-11-09 13:17:05'),
(1949,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','3cf490de-3eb9-4535-814a-b92e0989a057','49.149.116.41, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-09 13:17:18','2026-11-09 13:17:18'),
(1950,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','79a73213-32dd-4b17-91a9-5df36feda0e7','49.149.116.41, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-09 13:17:24','2026-11-09 13:17:24'),
(1951,1,'login_success','login','users',1,NULL,'b6a1382f-f566-476e-8661-13d4df1dbcaa','49.149.192.85, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 17:47:20','2026-11-09 17:47:20'),
(1952,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','62cdb85a-88c3-4b1f-aa5e-04568eb98fd8','49.149.192.85, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-09 17:53:45','2026-11-09 17:53:45'),
(1953,2,'login_success','login','users',2,NULL,'57eef6da-003c-4280-afb1-8817f24d795d','49.149.192.85, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 17:53:50','2026-11-09 17:53:50'),
(1954,2,'login_success','login','users',2,NULL,'1a62ce67-c5a8-4029-8809-1c913dccf95c','49.149.192.85, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 17:58:57','2026-11-09 17:58:57'),
(1955,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','d0b53f04-daa4-469e-9e40-720f89669001','49.149.211.51, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-09 18:34:19','2026-11-09 18:34:19'),
(1956,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','ce184eda-49fc-42a8-972e-64fb2a14daeb','49.149.211.51, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-09 18:34:28','2026-11-09 18:34:28'),
(1957,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','8c28892b-8d85-46f8-9163-210b7060fd93','49.149.211.51, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-09 18:35:15','2026-11-09 18:35:15'),
(1958,2,'login_success','login','users',2,NULL,'112f47f3-8707-4cdb-b2f6-b17cc439d82a','49.149.211.51, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 18:35:35','2026-11-09 18:35:35'),
(1959,2,'login_success','login','users',2,NULL,'12a8cc76-03d8-4777-96b8-f46be281008f','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 21:41:23','2026-11-09 21:41:23'),
(1960,1,'login_success','login','users',1,NULL,'16081d27-07a6-4c8c-a59e-47474f433015','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 21:41:57','2026-11-09 21:41:57'),
(1961,2,'login_success','login','users',2,NULL,'f2b2652c-9cad-4a60-bf15-65b15f0d6a32','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 21:42:24','2026-11-09 21:42:24'),
(1962,2,'login_success','login','users',2,NULL,'8c0ea486-fd98-4b4a-ba98-c8661582dbaa','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 21:50:12','2026-11-09 21:50:12'),
(1963,2,'login_success','login','users',2,NULL,'ff2d4555-c9c3-4b62-b7d5-4148a65c055c','49.149.211.51, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 22:09:24','2026-11-09 22:09:24'),
(1964,2,'login_success','login','users',2,NULL,'3b889ba6-8781-4e3d-a332-f561e26d88ae','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 22:09:50','2026-11-09 22:09:50'),
(1965,2,'login_success','login','users',2,NULL,'2ef5999d-731f-4a52-aabe-f00e5ecb5d41','49.149.211.51, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 22:10:02','2026-11-09 22:10:02'),
(1966,2,'login_success','login','users',2,NULL,'f2e90046-88db-475d-8af6-aaa21d2c67cc','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 22:12:47','2026-11-09 22:12:47'),
(1967,2,'user_provisioned','user_provisioned','users',132,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'ronan.delacruz\' for employee_id=104','2026-11-09 22:21:25','2026-11-09 22:21:25'),
(1968,132,'login_success','login','users',132,NULL,'1927e575-6283-450d-833f-92f45626550a','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 22:21:57','2026-11-09 22:21:57'),
(1969,2,'login_success','login','users',2,NULL,'9fc4602b-89e1-4bad-96b1-a2f21fed3741','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 22:22:34','2026-11-09 22:22:34'),
(1970,2,'user_provisioned','user_provisioned','users',133,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'lovely.paguntalan\' for employee_id=105','2026-11-09 22:27:21','2026-11-09 22:27:21'),
(1971,133,'login_success','login','users',133,NULL,'dd7d81bc-b469-4e8b-bdab-9ab35deb911d','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 22:27:59','2026-11-09 22:27:59'),
(1972,2,'login_success','login','users',2,NULL,'957170a7-12cc-46e5-a095-23d0b9eb1c95','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 22:40:40','2026-11-09 22:40:40'),
(1973,2,'user_provisioned','user_provisioned','users',134,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'dave.dalipe\' for employee_id=106','2026-11-09 22:44:14','2026-11-09 22:44:14'),
(1974,134,'login_success','login','users',134,NULL,'b98be863-d3c4-468d-ab61-ff92783b4108','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 22:44:40','2026-11-09 22:44:40'),
(1975,2,'login_success','login','users',2,NULL,'a18496fc-fb05-4333-bdb9-b6e2440ed5c9','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 22:44:59','2026-11-09 22:44:59'),
(1976,1,'login_success','login','users',1,NULL,'755270ef-0d34-45c0-b20b-a6316cc2fccd','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 22:48:34','2026-11-09 22:48:34'),
(1977,2,'user_provisioned','user_provisioned','users',135,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'joshua.pugay\' for employee_id=107','2026-11-09 22:51:15','2026-11-09 22:51:15'),
(1978,135,'login_success','login','users',135,NULL,'88924c46-212e-4027-8de9-ce6d28f0c904','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 22:51:47','2026-11-09 22:51:47'),
(1979,2,'login_success','login','users',2,NULL,'4b548a15-d8bb-4009-807e-7d902aa72526','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-09 22:52:28','2026-11-09 22:52:28'),
(1980,2,'login_success','login','users',2,NULL,'71a971e6-2ae3-461a-9421-5df9e21c6a44','49.149.211.51, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:08:07','2026-11-10 00:08:07'),
(1981,2,'user_provisioned','user_provisioned','users',136,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'isabel.tayong\' for employee_id=108','2026-11-10 00:11:44','2026-11-10 00:11:44'),
(1982,136,'login_success','login','users',136,NULL,'b405a95c-e738-4b27-bc51-e8814529942b','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:12:35','2026-11-10 00:12:35'),
(1983,2,'login_success','login','users',2,NULL,'bbe123ce-6419-4101-9896-4f3c1abcd316','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:14:27','2026-11-10 00:14:27'),
(1984,2,'user_provisioned','user_provisioned','users',137,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'albert.indo\' for employee_id=109','2026-11-10 00:18:51','2026-11-10 00:18:51'),
(1985,137,'login_success','login','users',137,NULL,'b5c1adf3-f7a9-436c-983a-8de31158e1af','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:19:16','2026-11-10 00:19:16'),
(1986,2,'login_success','login','users',2,NULL,'dcb410a4-24e1-4b7a-b92f-56075f4aae1e','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:22:37','2026-11-10 00:22:37'),
(1987,2,'user_provisioned','user_provisioned','users',138,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'laurence.amara\' for employee_id=110','2026-11-10 00:26:39','2026-11-10 00:26:39'),
(1988,138,'login_success','login','users',138,NULL,'3fd39740-5cfe-4d43-ba11-a67454408ce2','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:27:03','2026-11-10 00:27:03'),
(1989,NULL,'login_failure','login_attempt',NULL,NULL,'hrhead@demo.test','203973e1-435b-42aa-8229-0d18b2f221d0','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-10 00:27:38','2026-11-10 00:27:38'),
(1990,2,'login_success','login','users',2,NULL,'b8779d80-4dcc-427e-8198-a947ffee143f','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:27:47','2026-11-10 00:27:47'),
(1991,2,'user_provisioned','user_provisioned','users',139,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'melanie.vidal\' for employee_id=111','2026-11-10 00:31:34','2026-11-10 00:31:34'),
(1992,139,'login_success','login','users',139,NULL,'7b9a0901-634c-412a-905b-50e744dc0874','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:32:15','2026-11-10 00:32:15'),
(1993,1,'login_success','login','users',1,NULL,'a1952cdc-98ea-4ed3-ab83-dca56f7e529d','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:32:41','2026-11-10 00:32:41'),
(1994,2,'login_success','login','users',2,NULL,'c220c35f-569d-442d-8537-237f0c672dad','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:33:56','2026-11-10 00:33:56'),
(1995,2,'user_provisioned','user_provisioned','users',140,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'lowel.dalipe\' for employee_id=112','2026-11-10 00:40:36','2026-11-10 00:40:36'),
(1996,140,'login_success','login','users',140,NULL,'d5ceb81d-d82f-4571-bf07-3593d6481796','49.149.211.51, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:41:26','2026-11-10 00:41:26'),
(1997,2,'login_success','login','users',2,NULL,'00671e3f-1cfd-430c-a2a0-0c19b277939d','49.149.211.51, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:42:08','2026-11-10 00:42:08'),
(1998,2,'user_provisioned','user_provisioned','users',141,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'herwin.libuna\' for employee_id=113','2026-11-10 00:46:49','2026-11-10 00:46:49'),
(1999,141,'login_success','login','users',141,NULL,'e5bd6e2c-0693-4acd-97a5-ef8b6a802a25','49.149.211.51, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:47:14','2026-11-10 00:47:14'),
(2000,2,'login_success','login','users',2,NULL,'798e61a6-65fa-4021-ab89-80077f45837c','49.149.211.51, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:49:13','2026-11-10 00:49:13'),
(2001,2,'user_provisioned','user_provisioned','users',142,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'roce.catayoc\' for employee_id=114','2026-11-10 00:53:15','2026-11-10 00:53:15'),
(2002,142,'login_success','login','users',142,NULL,'36f2c407-5e3f-4b45-9c32-a526c7d63e87','49.149.211.51, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:53:49','2026-11-10 00:53:49'),
(2003,2,'login_success','login','users',2,NULL,'1b6cb71a-baa9-4e18-b3fd-02d6d15c07c3','49.149.211.51, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:55:00','2026-11-10 00:55:00'),
(2004,2,'user_provisioned','user_provisioned','users',143,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'menen.delacruz\' for employee_id=115','2026-11-10 00:58:31','2026-11-10 00:58:31'),
(2005,143,'login_success','login','users',143,NULL,'82daadb9-399d-481f-b706-f0a4b4f43509','49.149.211.51, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 00:59:07','2026-11-10 00:59:07'),
(2006,2,'login_success','login','users',2,NULL,'0f091471-c2dd-429b-8be8-4c8606547ce9','49.149.211.51, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 01:03:45','2026-11-10 01:03:45'),
(2007,2,'user_provisioned','user_provisioned','users',144,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'manny.linsaw\' for employee_id=116','2026-11-10 01:11:03','2026-11-10 01:11:03'),
(2008,NULL,'login_failure','login_attempt',NULL,NULL,'k.batcharo30@gmail.com','d8119bef-bd67-41e9-90fe-9a6b73b1b19c','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-10 01:11:44','2026-11-10 01:11:44'),
(2009,144,'login_success','login','users',144,NULL,'126be73e-f924-4a5d-99dc-dd483af4de95','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 01:11:55','2026-11-10 01:11:55'),
(2010,2,'login_success','login','users',2,NULL,'3d8e301b-6dff-45b7-a042-2e4b5d2e80e9','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 01:13:20','2026-11-10 01:13:20'),
(2011,2,'user_provisioned','user_provisioned','users',145,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'johndave.tagaduar\' for employee_id=117','2026-11-10 01:17:46','2026-11-10 01:17:46'),
(2012,2,'login_success','login','users',2,NULL,'f931dc53-6f97-493f-b76d-59a7ce8cd1a7','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 01:18:37','2026-11-10 01:18:37'),
(2013,145,'login_success','login','users',145,NULL,'4eee2119-2e6e-485b-acc6-b4320d8bf057','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 01:19:13','2026-11-10 01:19:13'),
(2014,2,'login_success','login','users',2,NULL,'b64258c6-ac5e-4285-9e8a-e323112023ae','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 01:19:51','2026-11-10 01:19:51'),
(2015,2,'login_success','login','users',2,NULL,'13958864-567f-4abe-b1a0-00706f7aa25c','49.146.57.182, 152.233.15.123','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 01:44:02','2026-11-10 01:44:02'),
(2016,2,'login_success','login','users',2,NULL,'f16fbbaf-aa0e-410f-a727-fd456e9daafe','165.99.250.89, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 01:53:16','2026-11-10 01:53:16'),
(2017,132,'login_success','login','users',132,NULL,'e78367f0-1cc3-4dd7-a45a-0e72419f1f37','49.149.211.51, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 02:25:02','2026-11-10 02:25:02'),
(2018,2,'login_success','login','users',2,NULL,'4136a745-2213-4377-83f6-8c720a6cb42a','49.149.211.51, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 02:28:48','2026-11-10 02:28:48'),
(2019,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','fe37771a-0ea0-412f-b51e-370c5f18036e','49.149.211.51, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-10 02:29:24','2026-11-10 02:29:24'),
(2020,132,'login_success','login','users',132,NULL,'ff49871c-1640-4828-84cc-e76a8a8c189c','49.149.211.51, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 02:29:37','2026-11-10 02:29:37'),
(2021,133,'login_success','login','users',133,NULL,'31b67fc8-7be4-4597-a78f-8d25d06e9253','49.149.211.51, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 02:29:58','2026-11-10 02:29:58'),
(2022,2,'login_success','login','users',2,NULL,'0b932d7a-ef6b-4695-aa10-9874b8aac18d','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 02:33:57','2026-11-10 02:33:57'),
(2023,2,'login_success','login','users',2,NULL,'93d9d9c9-1cdc-4a0f-9fe6-cb9692c6c3e4','49.146.57.182, 152.233.15.120','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 02:59:21','2026-11-10 02:59:21'),
(2024,2,'login_success','login','users',2,NULL,'f36f690c-47bb-422e-9f33-deb1f7b8b338','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 02:59:38','2026-11-10 02:59:38'),
(2025,1,'login_success','login','users',1,NULL,'0257dc42-a2de-4a14-a1c0-945bba681962','49.146.57.182, 152.233.15.120','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 03:00:11','2026-11-10 03:00:11'),
(2026,2,'login_success','login','users',2,NULL,'eab78426-f967-48ae-af35-0b328744e23b','122.3.73.126, 152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 03:15:10','2026-11-10 03:15:10'),
(2027,2,'login_success','login','users',2,NULL,'09f80433-1eea-48b0-8b89-3fc1717495c4','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 05:10:25','2026-11-10 05:10:25'),
(2028,2,'login_success','login','users',2,NULL,'c9bd9657-7c77-41b3-88c3-317550c5d6c8','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 05:13:57','2026-11-10 05:13:57'),
(2029,2,'login_success','login','users',2,NULL,'f560ccf3-b618-4747-b0be-5db8b7203f5a','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 05:14:21','2026-11-10 05:14:21'),
(2030,2,'attendance_adjusted','adjust_attendance','attendance',1549,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2025-05-02\",\"reason\":\"Forgot to punch\",\"old\":{\"time_in\":\"06:44:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:44:00\",\"time_out\":\"19:00:00\",\"overtime_minutes\":0}}','2026-11-10 05:16:00','2026-11-10 05:16:00'),
(2031,2,'attendance_adjusted','adjust_attendance','attendance',1555,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2025-05-02\",\"reason\":\"Forgot to punch\",\"old\":{\"time_in\":\"06:17:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:17:00\",\"time_out\":\"19:00:00\",\"overtime_minutes\":0}}','2026-11-10 05:16:55','2026-11-10 05:16:55'),
(2032,2,'login_success','login','users',2,NULL,'b8632a42-e503-4f95-af3a-7093da79828c','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 05:17:26','2026-11-10 05:17:26'),
(2033,141,'login_success','login','users',141,NULL,'ec67e2d0-7b93-482f-87b0-bba6c596d939','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 05:18:09','2026-11-10 05:18:09'),
(2034,2,'login_success','login','users',2,NULL,'3ea67792-4aa6-4b92-a731-9dd2cb596261','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 05:18:41','2026-11-10 05:18:41'),
(2035,2,'attendance_adjusted','adjust_attendance','attendance',1583,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2025-05-07\",\"reason\":\"forgot to punch\",\"old\":{\"time_in\":\"16:28:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:00:00\",\"time_out\":\"16:28:00\",\"overtime_minutes\":0}}','2026-11-10 05:20:59','2026-11-10 05:20:59'),
(2036,2,'attendance_adjusted','adjust_attendance','attendance',1573,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2025-05-02\",\"reason\":\"forgot to punch\",\"old\":{\"time_in\":\"06:57:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:57:00\",\"time_out\":\"19:00:00\",\"overtime_minutes\":0}}','2026-11-10 05:23:01','2026-11-10 05:23:01'),
(2037,2,'attendance_adjusted','adjust_attendance','attendance',1591,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2025-05-02\",\"reason\":\"Forgot to punch\",\"old\":{\"time_in\":\"07:29:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:29:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":0}}','2026-11-10 05:25:20','2026-11-10 05:25:20'),
(2038,2,'attendance_adjusted','adjust_attendance','attendance',1603,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2025-05-02\",\"reason\":\"Forgot to Punch\",\"old\":{\"time_in\":\"07:42:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:42:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":0}}','2026-11-10 05:25:57','2026-11-10 05:25:57'),
(2039,2,'attendance_adjusted','adjust_attendance','attendance',1610,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2025-05-04\",\"reason\":\"Forgot to punch\",\"old\":{\"time_in\":\"06:56:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"06:56:00\",\"time_out\":\"16:00:00\",\"overtime_minutes\":0}}','2026-11-10 05:27:16','2026-11-10 05:27:16'),
(2040,NULL,'login_failure','login_attempt',NULL,NULL,'owner@demo.test','ab1a2ae3-672a-4d72-944d-5de9b22a6121','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-10 05:56:12','2026-11-10 05:56:12'),
(2041,1,'login_success','login','users',1,NULL,'d64616bd-187b-44ef-8c63-0c4b4536889c','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 05:56:22','2026-11-10 05:56:22'),
(2042,133,'login_success','login','users',133,NULL,'80ed4132-a6a4-46a6-a793-fb8c926a8c3b','122.3.73.126, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 05:56:58','2026-11-10 05:56:58'),
(2043,2,'login_success','login','users',2,NULL,'eb09b9c9-80fb-48f2-bf7b-2894eac52327','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 07:11:49','2026-11-10 07:11:49'),
(2044,139,'login_success','login','users',139,NULL,'e9ebc19c-554c-419c-b064-041aefa1bcd4','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 07:14:03','2026-11-10 07:14:03'),
(2045,2,'login_success','login','users',2,NULL,'f04ba343-6f5d-4e7c-a4c4-2a75e929f23f','49.149.211.51, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 08:24:56','2026-11-10 08:24:56'),
(2046,1,'login_success','login','users',1,NULL,'22e038be-401e-4370-883e-3b1fbc41b85e','49.149.211.51, 152.233.68.98','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/22F76 [FBAN/FBIOS;FBAV/583.0.0.32.105;FBBV/1090090915;FBDV/iPhone14,5;FBMD/iPhone;FBSN/iOS;FBSV/18.5;FBSS/3;FBCR/;FBID/phone;FBLC/en_PH;FBOP/80]','User logged in successfully.','2026-11-10 09:21:38','2026-11-10 09:21:38'),
(2047,2,'login_success','login','users',2,NULL,'6207f3a4-7172-4ad9-975f-d4ecb7fca1db','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 09:36:28','2026-11-10 09:36:28'),
(2048,2,'user_provisioned','user_provisioned','users',146,NULL,NULL,NULL,NULL,'Auto-provisioned Employee account \'a.a\' for employee_id=118','2026-11-10 09:50:23','2026-11-10 09:50:23'),
(2049,1,'login_success','login','users',1,NULL,'f7b9a541-2a18-4541-b28f-13f6e7903899','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 09:51:39','2026-11-10 09:51:39'),
(2050,1,'user_archived','user_archived','users',146,NULL,NULL,NULL,NULL,'Archived user_id=146','2026-11-10 09:52:44','2026-11-10 09:52:44'),
(2051,2,'login_success','login','users',2,NULL,'3fee472c-fe10-4a29-8399-c5241b587d41','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 09:56:11','2026-11-10 09:56:11'),
(2052,1,'login_success','login','users',1,NULL,'8b2c8425-1796-4f50-b4b0-7626e5c5dcef','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 10:05:10','2026-11-10 10:05:10'),
(2053,1,'user_unarchived','user_unarchived','users',146,NULL,NULL,NULL,NULL,'Unarchived user_id=146 — status restored to Inactive','2026-11-10 10:05:28','2026-11-10 10:05:28'),
(2054,2,'login_success','login','users',2,NULL,'45bdaf6e-b728-4f80-9c66-2cf17fa73afd','49.149.211.51, 152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 10:06:39','2026-11-10 10:06:39'),
(2055,1,'login_success','login','users',1,NULL,'592b2007-3e50-4713-b29b-2f29001bd73a','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 10:37:40','2026-11-10 10:37:40'),
(2056,1,'user_updated','user_updated','users',142,NULL,NULL,NULL,NULL,'Updated user_id=142: username=\'roce.catayoc\', role_id=2, status=\'Active\'','2026-11-10 10:37:58','2026-11-10 10:37:58'),
(2057,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','0b7429b5-2dab-49f1-a75c-05befbe5a06e','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-10 10:38:28','2026-11-10 10:38:28'),
(2058,132,'login_success','login','users',132,NULL,'6ea18990-b342-48e3-ac6b-64e77444ac2d','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 10:38:39','2026-11-10 10:38:39'),
(2059,142,'login_success','login','users',142,NULL,'a6372a6e-33c0-4925-9ad7-bd52b5b8acdb','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 10:39:50','2026-11-10 10:39:50'),
(2060,2,'login_success','login','users',2,NULL,'056fe7c6-7ab6-42c1-8bdb-fce7f784c259','49.149.211.51, 152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 10:47:45','2026-11-10 10:47:45'),
(2061,142,'attendance_adjusted','adjust_attendance','attendance',1547,NULL,NULL,NULL,NULL,'{\"attendance_date\":\"2025-05-07\",\"reason\":\"Forgot Punch\",\"old\":{\"time_in\":\"07:26:00\",\"time_out\":null,\"overtime_minutes\":0},\"new\":{\"time_in\":\"07:26:00\",\"time_out\":\"17:00:00\",\"overtime_minutes\":0}}','2026-11-10 10:50:56','2026-11-10 10:50:56'),
(2062,132,'login_success','login','users',132,NULL,'f1eba23f-be36-447e-83af-43b074d9f3f8','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 10:55:11','2026-11-10 10:55:11'),
(2063,1,'login_success','login','users',1,NULL,'4993d4f6-c8b5-4479-a231-93a146dd0f9b','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 11:00:19','2026-11-10 11:00:19'),
(2064,2,'login_success','login','users',2,NULL,'333dc8f0-9006-41b9-97d4-f3bf098fc024','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 11:01:14','2026-11-10 11:01:14'),
(2065,142,'login_success','login','users',142,NULL,'72a2ba7c-74cc-4b6c-943e-7cecd42aa351','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 11:03:22','2026-11-10 11:03:22'),
(2066,142,'login_success','login','users',142,NULL,'6687ad1d-2e92-4b9f-9948-a211b365b572','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 11:04:19','2026-11-10 11:04:19'),
(2067,132,'login_success','login','users',132,NULL,'bb3a4e6c-7377-43d2-ba1c-9590f0980e88','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 11:04:51','2026-11-10 11:04:51'),
(2068,132,'login_success','login','users',132,NULL,'7f79e3cc-1a86-4dc6-9784-41291f2da3bd','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 11:05:13','2026-11-10 11:05:13'),
(2069,142,'login_success','login','users',142,NULL,'040bc12c-f910-4a61-a796-e9639d1cc903','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 11:05:29','2026-11-10 11:05:29'),
(2070,NULL,'login_failure','login_attempt',NULL,NULL,'almairah@gmail.com','ef9b3bd3-80d9-43e6-b01e-8da3b7e3eba8','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-10 11:44:38','2026-11-10 11:44:38'),
(2071,NULL,'login_failure','login_attempt',NULL,NULL,'almairahmaindan18@gmail.com','d13adde6-e7ee-4eb9-8409-d9fbb07d3e2a','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-10 11:44:46','2026-11-10 11:44:46'),
(2072,NULL,'login_failure','login_attempt',NULL,NULL,'ehkslg','ace25ae5-6791-48eb-b595-0cfa6d35b0ab','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-10 11:44:56','2026-11-10 11:44:56'),
(2073,1,'login_success','login','users',1,NULL,'c9ca65ed-53a8-4758-96ba-e92f080965ff','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 12:02:38','2026-11-10 12:02:38'),
(2074,1,'user_status_changed','user_status_changed','users',132,NULL,NULL,NULL,NULL,'Status changed to \'Inactive\' for user_id=132','2026-11-10 12:04:23','2026-11-10 12:04:23'),
(2075,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','043709cc-7dd1-4802-bd6e-18985299433b','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-10 12:05:10','2026-11-10 12:05:10'),
(2076,NULL,'login_failure','login_attempt',NULL,NULL,'almrhmaindan@gmail.com','18d78a95-b066-4411-8c93-65949084d78d','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','Login failed: invalid credentials or inactive account.','2026-11-10 12:05:18','2026-11-10 12:05:18'),
(2077,1,'login_success','login','users',1,NULL,'6f83330a-12a8-4fb2-b52f-5e2b4b569dec','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 12:05:22','2026-11-10 12:05:22'),
(2078,1,'user_status_changed','user_status_changed','users',132,NULL,NULL,NULL,NULL,'Status changed to \'Active\' for user_id=132','2026-11-10 12:05:47','2026-11-10 12:05:47'),
(2079,132,'login_success','login','users',132,NULL,'ea54dd70-df79-4a13-8960-28f9c4641c41','49.149.211.51, 152.233.68.105','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 12:05:55','2026-11-10 12:05:55'),
(2080,2,'login_success','login','users',2,NULL,'6c0ef6cb-59e9-4a04-9241-403df090f88c','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 12:10:52','2026-11-10 12:10:52'),
(2081,2,'user_updated','user_updated','users',145,NULL,NULL,NULL,NULL,'Updated user_id=145: username=\'johndave.tagadua\', role_id=3, status=\'Active\'','2026-11-10 12:11:34','2026-11-10 12:11:34'),
(2082,2,'user_updated','user_updated','users',145,NULL,NULL,NULL,NULL,'Updated user_id=145: username=\'johndave.tagaduar\', role_id=3, status=\'Active\'','2026-11-10 12:11:50','2026-11-10 12:11:50'),
(2083,2,'login_success','login','users',2,NULL,'a9802cf7-3f6b-4633-a136-d0537c872163','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 12:14:16','2026-11-10 12:14:16'),
(2084,142,'login_success','login','users',142,NULL,'4298e5b8-475c-4cd8-a60b-59bea610207c','49.149.211.51, 152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 12:14:41','2026-11-10 12:14:41'),
(2085,2,'login_success','login','users',2,NULL,'f0ee9777-1b48-4aa9-99e7-a92b169ed84e','49.149.211.51, 152.233.68.105','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 13:01:08','2026-11-10 13:01:08'),
(2086,142,'login_success','login','users',142,NULL,'9fa15203-d9fb-4bfd-a0d2-2ba50f82d77b','49.149.211.51, 152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36','User logged in successfully.','2026-11-10 13:02:54','2026-11-10 13:02:54');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_details`
--

DROP TABLE IF EXISTS `bank_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank_details` (
  `bank_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `bank_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BDO',
  `account_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `status` enum('Active','Inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`bank_id`),
  UNIQUE KEY `uq_bank_name_acct_from` (`bank_name`,`account_number`,`effective_from`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `bank_details_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_bank_period` CHECK (((`effective_to` is null) or (`effective_to` > `effective_from`)))
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Effective-dated bank accounts; one active BDO account per employee';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_details`
--

LOCK TABLES `bank_details` WRITE;
/*!40000 ALTER TABLE `bank_details` DISABLE KEYS */;
INSERT INTO `bank_details` VALUES
(21,110,'BDO','Laurence Amara','1234-0055-00','Savings','2024-01-05',NULL,'Active','2026-11-10 01:26:09','2026-11-10 01:26:09'),
(22,114,'BDO','Roce Catayoc','1234-0015-00','Savings','2024-01-05',NULL,'Active','2026-11-10 01:27:07','2026-11-10 01:27:07'),
(23,106,'BDO','Dave Dalipe','1234-0065-00','Savings','2024-01-05',NULL,'Active','2026-11-10 01:29:24','2026-11-10 01:29:24'),
(24,112,'BDO','Lowel Dalipe','1234-0008-00','Savings','2024-01-05',NULL,'Active','2026-11-10 01:30:16','2026-11-10 01:30:16'),
(25,115,'BDO','Menen Dela Cruz','1234-0126-00','Savings','2024-01-05',NULL,'Active','2026-11-10 01:31:13','2026-11-10 01:31:13'),
(26,104,'BDO','Ronan Dela Cruz','1234-0129-00','Savings','2024-01-05',NULL,'Active','2026-11-10 01:32:11','2026-11-10 01:32:11'),
(27,109,'BDO','Albert Indo','1234-0114-00','Savings','2024-01-05',NULL,'Active','2026-11-10 01:32:47','2026-11-10 01:32:47'),
(28,113,'BDO','Herwin Libuna','1234-0032-00','Savings','2024-01-05',NULL,'Active','2026-11-10 01:33:27','2026-11-10 01:33:27'),
(29,116,'BDO','Manny Linsaw','1234-0127-00','Savings','2024-01-05',NULL,'Active','2026-11-10 01:34:21','2026-11-10 01:34:21'),
(30,105,'BDO','Lovely Paguntalan','1234-0052-00','Savings','2024-01-05',NULL,'Active','2026-11-10 01:34:58','2026-11-10 01:34:58'),
(31,107,'BDO','Joshua Pugay','1234-0121-00','Savings','2024-01-05',NULL,'Active','2026-11-10 01:35:36','2026-11-10 01:35:36'),
(32,117,'BDO','John Dave Tagaduar','1234-0124-00','Savings','2024-01-05',NULL,'Active','2026-11-10 01:36:45','2026-11-10 01:36:45'),
(33,108,'BDO','Isabel Tayong','1234-0013-00','Savings','2024-01-05',NULL,'Active','2026-11-10 01:37:18','2026-11-10 01:37:18'),
(34,111,'BDO','Melanie Vidal','1234-0054-00','Savings','2024-01-05',NULL,'Active','2026-11-10 01:38:09','2026-11-10 01:38:09');
/*!40000 ALTER TABLE `bank_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `barangay`
--

DROP TABLE IF EXISTS `barangay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `barangay` (
  `barangay_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `barangay_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`barangay_id`),
  KEY `idx_barangay_name` (`barangay_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barangay`
--

LOCK TABLES `barangay` WRITE;
/*!40000 ALTER TABLE `barangay` DISABLE KEYS */;
/*!40000 ALTER TABLE `barangay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biometric_device`
--

DROP TABLE IF EXISTS `biometric_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `biometric_device` (
  `device_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `device_code` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serial_number` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_format` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'LDE_XLS_DAILY_LOG_V1',
  `timezone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Asia/Manila',
  `status` enum('Active','Inactive','Retired') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `installed_at` date DEFAULT NULL,
  `retired_at` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`device_id`),
  UNIQUE KEY `uq_device_code` (`device_code`),
  UNIQUE KEY `uq_device_serial` (`serial_number`),
  KEY `site_id` (`site_id`),
  CONSTRAINT `biometric_device_ibfk_1` FOREIGN KEY (`site_id`) REFERENCES `attendance_site` (`site_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Registered biometric devices; one device may cover multiple branches';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biometric_device`
--

LOCK TABLES `biometric_device` WRITE;
/*!40000 ALTER TABLE `biometric_device` DISABLE KEYS */;
INSERT INTO `biometric_device` VALUES
(1,1,'DEVICE-BANGA','Banga Biometric Terminal','SN-BANGA-001','LDE_XLS_DAILY_LOG_V1','Asia/Manila','Active','2024-01-01',NULL,'2026-09-02 01:00:56','2026-09-02 01:00:56'),
(2,2,'DEVICE-SURALLAH','Surallah Biometric Terminal','SN-SURALLAH-001','LDE_XLS_DAILY_LOG_V1','Asia/Manila','Active','2024-01-01',NULL,'2026-09-02 01:00:56','2026-09-02 01:00:56');
/*!40000 ALTER TABLE `biometric_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biometric_device_branch`
--

DROP TABLE IF EXISTS `biometric_device_branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `biometric_device_branch` (
  `device_branch_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `device_id` bigint unsigned NOT NULL,
  `branch_id` bigint unsigned NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `status` enum('Active','Inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`device_branch_id`),
  UNIQUE KEY `uq_dbb_device_branch_from` (`device_id`,`branch_id`,`effective_from`),
  KEY `branch_id` (`branch_id`),
  CONSTRAINT `biometric_device_branch_ibfk_1` FOREIGN KEY (`device_id`) REFERENCES `biometric_device` (`device_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `biometric_device_branch_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_dbb_period` CHECK (((`effective_to` is null) or (`effective_to` > `effective_from`)))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Effective-dated coverage: which branches a device serves';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biometric_device_branch`
--

LOCK TABLES `biometric_device_branch` WRITE;
/*!40000 ALTER TABLE `biometric_device_branch` DISABLE KEYS */;
INSERT INTO `biometric_device_branch` VALUES
(1,1,1,'2024-01-01',NULL,'Active','2026-09-02 01:00:56','2026-09-02 01:00:56'),
(2,1,2,'2024-01-01',NULL,'Active','2026-09-02 01:00:56','2026-09-02 01:00:56'),
(3,2,3,'2024-01-01',NULL,'Active','2026-09-02 01:00:56','2026-09-02 01:00:56');
/*!40000 ALTER TABLE `biometric_device_branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biometric_punch`
--

DROP TABLE IF EXISTS `biometric_punch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `biometric_punch` (
  `punch_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `import_batch_id` bigint unsigned NOT NULL,
  `device_id` bigint unsigned NOT NULL,
  `employee_id` bigint unsigned DEFAULT NULL,
  `branch_assignment_id` bigint unsigned DEFAULT NULL,
  `device_employee_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_local_at` datetime NOT NULL,
  `punched_at_utc` datetime NOT NULL,
  `punch_type` enum('In','Out','Unknown') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_transaction_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `match_status` enum('matched','unmatched','coverage_exception','duplicate') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_department` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_employee_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `raw_record` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_workbook_row` int unsigned NOT NULL,
  `source_date_column` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolved_by` bigint unsigned DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`punch_id`),
  UNIQUE KEY `uq_punch_device_code_local_at` (`device_id`,`device_employee_code`,`source_local_at`),
  KEY `idx_punch_batch` (`import_batch_id`),
  KEY `idx_punch_employee` (`employee_id`),
  KEY `branch_assignment_id` (`branch_assignment_id`),
  KEY `resolved_by` (`resolved_by`),
  CONSTRAINT `biometric_punch_ibfk_1` FOREIGN KEY (`import_batch_id`) REFERENCES `attendance_import_batch` (`import_batch_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `biometric_punch_ibfk_2` FOREIGN KEY (`device_id`) REFERENCES `biometric_device` (`device_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `biometric_punch_ibfk_3` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `biometric_punch_ibfk_4` FOREIGN KEY (`branch_assignment_id`) REFERENCES `employee_branch_assignment` (`branch_assignment_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `biometric_punch_ibfk_5` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=53133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Immutable raw punch; all time tokens from the workbook are preserved';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biometric_punch`
--

LOCK TABLES `biometric_punch` WRITE;
/*!40000 ALTER TABLE `biometric_punch` DISABLE KEYS */;
INSERT INTO `biometric_punch` VALUES
(52976,48,1,110,131,'55','2025-05-02 06:57:00','2025-05-01 22:57:00','Unknown',NULL,'matched','LDE','55','Amara, Laurence','06:57 16:30',2,'E',NULL,NULL,'2026-11-10 02:51:47'),
(52977,48,1,110,131,'55','2025-05-02 16:30:00','2025-05-02 08:30:00','Unknown',NULL,'matched','LDE','55','Amara, Laurence','06:57 16:30',2,'E',NULL,NULL,'2026-11-10 02:51:47'),
(52978,48,1,110,131,'55','2025-05-04 07:04:00','2025-05-03 23:04:00','Unknown',NULL,'matched','LDE','55','Amara, Laurence','07:04 16:30',2,'F',NULL,NULL,'2026-11-10 02:51:47'),
(52979,48,1,110,131,'55','2025-05-04 16:30:00','2025-05-04 08:30:00','Unknown',NULL,'matched','LDE','55','Amara, Laurence','07:04 16:30',2,'F',NULL,NULL,'2026-11-10 02:51:47'),
(52980,48,1,110,131,'55','2025-05-05 06:57:00','2025-05-04 22:57:00','Unknown',NULL,'matched','LDE','55','Amara, Laurence','06:57 16:32',2,'G',NULL,NULL,'2026-11-10 02:51:47'),
(52981,48,1,110,131,'55','2025-05-05 16:32:00','2025-05-05 08:32:00','Unknown',NULL,'matched','LDE','55','Amara, Laurence','06:57 16:32',2,'G',NULL,NULL,'2026-11-10 02:51:48'),
(52982,48,1,110,131,'55','2025-05-06 07:00:00','2025-05-05 23:00:00','Unknown',NULL,'matched','LDE','55','Amara, Laurence','07:00 16:30',2,'H',NULL,NULL,'2026-11-10 02:51:48'),
(52983,48,1,110,131,'55','2025-05-06 16:30:00','2025-05-06 08:30:00','Unknown',NULL,'matched','LDE','55','Amara, Laurence','07:00 16:30',2,'H',NULL,NULL,'2026-11-10 02:51:48'),
(52984,48,1,110,131,'55','2025-05-07 07:11:00','2025-05-06 23:11:00','Unknown',NULL,'matched','LDE','55','Amara, Laurence','07:11 16:31',2,'I',NULL,NULL,'2026-11-10 02:51:48'),
(52985,48,1,110,131,'55','2025-05-07 16:31:00','2025-05-07 08:31:00','Unknown',NULL,'matched','LDE','55','Amara, Laurence','07:11 16:31',2,'I',NULL,NULL,'2026-11-10 02:51:48'),
(52986,48,1,110,131,'55','2025-05-08 07:05:00','2025-05-07 23:05:00','Unknown',NULL,'matched','LDE','55','Amara, Laurence','07:05 16:30',2,'J',NULL,NULL,'2026-11-10 02:51:48'),
(52987,48,1,110,131,'55','2025-05-08 16:30:00','2025-05-08 08:30:00','Unknown',NULL,'matched','LDE','55','Amara, Laurence','07:05 16:30',2,'J',NULL,NULL,'2026-11-10 02:51:48'),
(52988,48,1,114,135,'15','2025-05-02 07:38:00','2025-05-01 23:38:00','Unknown',NULL,'matched','LDE','15','Catayoc,Roce','07:38 17:39',3,'E',NULL,NULL,'2026-11-10 02:51:48'),
(52989,48,1,114,135,'15','2025-05-02 17:39:00','2025-05-02 09:39:00','Unknown',NULL,'matched','LDE','15','Catayoc,Roce','07:38 17:39',3,'E',NULL,NULL,'2026-11-10 02:51:48'),
(52990,48,1,114,135,'15','2025-05-04 07:17:00','2025-05-03 23:17:00','Unknown',NULL,'matched','LDE','15','Catayoc,Roce','07:17 17:08',3,'F',NULL,NULL,'2026-11-10 02:51:48'),
(52991,48,1,114,135,'15','2025-05-04 17:08:00','2025-05-04 09:08:00','Unknown',NULL,'matched','LDE','15','Catayoc,Roce','07:17 17:08',3,'F',NULL,NULL,'2026-11-10 02:51:48'),
(52992,48,1,114,135,'15','2025-05-05 07:32:00','2025-05-04 23:32:00','Unknown',NULL,'matched','LDE','15','Catayoc,Roce','07:32 17:19',3,'G',NULL,NULL,'2026-11-10 02:51:48'),
(52993,48,1,114,135,'15','2025-05-05 17:19:00','2025-05-05 09:19:00','Unknown',NULL,'matched','LDE','15','Catayoc,Roce','07:32 17:19',3,'G',NULL,NULL,'2026-11-10 02:51:48'),
(52994,48,1,114,135,'15','2025-05-06 07:32:00','2025-05-05 23:32:00','Unknown',NULL,'matched','LDE','15','Catayoc,Roce','07:32 18:04',3,'H',NULL,NULL,'2026-11-10 02:51:48'),
(52995,48,1,114,135,'15','2025-05-06 18:04:00','2025-05-06 10:04:00','Unknown',NULL,'matched','LDE','15','Catayoc,Roce','07:32 18:04',3,'H',NULL,NULL,'2026-11-10 02:51:48'),
(52996,48,1,114,135,'15','2025-05-07 07:26:00','2025-05-06 23:26:00','Unknown',NULL,'matched','LDE','15','Catayoc,Roce','07:26',3,'I',NULL,NULL,'2026-11-10 02:51:48'),
(52997,48,1,114,135,'15','2025-05-08 07:34:00','2025-05-07 23:34:00','Unknown',NULL,'matched','LDE','15','Catayoc,Roce','07:34 17:03',3,'J',NULL,NULL,'2026-11-10 02:51:48'),
(52998,48,1,114,135,'15','2025-05-08 17:03:00','2025-05-08 09:03:00','Unknown',NULL,'matched','LDE','15','Catayoc,Roce','07:34 17:03',3,'J',NULL,NULL,'2026-11-10 02:51:48'),
(52999,48,1,106,127,'65','2025-05-02 06:44:00','2025-05-01 22:44:00','Unknown',NULL,'matched','HARDWARE','65','Dalipe, Dave','06:44',4,'E',NULL,NULL,'2026-11-10 02:51:48'),
(53000,48,1,106,127,'65','2025-05-04 06:48:00','2025-05-03 22:48:00','Unknown',NULL,'matched','HARDWARE','65','Dalipe, Dave','06:48',4,'F',NULL,NULL,'2026-11-10 02:51:48'),
(53001,48,1,106,127,'65','2025-05-05 06:43:00','2025-05-04 22:43:00','Unknown',NULL,'matched','HARDWARE','65','Dalipe, Dave','06:43',4,'G',NULL,NULL,'2026-11-10 02:51:48'),
(53002,48,1,106,127,'65','2025-05-06 06:50:00','2025-05-05 22:50:00','Unknown',NULL,'matched','HARDWARE','65','Dalipe, Dave','06:50 16:28',4,'H',NULL,NULL,'2026-11-10 02:51:48'),
(53003,48,1,106,127,'65','2025-05-06 16:28:00','2025-05-06 08:28:00','Unknown',NULL,'matched','HARDWARE','65','Dalipe, Dave','06:50 16:28',4,'H',NULL,NULL,'2026-11-10 02:51:48'),
(53004,48,1,106,127,'65','2025-05-07 07:11:00','2025-05-06 23:11:00','Unknown',NULL,'matched','HARDWARE','65','Dalipe, Dave','07:11 16:28',4,'I',NULL,NULL,'2026-11-10 02:51:48'),
(53005,48,1,106,127,'65','2025-05-07 16:28:00','2025-05-07 08:28:00','Unknown',NULL,'matched','HARDWARE','65','Dalipe, Dave','07:11 16:28',4,'I',NULL,NULL,'2026-11-10 02:51:48'),
(53006,48,1,106,127,'65','2025-05-08 06:33:00','2025-05-07 22:33:00','Unknown',NULL,'matched','HARDWARE','65','Dalipe, Dave','06:33 16:33',4,'J',NULL,NULL,'2026-11-10 02:51:48'),
(53007,48,1,106,127,'65','2025-05-08 16:33:00','2025-05-08 08:33:00','Unknown',NULL,'matched','HARDWARE','65','Dalipe, Dave','06:33 16:33',4,'J',NULL,NULL,'2026-11-10 02:51:49'),
(53008,48,1,112,133,'8','2025-05-02 06:17:00','2025-05-01 22:17:00','Unknown',NULL,'matched','HARDWARE','8','Dalipe,Lowel','06:17',5,'E',NULL,NULL,'2026-11-10 02:51:49'),
(53009,48,1,112,133,'8','2025-05-04 06:38:00','2025-05-03 22:38:00','Unknown',NULL,'matched','HARDWARE','8','Dalipe,Lowel','06:38 16:57',5,'F',NULL,NULL,'2026-11-10 02:51:49'),
(53010,48,1,112,133,'8','2025-05-04 16:57:00','2025-05-04 08:57:00','Unknown',NULL,'matched','HARDWARE','8','Dalipe,Lowel','06:38 16:57',5,'F',NULL,NULL,'2026-11-10 02:51:49'),
(53011,48,1,112,133,'8','2025-05-05 06:30:00','2025-05-04 22:30:00','Unknown',NULL,'matched','HARDWARE','8','Dalipe,Lowel','06:30 16:47',5,'G',NULL,NULL,'2026-11-10 02:51:49'),
(53012,48,1,112,133,'8','2025-05-05 16:47:00','2025-05-05 08:47:00','Unknown',NULL,'matched','HARDWARE','8','Dalipe,Lowel','06:30 16:47',5,'G',NULL,NULL,'2026-11-10 02:51:49'),
(53013,48,1,112,133,'8','2025-05-06 06:44:00','2025-05-05 22:44:00','Unknown',NULL,'matched','HARDWARE','8','Dalipe,Lowel','06:44 16:29',5,'H',NULL,NULL,'2026-11-10 02:51:49'),
(53014,48,1,112,133,'8','2025-05-06 16:29:00','2025-05-06 08:29:00','Unknown',NULL,'matched','HARDWARE','8','Dalipe,Lowel','06:44 16:29',5,'H',NULL,NULL,'2026-11-10 02:51:49'),
(53015,48,1,112,133,'8','2025-05-07 07:11:00','2025-05-06 23:11:00','Unknown',NULL,'matched','HARDWARE','8','Dalipe,Lowel','07:11 16:27',5,'I',NULL,NULL,'2026-11-10 02:51:49'),
(53016,48,1,112,133,'8','2025-05-07 16:27:00','2025-05-07 08:27:00','Unknown',NULL,'matched','HARDWARE','8','Dalipe,Lowel','07:11 16:27',5,'I',NULL,NULL,'2026-11-10 02:51:49'),
(53017,48,1,112,133,'8','2025-05-08 06:43:00','2025-05-07 22:43:00','Unknown',NULL,'matched','HARDWARE','8','Dalipe,Lowel','06:43 16:28',5,'J',NULL,NULL,'2026-11-10 02:51:49'),
(53018,48,1,112,133,'8','2025-05-08 16:28:00','2025-05-08 08:28:00','Unknown',NULL,'matched','HARDWARE','8','Dalipe,Lowel','06:43 16:28',5,'J',NULL,NULL,'2026-11-10 02:51:49'),
(53019,48,1,115,136,'126','2025-05-02 07:20:00','2025-05-01 23:20:00','Unknown',NULL,'matched','LDE','126','Dela Cruz, Menen','07:20 17:38',6,'E',NULL,NULL,'2026-11-10 02:51:49'),
(53020,48,1,115,136,'126','2025-05-02 17:38:00','2025-05-02 09:38:00','Unknown',NULL,'matched','LDE','126','Dela Cruz, Menen','07:20 17:38',6,'E',NULL,NULL,'2026-11-10 02:51:49'),
(53021,48,1,115,136,'126','2025-05-04 06:52:00','2025-05-03 22:52:00','Unknown',NULL,'matched','LDE','126','Dela Cruz, Menen','06:52 16:40',6,'F',NULL,NULL,'2026-11-10 02:51:49'),
(53022,48,1,115,136,'126','2025-05-04 16:40:00','2025-05-04 08:40:00','Unknown',NULL,'matched','LDE','126','Dela Cruz, Menen','06:52 16:40',6,'F',NULL,NULL,'2026-11-10 02:51:49'),
(53023,48,1,115,136,'126','2025-05-05 06:52:00','2025-05-04 22:52:00','Unknown',NULL,'matched','LDE','126','Dela Cruz, Menen','06:52 16:40',6,'G',NULL,NULL,'2026-11-10 02:51:49'),
(53024,48,1,115,136,'126','2025-05-05 16:40:00','2025-05-05 08:40:00','Unknown',NULL,'matched','LDE','126','Dela Cruz, Menen','06:52 16:40',6,'G',NULL,NULL,'2026-11-10 02:51:49'),
(53025,48,1,115,136,'126','2025-05-06 06:56:00','2025-05-05 22:56:00','Unknown',NULL,'matched','LDE','126','Dela Cruz, Menen','06:56 16:38',6,'H',NULL,NULL,'2026-11-10 02:51:49'),
(53026,48,1,115,136,'126','2025-05-06 16:38:00','2025-05-06 08:38:00','Unknown',NULL,'matched','LDE','126','Dela Cruz, Menen','06:56 16:38',6,'H',NULL,NULL,'2026-11-10 02:51:49'),
(53027,48,1,115,136,'126','2025-05-07 07:11:00','2025-05-06 23:11:00','Unknown',NULL,'matched','LDE','126','Dela Cruz, Menen','07:11 16:36',6,'I',NULL,NULL,'2026-11-10 02:51:49'),
(53028,48,1,115,136,'126','2025-05-07 16:36:00','2025-05-07 08:36:00','Unknown',NULL,'matched','LDE','126','Dela Cruz, Menen','07:11 16:36',6,'I',NULL,NULL,'2026-11-10 02:51:49'),
(53029,48,1,115,136,'126','2025-05-08 06:56:00','2025-05-07 22:56:00','Unknown',NULL,'matched','LDE','126','Dela Cruz, Menen','06:56 16:39',6,'J',NULL,NULL,'2026-11-10 02:51:49'),
(53030,48,1,115,136,'126','2025-05-08 16:39:00','2025-05-08 08:39:00','Unknown',NULL,'matched','LDE','126','Dela Cruz, Menen','06:56 16:39',6,'J',NULL,NULL,'2026-11-10 02:51:49'),
(53031,48,1,104,125,'129','2025-05-02 06:45:00','2025-05-01 22:45:00','Unknown',NULL,'matched','LDE','129','Dela Cruz, Ronan','06:45 16:49',7,'E',NULL,NULL,'2026-11-10 02:51:49'),
(53032,48,1,104,125,'129','2025-05-02 16:49:00','2025-05-02 08:49:00','Unknown',NULL,'matched','LDE','129','Dela Cruz, Ronan','06:45 16:49',7,'E',NULL,NULL,'2026-11-10 02:51:50'),
(53033,48,1,104,125,'129','2025-05-04 07:40:00','2025-05-03 23:40:00','Unknown',NULL,'matched','LDE','129','Dela Cruz, Ronan','07:40 16:58',7,'F',NULL,NULL,'2026-11-10 02:51:50'),
(53034,48,1,104,125,'129','2025-05-04 16:58:00','2025-05-04 08:58:00','Unknown',NULL,'matched','LDE','129','Dela Cruz, Ronan','07:40 16:58',7,'F',NULL,NULL,'2026-11-10 02:51:50'),
(53035,48,1,104,125,'129','2025-05-05 07:38:00','2025-05-04 23:38:00','Unknown',NULL,'matched','LDE','129','Dela Cruz, Ronan','07:38 17:00',7,'G',NULL,NULL,'2026-11-10 02:51:50'),
(53036,48,1,104,125,'129','2025-05-05 17:00:00','2025-05-05 09:00:00','Unknown',NULL,'matched','LDE','129','Dela Cruz, Ronan','07:38 17:00',7,'G',NULL,NULL,'2026-11-10 02:51:50'),
(53037,48,1,104,125,'129','2025-05-06 07:37:00','2025-05-05 23:37:00','Unknown',NULL,'matched','LDE','129','Dela Cruz, Ronan','07:37 16:58',7,'H',NULL,NULL,'2026-11-10 02:51:50'),
(53038,48,1,104,125,'129','2025-05-06 16:58:00','2025-05-06 08:58:00','Unknown',NULL,'matched','LDE','129','Dela Cruz, Ronan','07:37 16:58',7,'H',NULL,NULL,'2026-11-10 02:51:50'),
(53039,48,1,104,125,'129','2025-05-07 07:44:00','2025-05-06 23:44:00','Unknown',NULL,'matched','LDE','129','Dela Cruz, Ronan','07:44 16:57',7,'I',NULL,NULL,'2026-11-10 02:51:50'),
(53040,48,1,104,125,'129','2025-05-07 16:57:00','2025-05-07 08:57:00','Unknown',NULL,'matched','LDE','129','Dela Cruz, Ronan','07:44 16:57',7,'I',NULL,NULL,'2026-11-10 02:51:50'),
(53041,48,1,104,125,'129','2025-05-08 07:40:00','2025-05-07 23:40:00','Unknown',NULL,'matched','LDE','129','Dela Cruz, Ronan','07:40 17:00',7,'J',NULL,NULL,'2026-11-10 02:51:50'),
(53042,48,1,104,125,'129','2025-05-08 17:00:00','2025-05-08 09:00:00','Unknown',NULL,'matched','LDE','129','Dela Cruz, Ronan','07:40 17:00',7,'J',NULL,NULL,'2026-11-10 02:51:50'),
(53043,48,1,109,130,'114','2025-05-02 06:57:00','2025-05-01 22:57:00','Unknown',NULL,'matched','HARDWARE','114','Indo, Albert','06:57',8,'E',NULL,NULL,'2026-11-10 02:51:50'),
(53044,48,1,109,130,'114','2025-05-04 06:47:00','2025-05-03 22:47:00','Unknown',NULL,'matched','HARDWARE','114','Indo, Albert','06:47 16:34',8,'F',NULL,NULL,'2026-11-10 02:51:50'),
(53045,48,1,109,130,'114','2025-05-04 16:34:00','2025-05-04 08:34:00','Unknown',NULL,'matched','HARDWARE','114','Indo, Albert','06:47 16:34',8,'F',NULL,NULL,'2026-11-10 02:51:50'),
(53046,48,1,109,130,'114','2025-05-05 06:58:00','2025-05-04 22:58:00','Unknown',NULL,'matched','HARDWARE','114','Indo, Albert','06:58 16:39',8,'G',NULL,NULL,'2026-11-10 02:51:50'),
(53047,48,1,109,130,'114','2025-05-05 16:39:00','2025-05-05 08:39:00','Unknown',NULL,'matched','HARDWARE','114','Indo, Albert','06:58 16:39',8,'G',NULL,NULL,'2026-11-10 02:51:50'),
(53048,48,1,109,130,'114','2025-05-06 06:50:00','2025-05-05 22:50:00','Unknown',NULL,'matched','HARDWARE','114','Indo, Albert','06:50 16:29',8,'H',NULL,NULL,'2026-11-10 02:51:50'),
(53049,48,1,109,130,'114','2025-05-06 16:29:00','2025-05-06 08:29:00','Unknown',NULL,'matched','HARDWARE','114','Indo, Albert','06:50 16:29',8,'H',NULL,NULL,'2026-11-10 02:51:50'),
(53050,48,1,109,130,'114','2025-05-07 07:14:00','2025-05-06 23:14:00','Unknown',NULL,'matched','HARDWARE','114','Indo, Albert','07:14 16:27',8,'I',NULL,NULL,'2026-11-10 02:51:50'),
(53051,48,1,109,130,'114','2025-05-07 16:27:00','2025-05-07 08:27:00','Unknown',NULL,'matched','HARDWARE','114','Indo, Albert','07:14 16:27',8,'I',NULL,NULL,'2026-11-10 02:51:50'),
(53052,48,1,109,130,'114','2025-05-08 06:54:00','2025-05-07 22:54:00','Unknown',NULL,'matched','HARDWARE','114','Indo, Albert','06:54 16:30',8,'J',NULL,NULL,'2026-11-10 02:51:50'),
(53053,48,1,109,130,'114','2025-05-08 16:30:00','2025-05-08 08:30:00','Unknown',NULL,'matched','HARDWARE','114','Indo, Albert','06:54 16:30',8,'J',NULL,NULL,'2026-11-10 02:51:50'),
(53054,48,1,113,134,'32','2025-05-02 06:33:00','2025-05-01 22:33:00','Unknown',NULL,'matched','HARDWARE','32','Libuna,Herwin','06:33 16:48 16:54',9,'E',NULL,NULL,'2026-11-10 02:51:50'),
(53055,48,1,113,134,'32','2025-05-02 16:48:00','2025-05-02 08:48:00','Unknown',NULL,'matched','HARDWARE','32','Libuna,Herwin','06:33 16:48 16:54',9,'E',NULL,NULL,'2026-11-10 02:51:50'),
(53056,48,1,113,134,'32','2025-05-02 16:54:00','2025-05-02 08:54:00','Unknown',NULL,'matched','HARDWARE','32','Libuna,Herwin','06:33 16:48 16:54',9,'E',NULL,NULL,'2026-11-10 02:51:51'),
(53057,48,1,113,134,'32','2025-05-04 06:35:00','2025-05-03 22:35:00','Unknown',NULL,'matched','HARDWARE','32','Libuna,Herwin','06:35 16:32',9,'F',NULL,NULL,'2026-11-10 02:51:51'),
(53058,48,1,113,134,'32','2025-05-04 16:32:00','2025-05-04 08:32:00','Unknown',NULL,'matched','HARDWARE','32','Libuna,Herwin','06:35 16:32',9,'F',NULL,NULL,'2026-11-10 02:51:51'),
(53059,48,1,113,134,'32','2025-05-05 06:49:00','2025-05-04 22:49:00','Unknown',NULL,'matched','HARDWARE','32','Libuna,Herwin','06:49 16:33',9,'G',NULL,NULL,'2026-11-10 02:51:51'),
(53060,48,1,113,134,'32','2025-05-05 16:33:00','2025-05-05 08:33:00','Unknown',NULL,'matched','HARDWARE','32','Libuna,Herwin','06:49 16:33',9,'G',NULL,NULL,'2026-11-10 02:51:51'),
(53061,48,1,113,134,'32','2025-05-06 06:56:00','2025-05-05 22:56:00','Unknown',NULL,'matched','HARDWARE','32','Libuna,Herwin','06:56 16:29',9,'H',NULL,NULL,'2026-11-10 02:51:51'),
(53062,48,1,113,134,'32','2025-05-06 16:29:00','2025-05-06 08:29:00','Unknown',NULL,'matched','HARDWARE','32','Libuna,Herwin','06:56 16:29',9,'H',NULL,NULL,'2026-11-10 02:51:51'),
(53063,48,1,113,134,'32','2025-05-07 16:28:00','2025-05-07 08:28:00','Unknown',NULL,'matched','HARDWARE','32','Libuna,Herwin','16:28',9,'I',NULL,NULL,'2026-11-10 02:51:51'),
(53064,48,1,113,134,'32','2025-05-08 06:38:00','2025-05-07 22:38:00','Unknown',NULL,'matched','HARDWARE','32','Libuna,Herwin','06:38 16:30',9,'J',NULL,NULL,'2026-11-10 02:51:51'),
(53065,48,1,113,134,'32','2025-05-08 16:30:00','2025-05-08 08:30:00','Unknown',NULL,'matched','HARDWARE','32','Libuna,Herwin','06:38 16:30',9,'J',NULL,NULL,'2026-11-10 02:51:51'),
(53066,48,1,116,137,'127','2025-05-02 06:48:00','2025-05-01 22:48:00','Unknown',NULL,'matched','HARDWARE','127','Linsaw, Manny','06:48 16:47',10,'E',NULL,NULL,'2026-11-10 02:51:51'),
(53067,48,1,116,137,'127','2025-05-02 16:47:00','2025-05-02 08:47:00','Unknown',NULL,'matched','HARDWARE','127','Linsaw, Manny','06:48 16:47',10,'E',NULL,NULL,'2026-11-10 02:51:51'),
(53068,48,1,116,137,'127','2025-05-04 07:30:00','2025-05-03 23:30:00','Unknown',NULL,'matched','HARDWARE','127','Linsaw, Manny','07:30 16:52',10,'F',NULL,NULL,'2026-11-10 02:51:51'),
(53069,48,1,116,137,'127','2025-05-04 16:52:00','2025-05-04 08:52:00','Unknown',NULL,'matched','HARDWARE','127','Linsaw, Manny','07:30 16:52',10,'F',NULL,NULL,'2026-11-10 02:51:51'),
(53070,48,1,116,137,'127','2025-05-05 07:01:00','2025-05-04 23:01:00','Unknown',NULL,'matched','HARDWARE','127','Linsaw, Manny','07:01 16:38',10,'G',NULL,NULL,'2026-11-10 02:51:51'),
(53071,48,1,116,137,'127','2025-05-05 16:38:00','2025-05-05 08:38:00','Unknown',NULL,'matched','HARDWARE','127','Linsaw, Manny','07:01 16:38',10,'G',NULL,NULL,'2026-11-10 02:51:51'),
(53072,48,1,116,137,'127','2025-05-06 07:27:00','2025-05-05 23:27:00','Unknown',NULL,'matched','HARDWARE','127','Linsaw, Manny','07:27 17:05 18:04',10,'H',NULL,NULL,'2026-11-10 02:51:51'),
(53073,48,1,116,137,'127','2025-05-06 17:05:00','2025-05-06 09:05:00','Unknown',NULL,'matched','HARDWARE','127','Linsaw, Manny','07:27 17:05 18:04',10,'H',NULL,NULL,'2026-11-10 02:51:51'),
(53074,48,1,116,137,'127','2025-05-06 18:04:00','2025-05-06 10:04:00','Unknown',NULL,'matched','HARDWARE','127','Linsaw, Manny','07:27 17:05 18:04',10,'H',NULL,NULL,'2026-11-10 02:51:51'),
(53075,48,1,116,137,'127','2025-05-07 07:28:00','2025-05-06 23:28:00','Unknown',NULL,'matched','HARDWARE','127','Linsaw, Manny','07:28 16:57',10,'I',NULL,NULL,'2026-11-10 02:51:51'),
(53076,48,1,116,137,'127','2025-05-07 16:57:00','2025-05-07 08:57:00','Unknown',NULL,'matched','HARDWARE','127','Linsaw, Manny','07:28 16:57',10,'I',NULL,NULL,'2026-11-10 02:51:51'),
(53077,48,1,116,137,'127','2025-05-08 06:53:00','2025-05-07 22:53:00','Unknown',NULL,'matched','HARDWARE','127','Linsaw, Manny','06:53 16:56',10,'J',NULL,NULL,'2026-11-10 02:51:51'),
(53078,48,1,116,137,'127','2025-05-08 16:56:00','2025-05-08 08:56:00','Unknown',NULL,'matched','HARDWARE','127','Linsaw, Manny','06:53 16:56',10,'J',NULL,NULL,'2026-11-10 02:51:51'),
(53079,48,1,105,126,'52','2025-05-02 07:29:00','2025-05-01 23:29:00','Unknown',NULL,'matched','LDE','52','Paguntalan, lovely','07:29',11,'E',NULL,NULL,'2026-11-10 02:51:51'),
(53080,48,1,105,126,'52','2025-05-04 07:33:00','2025-05-03 23:33:00','Unknown',NULL,'matched','LDE','52','Paguntalan, lovely','07:33 16:59',11,'F',NULL,NULL,'2026-11-10 02:51:52'),
(53081,48,1,105,126,'52','2025-05-04 16:59:00','2025-05-04 08:59:00','Unknown',NULL,'matched','LDE','52','Paguntalan, lovely','07:33 16:59',11,'F',NULL,NULL,'2026-11-10 02:51:52'),
(53082,48,1,105,126,'52','2025-05-05 07:22:00','2025-05-04 23:22:00','Unknown',NULL,'matched','LDE','52','Paguntalan, lovely','07:22 17:09',11,'G',NULL,NULL,'2026-11-10 02:51:52'),
(53083,48,1,105,126,'52','2025-05-05 17:09:00','2025-05-05 09:09:00','Unknown',NULL,'matched','LDE','52','Paguntalan, lovely','07:22 17:09',11,'G',NULL,NULL,'2026-11-10 02:51:52'),
(53084,48,1,105,126,'52','2025-05-06 07:33:00','2025-05-05 23:33:00','Unknown',NULL,'matched','LDE','52','Paguntalan, lovely','07:33',11,'H',NULL,NULL,'2026-11-10 02:51:52'),
(53085,48,1,105,126,'52','2025-05-07 07:35:00','2025-05-06 23:35:00','Unknown',NULL,'matched','LDE','52','Paguntalan, lovely','07:35 16:56',11,'I',NULL,NULL,'2026-11-10 02:51:52'),
(53086,48,1,105,126,'52','2025-05-07 16:56:00','2025-05-07 08:56:00','Unknown',NULL,'matched','LDE','52','Paguntalan, lovely','07:35 16:56',11,'I',NULL,NULL,'2026-11-10 02:51:52'),
(53087,48,1,105,126,'52','2025-05-08 07:31:00','2025-05-07 23:31:00','Unknown',NULL,'matched','LDE','52','Paguntalan, lovely','07:31 17:02',11,'J',NULL,NULL,'2026-11-10 02:51:52'),
(53088,48,1,105,126,'52','2025-05-08 17:02:00','2025-05-08 09:02:00','Unknown',NULL,'matched','LDE','52','Paguntalan, lovely','07:31 17:02',11,'J',NULL,NULL,'2026-11-10 02:51:52'),
(53089,48,1,107,128,'121','2025-05-02 06:51:00','2025-05-01 22:51:00','Unknown',NULL,'matched','HARDWARE','121','Pugay, Joshua','06:51 16:52',12,'E',NULL,NULL,'2026-11-10 02:51:52'),
(53090,48,1,107,128,'121','2025-05-02 16:52:00','2025-05-02 08:52:00','Unknown',NULL,'matched','HARDWARE','121','Pugay, Joshua','06:51 16:52',12,'E',NULL,NULL,'2026-11-10 02:51:52'),
(53091,48,1,107,128,'121','2025-05-04 07:03:00','2025-05-03 23:03:00','Unknown',NULL,'matched','HARDWARE','121','Pugay, Joshua','07:03 16:29',12,'F',NULL,NULL,'2026-11-10 02:51:52'),
(53092,48,1,107,128,'121','2025-05-04 16:29:00','2025-05-04 08:29:00','Unknown',NULL,'matched','HARDWARE','121','Pugay, Joshua','07:03 16:29',12,'F',NULL,NULL,'2026-11-10 02:51:52'),
(53093,48,1,107,128,'121','2025-05-05 06:50:00','2025-05-04 22:50:00','Unknown',NULL,'matched','HARDWARE','121','Pugay, Joshua','06:50 17:00',12,'G',NULL,NULL,'2026-11-10 02:51:52'),
(53094,48,1,107,128,'121','2025-05-05 17:00:00','2025-05-05 09:00:00','Unknown',NULL,'matched','HARDWARE','121','Pugay, Joshua','06:50 17:00',12,'G',NULL,NULL,'2026-11-10 02:51:52'),
(53095,48,1,107,128,'121','2025-05-06 07:01:00','2025-05-05 23:01:00','Unknown',NULL,'matched','HARDWARE','121','Pugay, Joshua','07:01 16:28',12,'H',NULL,NULL,'2026-11-10 02:51:52'),
(53096,48,1,107,128,'121','2025-05-06 16:28:00','2025-05-06 08:28:00','Unknown',NULL,'matched','HARDWARE','121','Pugay, Joshua','07:01 16:28',12,'H',NULL,NULL,'2026-11-10 02:51:52'),
(53097,48,1,107,128,'121','2025-05-07 07:12:00','2025-05-06 23:12:00','Unknown',NULL,'matched','HARDWARE','121','Pugay, Joshua','07:12 16:27',12,'I',NULL,NULL,'2026-11-10 02:51:52'),
(53098,48,1,107,128,'121','2025-05-07 16:27:00','2025-05-07 08:27:00','Unknown',NULL,'matched','HARDWARE','121','Pugay, Joshua','07:12 16:27',12,'I',NULL,NULL,'2026-11-10 02:51:52'),
(53099,48,1,107,128,'121','2025-05-08 06:41:00','2025-05-07 22:41:00','Unknown',NULL,'matched','HARDWARE','121','Pugay, Joshua','06:41 17:00',12,'J',NULL,NULL,'2026-11-10 02:51:52'),
(53100,48,1,107,128,'121','2025-05-08 17:00:00','2025-05-08 09:00:00','Unknown',NULL,'matched','HARDWARE','121','Pugay, Joshua','06:41 17:00',12,'J',NULL,NULL,'2026-11-10 02:51:52'),
(53101,48,1,117,138,'124','2025-05-02 07:42:00','2025-05-01 23:42:00','Unknown',NULL,'matched','HARDWARE','124','Tagaduar, John Dave','07:42',13,'E',NULL,NULL,'2026-11-10 02:51:52'),
(53102,48,1,117,138,'124','2025-05-04 06:45:00','2025-05-03 22:45:00','Unknown',NULL,'matched','HARDWARE','124','Tagaduar, John Dave','06:45 16:59',13,'F',NULL,NULL,'2026-11-10 02:51:52'),
(53103,48,1,117,138,'124','2025-05-04 16:59:00','2025-05-04 08:59:00','Unknown',NULL,'matched','HARDWARE','124','Tagaduar, John Dave','06:45 16:59',13,'F',NULL,NULL,'2026-11-10 02:51:52'),
(53104,48,1,117,138,'124','2025-05-05 06:41:00','2025-05-04 22:41:00','Unknown',NULL,'matched','HARDWARE','124','Tagaduar, John Dave','06:41 16:58',13,'G',NULL,NULL,'2026-11-10 02:51:52'),
(53105,48,1,117,138,'124','2025-05-05 16:58:00','2025-05-05 08:58:00','Unknown',NULL,'matched','HARDWARE','124','Tagaduar, John Dave','06:41 16:58',13,'G',NULL,NULL,'2026-11-10 02:51:52'),
(53106,48,1,117,138,'124','2025-05-06 06:54:00','2025-05-05 22:54:00','Unknown',NULL,'matched','HARDWARE','124','Tagaduar, John Dave','06:54 16:58',13,'H',NULL,NULL,'2026-11-10 02:51:53'),
(53107,48,1,117,138,'124','2025-05-06 16:58:00','2025-05-06 08:58:00','Unknown',NULL,'matched','HARDWARE','124','Tagaduar, John Dave','06:54 16:58',13,'H',NULL,NULL,'2026-11-10 02:51:53'),
(53108,48,1,117,138,'124','2025-05-07 07:12:00','2025-05-06 23:12:00','Unknown',NULL,'matched','HARDWARE','124','Tagaduar, John Dave','07:12 16:57',13,'I',NULL,NULL,'2026-11-10 02:51:53'),
(53109,48,1,117,138,'124','2025-05-07 16:57:00','2025-05-07 08:57:00','Unknown',NULL,'matched','HARDWARE','124','Tagaduar, John Dave','07:12 16:57',13,'I',NULL,NULL,'2026-11-10 02:51:53'),
(53110,48,1,117,138,'124','2025-05-08 06:40:00','2025-05-07 22:40:00','Unknown',NULL,'matched','HARDWARE','124','Tagaduar, John Dave','06:40 16:27',13,'J',NULL,NULL,'2026-11-10 02:51:53'),
(53111,48,1,117,138,'124','2025-05-08 16:27:00','2025-05-08 08:27:00','Unknown',NULL,'matched','HARDWARE','124','Tagaduar, John Dave','06:40 16:27',13,'J',NULL,NULL,'2026-11-10 02:51:53'),
(53112,48,1,108,129,'13','2025-05-02 06:57:00','2025-05-01 22:57:00','Unknown',NULL,'matched','HARDWARE','13','Tayong,Isabel','06:57',14,'E',NULL,NULL,'2026-11-10 02:51:53'),
(53113,48,1,108,129,'13','2025-05-04 06:56:00','2025-05-03 22:56:00','Unknown',NULL,'matched','HARDWARE','13','Tayong,Isabel','06:56',14,'F',NULL,NULL,'2026-11-10 02:51:53'),
(53114,48,1,108,129,'13','2025-05-05 06:52:00','2025-05-04 22:52:00','Unknown',NULL,'matched','HARDWARE','13','Tayong,Isabel','06:52 16:39',14,'G',NULL,NULL,'2026-11-10 02:51:53'),
(53115,48,1,108,129,'13','2025-05-05 16:39:00','2025-05-05 08:39:00','Unknown',NULL,'matched','HARDWARE','13','Tayong,Isabel','06:52 16:39',14,'G',NULL,NULL,'2026-11-10 02:51:53'),
(53116,48,1,108,129,'13','2025-05-06 06:55:00','2025-05-05 22:55:00','Unknown',NULL,'matched','HARDWARE','13','Tayong,Isabel','06:55 16:31',14,'H',NULL,NULL,'2026-11-10 02:51:53'),
(53117,48,1,108,129,'13','2025-05-06 16:31:00','2025-05-06 08:31:00','Unknown',NULL,'matched','HARDWARE','13','Tayong,Isabel','06:55 16:31',14,'H',NULL,NULL,'2026-11-10 02:51:53'),
(53118,48,1,108,129,'13','2025-05-07 07:11:00','2025-05-06 23:11:00','Unknown',NULL,'matched','HARDWARE','13','Tayong,Isabel','07:11 16:28',14,'I',NULL,NULL,'2026-11-10 02:51:53'),
(53119,48,1,108,129,'13','2025-05-07 16:28:00','2025-05-07 08:28:00','Unknown',NULL,'matched','HARDWARE','13','Tayong,Isabel','07:11 16:28',14,'I',NULL,NULL,'2026-11-10 02:51:53'),
(53120,48,1,108,129,'13','2025-05-08 06:53:00','2025-05-07 22:53:00','Unknown',NULL,'matched','HARDWARE','13','Tayong,Isabel','06:53 16:34',14,'J',NULL,NULL,'2026-11-10 02:51:53'),
(53121,48,1,108,129,'13','2025-05-08 16:34:00','2025-05-08 08:34:00','Unknown',NULL,'matched','HARDWARE','13','Tayong,Isabel','06:53 16:34',14,'J',NULL,NULL,'2026-11-10 02:51:53'),
(53122,48,1,111,132,'54','2025-05-02 06:54:00','2025-05-01 22:54:00','Unknown',NULL,'matched','LDE','54','Vidal, Melanie','06:54',15,'E',NULL,NULL,'2026-11-10 02:51:53'),
(53123,48,1,111,132,'54','2025-05-04 06:40:00','2025-05-03 22:40:00','Unknown',NULL,'matched','LDE','54','Vidal, Melanie','06:40 16:53',15,'F',NULL,NULL,'2026-11-10 02:51:53'),
(53124,48,1,111,132,'54','2025-05-04 16:53:00','2025-05-04 08:53:00','Unknown',NULL,'matched','LDE','54','Vidal, Melanie','06:40 16:53',15,'F',NULL,NULL,'2026-11-10 02:51:53'),
(53125,48,1,111,132,'54','2025-05-05 06:52:00','2025-05-04 22:52:00','Unknown',NULL,'matched','LDE','54','Vidal, Melanie','06:52 16:37',15,'G',NULL,NULL,'2026-11-10 02:51:53'),
(53126,48,1,111,132,'54','2025-05-05 16:37:00','2025-05-05 08:37:00','Unknown',NULL,'matched','LDE','54','Vidal, Melanie','06:52 16:37',15,'G',NULL,NULL,'2026-11-10 02:51:53'),
(53127,48,1,111,132,'54','2025-05-06 06:47:00','2025-05-05 22:47:00','Unknown',NULL,'matched','LDE','54','Vidal, Melanie','06:47 16:27',15,'H',NULL,NULL,'2026-11-10 02:51:53'),
(53128,48,1,111,132,'54','2025-05-06 16:27:00','2025-05-06 08:27:00','Unknown',NULL,'matched','LDE','54','Vidal, Melanie','06:47 16:27',15,'H',NULL,NULL,'2026-11-10 02:51:53'),
(53129,48,1,111,132,'54','2025-05-07 07:15:00','2025-05-06 23:15:00','Unknown',NULL,'matched','LDE','54','Vidal, Melanie','07:15 16:56',15,'I',NULL,NULL,'2026-11-10 02:51:53'),
(53130,48,1,111,132,'54','2025-05-07 16:56:00','2025-05-07 08:56:00','Unknown',NULL,'matched','LDE','54','Vidal, Melanie','07:15 16:56',15,'I',NULL,NULL,'2026-11-10 02:51:53'),
(53131,48,1,111,132,'54','2025-05-08 06:33:00','2025-05-07 22:33:00','Unknown',NULL,'matched','LDE','54','Vidal, Melanie','06:33 16:33',15,'J',NULL,NULL,'2026-11-10 02:51:53'),
(53132,48,1,111,132,'54','2025-05-08 16:33:00','2025-05-08 08:33:00','Unknown',NULL,'matched','LDE','54','Vidal, Melanie','06:33 16:33',15,'J',NULL,NULL,'2026-11-10 02:51:53');
/*!40000 ALTER TABLE `biometric_punch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `branch` (
  `branch_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `branch_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `branch_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Active','Inactive','Archived') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`branch_id`),
  UNIQUE KEY `uq_branch_code` (`branch_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Configurable organizational branches';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch`
--

LOCK TABLES `branch` WRITE;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` VALUES
(1,'BANGA-CON','Banga Construction Supplies','Banga, South Cotabato','Active','2026-09-02 01:00:56','2026-09-02 01:00:56'),
(2,'BANGA-AUT','Banga Auto Supplies','Banga, South Cotabato','Active','2026-09-02 01:00:56','2026-09-02 01:00:56'),
(3,'SURALLAH','Surallah Branch','Surallah, South Cotabato','Active','2026-09-02 01:00:56','2026-09-02 01:00:56');
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_advance_history`
--

DROP TABLE IF EXISTS `cash_advance_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cash_advance_history` (
  `history_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_id` bigint unsigned NOT NULL,
  `employee_id` bigint unsigned NOT NULL,
  `original_amount` decimal(12,2) NOT NULL,
  `remaining_balance` decimal(12,2) NOT NULL,
  `status` enum('Active','Paid','Cancelled','Settled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `approved_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`history_id`),
  UNIQUE KEY `uq_cah_request_id` (`request_id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `cash_advance_history_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `request` (`request_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `cash_advance_history_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_cah_balance` CHECK (((`remaining_balance` >= 0) and (`remaining_balance` <= `original_amount`) and (`original_amount` > 0)))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='One active obligation per approved cash advance request';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_advance_history`
--

LOCK TABLES `cash_advance_history` WRITE;
/*!40000 ALTER TABLE `cash_advance_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_advance_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_advance_repayment`
--

DROP TABLE IF EXISTS `cash_advance_repayment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cash_advance_repayment` (
  `repayment_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `history_id` bigint unsigned NOT NULL,
  `payroll_id` bigint unsigned NOT NULL,
  `deduction_id` bigint unsigned NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`repayment_id`),
  UNIQUE KEY `uq_car_history_payroll` (`history_id`,`payroll_id`),
  UNIQUE KEY `uq_car_deduction_id` (`deduction_id`),
  KEY `payroll_id` (`payroll_id`),
  CONSTRAINT `cash_advance_repayment_ibfk_1` FOREIGN KEY (`history_id`) REFERENCES `cash_advance_history` (`history_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `cash_advance_repayment_ibfk_2` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`payroll_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `cash_advance_repayment_ibfk_3` FOREIGN KEY (`deduction_id`) REFERENCES `deduction` (`deduction_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_car_amount` CHECK ((`amount` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Weekly repayment deductions';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_advance_repayment`
--

LOCK TABLES `cash_advance_repayment` WRITE;
/*!40000 ALTER TABLE `cash_advance_repayment` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_advance_repayment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_advance_request_detail`
--

DROP TABLE IF EXISTS `cash_advance_request_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cash_advance_request_detail` (
  `request_id` bigint unsigned NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  PRIMARY KEY (`request_id`),
  CONSTRAINT `cash_advance_request_detail_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `request` (`request_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_card_amount` CHECK ((`amount` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_advance_request_detail`
--

LOCK TABLES `cash_advance_request_detail` WRITE;
/*!40000 ALTER TABLE `cash_advance_request_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_advance_request_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `city` (
  `city_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `city_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`city_id`),
  KEY `idx_city_name` (`city_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contribution_policy_version`
--

DROP TABLE IF EXISTS `contribution_policy_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contribution_policy_version` (
  `contribution_policy_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `policy_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `demo_only` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('Draft','Approved','Retired') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Draft',
  `approved_by` bigint unsigned DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`contribution_policy_id`),
  UNIQUE KEY `uq_cpv_code_version` (`policy_code`,`version`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `contribution_policy_version_ibfk_1` FOREIGN KEY (`approved_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Versioned government contribution policy';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contribution_policy_version`
--

LOCK TABLES `contribution_policy_version` WRITE;
/*!40000 ALTER TABLE `contribution_policy_version` DISABLE KEYS */;
INSERT INTO `contribution_policy_version` VALUES
(1,'DEFAULT','V1','2024-01-01',NULL,1,'Approved',NULL,'2026-10-11 14:02:12','2026-10-11 14:02:12','2026-10-11 14:02:12');
/*!40000 ALTER TABLE `contribution_policy_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contribution_record`
--

DROP TABLE IF EXISTS `contribution_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contribution_record` (
  `contribution_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payroll_id` bigint unsigned NOT NULL,
  `deduction_id` bigint unsigned NOT NULL,
  `contribution_policy_id` bigint unsigned NOT NULL,
  `contribution_type` enum('SSS','PhilHealth','PagIBIG') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `eemr_basis` decimal(12,2) NOT NULL,
  `employee_share` decimal(12,2) NOT NULL,
  `employer_share` decimal(12,2) NOT NULL,
  `deduction_date` date NOT NULL,
  `calculation_details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Computed','Locked') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Computed',
  `locked_at` datetime DEFAULT NULL,
  `locked_by` bigint unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`contribution_id`),
  UNIQUE KEY `uq_cr_payroll_type` (`payroll_id`,`contribution_type`),
  UNIQUE KEY `uq_cr_deduction_id` (`deduction_id`),
  KEY `contribution_policy_id` (`contribution_policy_id`),
  KEY `locked_by` (`locked_by`),
  CONSTRAINT `contribution_record_ibfk_1` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`payroll_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `contribution_record_ibfk_2` FOREIGN KEY (`deduction_id`) REFERENCES `deduction` (`deduction_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `contribution_record_ibfk_3` FOREIGN KEY (`contribution_policy_id`) REFERENCES `contribution_policy_version` (`contribution_policy_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `contribution_record_ibfk_4` FOREIGN KEY (`locked_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Government contribution; unique per payroll x program';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contribution_record`
--

LOCK TABLES `contribution_record` WRITE;
/*!40000 ALTER TABLE `contribution_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `contribution_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deduction`
--

DROP TABLE IF EXISTS `deduction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `deduction` (
  `deduction_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payroll_id` bigint unsigned NOT NULL,
  `deduction_type` enum('Late','Undertime','Absence','CashAdvance','SSS','PhilHealth','PagIBIG','IncomeTax') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Absence = unpaid day already excluded from Basic Pay; recorded for audit',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_attendance_id` bigint unsigned DEFAULT NULL,
  `quantity` decimal(12,4) NOT NULL,
  `unit_rate` decimal(12,4) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `calculation_details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`deduction_id`),
  KEY `payroll_id` (`payroll_id`),
  KEY `source_attendance_id` (`source_attendance_id`),
  CONSTRAINT `deduction_ibfk_1` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`payroll_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `deduction_ibfk_2` FOREIGN KEY (`source_attendance_id`) REFERENCES `attendance` (`attendance_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=807 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Itemized deduction lines';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deduction`
--

LOCK TABLES `deduction` WRITE;
/*!40000 ALTER TABLE `deduction` DISABLE KEYS */;
/*!40000 ALTER TABLE `deduction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deposit_slip`
--

DROP TABLE IF EXISTS `deposit_slip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `deposit_slip` (
  `slip_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `batch_id` bigint unsigned NOT NULL,
  `payroll_id` bigint unsigned NOT NULL,
  `bank_id` bigint unsigned NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `status` enum('Pending','Prepared','Deposited') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `prepared_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`slip_id`),
  UNIQUE KEY `uq_slip_payroll_id` (`payroll_id`),
  KEY `batch_id` (`batch_id`),
  KEY `bank_id` (`bank_id`),
  CONSTRAINT `deposit_slip_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `disbursement_batch` (`batch_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `deposit_slip_ibfk_2` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`payroll_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `deposit_slip_ibfk_3` FOREIGN KEY (`bank_id`) REFERENCES `bank_details` (`bank_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_slip_amount` CHECK ((`amount` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Individual employee deposit slips';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deposit_slip`
--

LOCK TABLES `deposit_slip` WRITE;
/*!40000 ALTER TABLE `deposit_slip` DISABLE KEYS */;
/*!40000 ALTER TABLE `deposit_slip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disbursement_batch`
--

DROP TABLE IF EXISTS `disbursement_batch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `disbursement_batch` (
  `batch_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payroll_period_id` bigint unsigned NOT NULL,
  `bank_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BDO',
  `cheque_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cheque_total` decimal(15,2) NOT NULL,
  `status` enum('Prepared','Issued','Reconciled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Prepared',
  `prepared_by` bigint unsigned DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `uq_disbursement_period` (`payroll_period_id`),
  UNIQUE KEY `uq_disbursement_cheque` (`cheque_number`),
  KEY `prepared_by` (`prepared_by`),
  CONSTRAINT `disbursement_batch_ibfk_1` FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_period` (`payroll_period_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `disbursement_batch_ibfk_2` FOREIGN KEY (`prepared_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='One BDO cheque per payroll period';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disbursement_batch`
--

LOCK TABLES `disbursement_batch` WRITE;
/*!40000 ALTER TABLE `disbursement_batch` DISABLE KEYS */;
/*!40000 ALTER TABLE `disbursement_batch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `employee_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Immutable after creation',
  `employee_type` enum('Regular','Contractual') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_initial` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(254) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `hire_date` date NOT NULL,
  `id_picture` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_id` bigint unsigned DEFAULT NULL,
  `status` enum('Active','Inactive','Separated','Archived') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `philhealth_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pagibig_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tin_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sss_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contract_review_date` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`employee_id`),
  UNIQUE KEY `uq_employee_number` (`employee_number`),
  UNIQUE KEY `uq_employee_email` (`email`),
  KEY `address_id` (`address_id`),
  CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Core employee record; employee_number is immutable after creation';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES
(104,'129','Regular','Ronan',NULL,'Dela Cruz','almrhmaindan@gmail.com','09000000129','1995-10-11','2020-05-29',NULL,NULL,'Active','000000000129','000000000129','000-000-129','00-0000129-0','Store In-charge',NULL,'2026-11-09 22:21:25','2026-11-09 22:21:25'),
(105,'52','Regular','Lovely',NULL,'Paguntalan','jianearielleee@gmail.com','09000000052','2000-03-15','2020-05-29',NULL,NULL,'Active','000000000052','000000000052','000-000-052','00-0000052-0','Sales Clerk',NULL,'2026-11-09 22:27:21','2026-11-09 22:27:21'),
(106,'65','Regular','Dave',NULL,'Dalipe','jianegamboa22@gmail.com','09000000065','1999-04-17','2020-05-29',NULL,NULL,'Active','000000000065','000000000065','000-000-065','00-0000065-0','Checker',NULL,'2026-11-09 22:44:13','2026-11-09 22:44:13'),
(107,'121','Regular','Joshua',NULL,'Pugay','jianegamboa24@gmail.com','09000000121','2002-06-17','2020-05-29',NULL,NULL,'Active','000000000121','000000000121','000-000-121','00-0000121-0','Driver',NULL,'2026-11-09 22:51:15','2026-11-09 22:51:15'),
(108,'13','Regular','Isabel',NULL,'Tayong','jianegamboa26@gmail.com','09000000013','1996-05-11','2020-05-29',NULL,NULL,'Active','000000000013','000000000013','000-000-013','00-0000013-0','Secretary',NULL,'2026-11-10 00:11:44','2026-11-10 00:11:44'),
(109,'114','Regular','Albert',NULL,'Indo','jianegamboa28@gmail.com','09000000114','2001-06-06','2020-05-29',NULL,NULL,'Active','000000000114','000000000114','000-000-114','00-0000114-0','Cashier',NULL,'2026-11-10 00:18:50','2026-11-10 00:18:50'),
(110,'55','Regular','Laurence',NULL,'Amara','jianegamboa32@gmail.com','09000000055','1993-07-14','2020-05-29',NULL,NULL,'Active','000000000055','000000000055','000-000-055','00-0000055-0','Warehouse In-charge',NULL,'2026-11-10 00:26:39','2026-11-10 00:26:39'),
(111,'54','Regular','Melanie',NULL,'Vidal','jianegamboa35@gmail.com','09000000054','2003-08-17','2020-05-29',NULL,NULL,'Active','000000000054','000000000054','000-000-054','00-0000054-0','Encoder',NULL,'2026-11-10 00:31:34','2026-11-10 00:31:34'),
(112,'8','Regular','Lowel',NULL,'Dalipe','jianegamboa27@gmail.com','09000000008','1997-09-18','2020-05-29',NULL,NULL,'Active','000000000008','000000000008','000-000-008','00-0000008-0','Laborer',NULL,'2026-11-10 00:40:36','2026-11-10 00:40:36'),
(113,'32','Regular','Herwin',NULL,'Libuna','jianegamboa34@gmail.com','09000000032','1998-11-01','2020-05-29',NULL,NULL,'Active','000000000032','000000000032','000-000-032','00-0000032-0','Laborer',NULL,'2026-11-10 00:46:49','2026-11-10 00:46:49'),
(114,'15','Regular','Roce',NULL,'Catayoc','almairahmaindan18@gmail.com','09000000015','1992-05-11','2020-05-29',NULL,NULL,'Active','000000000015','000000000015','000-000-015','00-0000015-0','HR Head',NULL,'2026-11-10 00:53:14','2026-11-10 00:53:14'),
(115,'126','Regular','Menen',NULL,'Dela Cruz','alejandradangan@gmail.com','09000000126','1990-01-13','2020-05-29',NULL,NULL,'Active','000000000126','000000000126','000-000-126','00-0000126-0','Checker',NULL,'2026-11-10 00:58:31','2026-11-10 00:58:31'),
(116,'127','Regular','Manny',NULL,'Linsaw','k.batcharo30@gmail.com','09000000127','1991-12-03','2020-05-29',NULL,NULL,'Active','000000000127','000000000127','000-000-127','00-0000127-0','Sales Clerk',NULL,'2026-11-10 01:11:03','2026-11-10 01:11:03'),
(117,'124','Regular','John Dave',NULL,'Tagaduar','aljayveeversola@gmail.com','09000000124','2001-02-14','2020-05-29',NULL,NULL,'Active','000000000124','000000000124','000-000-124','00-0000124-0','Laborer',NULL,'2026-11-10 01:17:46','2026-11-10 01:17:46'),
(118,'test','Regular','A',NULL,'A','maindan@gmail.com','09268003661','2020-06-01','2025-01-01',NULL,NULL,'Inactive',NULL,NULL,NULL,NULL,'Laborer',NULL,'2026-11-10 09:50:23','2026-11-10 10:05:28');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_biometric_enrollment`
--

DROP TABLE IF EXISTS `employee_biometric_enrollment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_biometric_enrollment` (
  `enrollment_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `device_id` bigint unsigned NOT NULL,
  `device_employee_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Leading zeroes preserved',
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `status` enum('Active','Inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`enrollment_id`),
  UNIQUE KEY `uq_ebe_device_code_from` (`device_id`,`device_employee_code`,`effective_from`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `employee_biometric_enrollment_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `employee_biometric_enrollment_ibfk_2` FOREIGN KEY (`device_id`) REFERENCES `biometric_device` (`device_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_ebe_period` CHECK (((`effective_to` is null) or (`effective_to` > `effective_from`)))
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Maps device enrollment code to employee; preserves leading zeroes';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_biometric_enrollment`
--

LOCK TABLES `employee_biometric_enrollment` WRITE;
/*!40000 ALTER TABLE `employee_biometric_enrollment` DISABLE KEYS */;
INSERT INTO `employee_biometric_enrollment` VALUES
(102,104,1,'129','2020-05-29',NULL,'Active','2026-11-09 22:21:25','2026-11-09 22:21:25'),
(103,105,1,'52','2020-05-29',NULL,'Active','2026-11-09 22:27:21','2026-11-09 22:27:21'),
(104,106,1,'65','2020-05-29',NULL,'Active','2026-11-09 22:44:14','2026-11-09 22:44:14'),
(105,107,1,'121','2020-05-29',NULL,'Active','2026-11-09 22:51:15','2026-11-09 22:51:15'),
(106,108,1,'13','2020-05-29',NULL,'Active','2026-11-10 00:11:44','2026-11-10 00:11:44'),
(107,109,1,'114','2020-05-29',NULL,'Active','2026-11-10 00:18:51','2026-11-10 00:18:51'),
(108,110,1,'55','2020-05-29',NULL,'Active','2026-11-10 00:26:39','2026-11-10 00:26:39'),
(109,111,1,'54','2020-05-29',NULL,'Active','2026-11-10 00:31:34','2026-11-10 00:31:34'),
(110,112,1,'8','2020-05-29',NULL,'Active','2026-11-10 00:40:36','2026-11-10 00:40:36'),
(111,113,1,'32','2020-05-29',NULL,'Active','2026-11-10 00:46:49','2026-11-10 00:46:49'),
(112,114,1,'15','2020-05-29',NULL,'Active','2026-11-10 00:53:15','2026-11-10 00:53:15'),
(113,115,1,'126','2020-05-29',NULL,'Active','2026-11-10 00:58:31','2026-11-10 00:58:31'),
(114,116,1,'127','2020-05-29',NULL,'Active','2026-11-10 01:11:03','2026-11-10 01:11:03'),
(115,117,1,'124','2020-05-29',NULL,'Active','2026-11-10 01:17:46','2026-11-10 01:17:46'),
(116,118,1,'test','2025-01-01','2026-11-10','Inactive','2026-11-10 09:50:23','2026-11-10 09:51:21');
/*!40000 ALTER TABLE `employee_biometric_enrollment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_branch_assignment`
--

DROP TABLE IF EXISTS `employee_branch_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_branch_assignment` (
  `branch_assignment_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `branch_id` bigint unsigned NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `transfer_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transferred_by` bigint unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`branch_assignment_id`),
  UNIQUE KEY `uq_eba_employee_from` (`employee_id`,`effective_from`),
  KEY `branch_id` (`branch_id`),
  KEY `transferred_by` (`transferred_by`),
  CONSTRAINT `employee_branch_assignment_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `employee_branch_assignment_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `employee_branch_assignment_ibfk_3` FOREIGN KEY (`transferred_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_eba_period` CHECK (((`effective_to` is null) or (`effective_to` > `effective_from`)))
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Effective-dated branch membership; one assignment per employee per date';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_branch_assignment`
--

LOCK TABLES `employee_branch_assignment` WRITE;
/*!40000 ALTER TABLE `employee_branch_assignment` DISABLE KEYS */;
INSERT INTO `employee_branch_assignment` VALUES
(125,104,1,'2020-05-29',NULL,NULL,NULL,'2026-11-09 22:21:25'),
(126,105,1,'2020-05-29',NULL,NULL,NULL,'2026-11-09 22:27:21'),
(127,106,2,'2020-05-29',NULL,NULL,NULL,'2026-11-09 22:44:13'),
(128,107,1,'2020-05-29',NULL,NULL,NULL,'2026-11-09 22:51:15'),
(129,108,2,'2020-05-29',NULL,NULL,NULL,'2026-11-10 00:11:44'),
(130,109,1,'2020-05-29',NULL,NULL,NULL,'2026-11-10 00:18:50'),
(131,110,2,'2020-05-29',NULL,NULL,NULL,'2026-11-10 00:26:39'),
(132,111,1,'2020-05-29',NULL,NULL,NULL,'2026-11-10 00:31:34'),
(133,112,1,'2020-05-29',NULL,NULL,NULL,'2026-11-10 00:40:36'),
(134,113,1,'2020-05-29',NULL,NULL,NULL,'2026-11-10 00:46:49'),
(135,114,1,'2020-05-29',NULL,NULL,NULL,'2026-11-10 00:53:14'),
(136,115,2,'2020-05-29',NULL,NULL,NULL,'2026-11-10 00:58:31'),
(137,116,2,'2020-05-29',NULL,NULL,NULL,'2026-11-10 01:11:03'),
(138,117,1,'2020-05-29',NULL,NULL,NULL,'2026-11-10 01:17:46'),
(139,118,1,'2025-01-01','2026-11-10',NULL,NULL,'2026-11-10 09:50:23');
/*!40000 ALTER TABLE `employee_branch_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_document`
--

DROP TABLE IF EXISTS `employee_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_document` (
  `document_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `document_type` enum('IDPhoto','EmploymentContract','GovernmentID','TaxForm','BankProof','SeparationDocument','RehireDocument','Other') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Other',
  `document_label` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `original_filename` varchar(260) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `stored_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `byte_size` int unsigned NOT NULL,
  `sha256` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` enum('Current','Superseded','Archived') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Current',
  `replaces_document_id` bigint unsigned DEFAULT NULL,
  `uploaded_by` bigint unsigned NOT NULL,
  `uploaded_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `verified_by` bigint unsigned DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`document_id`),
  KEY `idx_employee_document_employee` (`employee_id`),
  KEY `idx_employee_document_status` (`status`),
  KEY `idx_employee_document_sha256` (`sha256`),
  KEY `uploaded_by` (`uploaded_by`),
  KEY `verified_by` (`verified_by`),
  CONSTRAINT `employee_document_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `employee_document_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `employee_document_ibfk_3` FOREIGN KEY (`verified_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Scanned employee documents - files stored in storage/private/';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_document`
--

LOCK TABLES `employee_document` WRITE;
/*!40000 ALTER TABLE `employee_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_employment_episode`
--

DROP TABLE IF EXISTS `employee_employment_episode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_employment_episode` (
  `episode_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `started_on` date NOT NULL,
  `ended_on` date DEFAULT NULL,
  `start_reason` enum('Hire','Rehire') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `end_reason` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`episode_id`),
  UNIQUE KEY `uq_episode_employee_start` (`employee_id`,`started_on`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `employee_employment_episode_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `employee_employment_episode_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_episode_dates` CHECK (((`ended_on` is null) or (`ended_on` >= `started_on`)))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='One row per continuous employment period for an employee';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_employment_episode`
--

LOCK TABLES `employee_employment_episode` WRITE;
/*!40000 ALTER TABLE `employee_employment_episode` DISABLE KEYS */;
INSERT INTO `employee_employment_episode` VALUES
(6,118,'2025-01-01','2026-11-09','Hire','End of Contract',NULL,2,'2026-11-10 09:51:21');
/*!40000 ALTER TABLE `employee_employment_episode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_hr_notice`
--

DROP TABLE IF EXISTS `employee_hr_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_hr_notice` (
  `notice_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `policy_flag_id` bigint unsigned NOT NULL,
  `issued_by` bigint unsigned NOT NULL,
  `title` varchar(160) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `issued_at` datetime NOT NULL,
  `acknowledged_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`notice_id`),
  UNIQUE KEY `uq_employee_hr_notice_policy_flag` (`policy_flag_id`),
  KEY `idx_employee_hr_notice_inbox` (`employee_id`,`acknowledged_at`,`issued_at`),
  KEY `issued_by` (`issued_by`),
  CONSTRAINT `employee_hr_notice_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `employee_hr_notice_ibfk_2` FOREIGN KEY (`policy_flag_id`) REFERENCES `attendance_policy_flag` (`flag_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `employee_hr_notice_ibfk_3` FOREIGN KEY (`issued_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Employee notices issued by HR from attendance policy reviews';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_hr_notice`
--

LOCK TABLES `employee_hr_notice` WRITE;
/*!40000 ALTER TABLE `employee_hr_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_hr_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_lifecycle_event`
--

DROP TABLE IF EXISTS `employee_lifecycle_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_lifecycle_event` (
  `event_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `event_type` enum('Archive','Rehire') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `previous_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `new_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `effective_date` date NOT NULL,
  `reason` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acted_by` bigint unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`event_id`),
  KEY `idx_lifecycle_employee_date` (`employee_id`,`effective_date`),
  KEY `acted_by` (`acted_by`),
  CONSTRAINT `employee_lifecycle_event_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `employee_lifecycle_event_ibfk_2` FOREIGN KEY (`acted_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Append-only audit trail for archive and rehire decisions';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_lifecycle_event`
--

LOCK TABLES `employee_lifecycle_event` WRITE;
/*!40000 ALTER TABLE `employee_lifecycle_event` DISABLE KEYS */;
INSERT INTO `employee_lifecycle_event` VALUES
(6,118,'Archive','Active','Archived','2026-11-10','End of Contract',NULL,2,'2026-11-10 09:51:21');
/*!40000 ALTER TABLE `employee_lifecycle_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_schedule_assignment`
--

DROP TABLE IF EXISTS `employee_schedule_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_schedule_assignment` (
  `assignment_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `schedule_id` bigint unsigned NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `status` enum('Active','Archived') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `notes` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`assignment_id`),
  UNIQUE KEY `uq_esa_employee_from` (`employee_id`,`effective_from`),
  KEY `schedule_id` (`schedule_id`),
  CONSTRAINT `employee_schedule_assignment_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `employee_schedule_assignment_ibfk_2` FOREIGN KEY (`schedule_id`) REFERENCES `work_schedule` (`schedule_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_esa_period` CHECK (((`effective_to` is null) or (`effective_to` > `effective_from`)))
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Links an employee to a reusable work_schedule';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_schedule_assignment`
--

LOCK TABLES `employee_schedule_assignment` WRITE;
/*!40000 ALTER TABLE `employee_schedule_assignment` DISABLE KEYS */;
INSERT INTO `employee_schedule_assignment` VALUES
(109,104,2,'2020-05-29',NULL,'Active',NULL,'2026-11-09 22:21:25','2026-11-09 22:21:25'),
(110,105,4,'2020-05-29',NULL,'Active',NULL,'2026-11-09 22:27:21','2026-11-09 22:27:21'),
(111,106,2,'2020-05-29',NULL,'Active',NULL,'2026-11-09 22:44:13','2026-11-09 22:44:13'),
(112,107,2,'2020-05-29',NULL,'Active',NULL,'2026-11-09 22:51:15','2026-11-09 22:51:15'),
(113,108,2,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:11:44','2026-11-10 00:11:44'),
(114,109,2,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:18:50','2026-11-10 00:18:50'),
(115,110,4,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:26:39','2026-11-10 00:26:39'),
(116,111,4,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:31:34','2026-11-10 00:31:34'),
(117,112,2,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:40:36','2026-11-10 00:40:36'),
(118,113,2,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:46:49','2026-11-10 00:46:49'),
(119,114,4,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:53:15','2026-11-10 00:53:15'),
(120,115,2,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:58:31','2026-11-10 00:58:31'),
(121,116,1,'2020-05-29',NULL,'Active',NULL,'2026-11-10 01:11:03','2026-11-10 01:11:03'),
(122,117,1,'2020-05-29',NULL,'Active',NULL,'2026-11-10 01:17:46','2026-11-10 01:17:46'),
(123,118,1,'2025-01-01','2026-11-10','Archived',NULL,'2026-11-10 09:50:23','2026-11-10 09:51:21');
/*!40000 ALTER TABLE `employee_schedule_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employment_contract_review`
--

DROP TABLE IF EXISTS `employment_contract_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `employment_contract_review` (
  `review_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `review_due_date` date NOT NULL,
  `outcome` enum('Regularized','Renewed','Separated') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `effective_date` date NOT NULL,
  `next_review_date` date DEFAULT NULL,
  `reviewed_by` bigint unsigned DEFAULT NULL,
  `notes` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`review_id`),
  UNIQUE KEY `uq_ecr_employee_effective` (`employee_id`,`effective_date`),
  KEY `reviewed_by` (`reviewed_by`),
  CONSTRAINT `employment_contract_review_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `employment_contract_review_ibfk_2` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Contractual employee review outcomes';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employment_contract_review`
--

LOCK TABLES `employment_contract_review` WRITE;
/*!40000 ALTER TABLE `employment_contract_review` DISABLE KEYS */;
/*!40000 ALTER TABLE `employment_contract_review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holiday_calendar`
--

DROP TABLE IF EXISTS `holiday_calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `holiday_calendar` (
  `holiday_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `holiday_date` date NOT NULL,
  `description` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `holiday_type` enum('Regular','Special','SpecialNonWorking') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pay_multiplier` decimal(4,2) NOT NULL,
  `status` enum('Active','Inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`holiday_id`),
  UNIQUE KEY `uq_holiday_date` (`holiday_date`),
  CONSTRAINT `chk_holiday_multiplier` CHECK ((((`holiday_type` = _utf8mb4'Regular') and (`pay_multiplier` = 2.00)) or ((`holiday_type` = _utf8mb4'Special') and (`pay_multiplier` = 1.00)) or ((`holiday_type` = _utf8mb4'SpecialNonWorking') and (`pay_multiplier` = 1.30))))
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Public holidays; Regular=200%, Special=130% pay multiplier per ADR-0001';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holiday_calendar`
--

LOCK TABLES `holiday_calendar` WRITE;
/*!40000 ALTER TABLE `holiday_calendar` DISABLE KEYS */;
INSERT INTO `holiday_calendar` VALUES
(1,'2026-09-10','Flomlok Festival','Regular',2.00,'Active','2026-09-04 15:16:11','2026-10-17 03:25:11'),
(2,'2026-08-31','Ninoy Aquino Day','Regular',2.00,'Active','2026-09-04 22:09:14','2026-09-04 22:09:14'),
(3,'2026-08-03','Test Regular Holiday','Regular',2.00,'Active','2026-09-06 20:12:40','2026-09-06 20:12:40'),
(4,'2026-01-01','New Year','Regular',2.00,'Active','2026-10-07 07:54:29','2026-10-07 07:54:29'),
(5,'2026-12-12','Balanced Holiday','Regular',2.00,'Active','2026-10-22 04:38:39','2026-10-25 10:02:17'),
(6,'2026-11-01','All Saint\'s Day','SpecialNonWorking',1.30,'Active','2026-10-25 09:38:07','2026-11-10 13:35:50'),
(7,'2026-11-30','Bonifacio Day','Regular',2.00,'Active','2026-11-04 08:07:30','2026-11-04 08:07:30'),
(8,'2026-06-12','Independence Day','Regular',2.00,'Active','2026-11-04 08:08:44','2026-11-04 08:08:44'),
(9,'2026-12-25','Christmas Holiday','Regular',2.00,'Active','2026-11-10 12:23:46','2026-11-10 12:23:46'),
(11,'2026-04-02','Maundy Thursday','Regular',2.00,'Active','2026-11-10 13:06:47','2026-11-10 13:06:47'),
(12,'2026-04-03','Good Friday','Regular',2.00,'Active','2026-11-10 13:08:02','2026-11-10 13:08:02'),
(13,'2026-04-09','Araw ng Kagitingan (Day of Valor','Regular',2.00,'Active','2026-11-10 13:09:34','2026-11-10 13:09:34'),
(14,'2026-05-01','Labor Day','Regular',2.00,'Active','2026-11-10 13:10:16','2026-11-10 13:10:16'),
(15,'2026-05-27','Eid\'I Adha','Regular',2.00,'Active','2026-11-10 13:13:44','2026-11-10 13:13:44'),
(17,'2026-12-30','Rizal Day','Regular',2.00,'Active','2026-11-10 13:16:23','2026-11-10 13:16:23'),
(18,'2026-03-20','Eid\'I Fitr','Regular',2.00,'Active','2026-11-10 13:17:11','2026-11-10 13:17:11'),
(19,'2026-02-17','Chinese New Year','SpecialNonWorking',1.30,'Active','2026-11-10 13:22:35','2026-11-10 13:22:35'),
(20,'2026-04-04','Black Saturday','SpecialNonWorking',1.30,'Active','2026-11-10 13:23:06','2026-11-10 13:23:06'),
(21,'2026-08-21','Ninoy Aquino Day','SpecialNonWorking',1.30,'Active','2026-11-10 13:23:46','2026-11-10 13:23:46'),
(23,'2026-11-02','All Souls\' Day','SpecialNonWorking',1.30,'Active','2026-11-10 13:26:41','2026-11-10 13:26:41'),
(24,'2026-12-08','Feast of the Immaculate Conception of Mary','SpecialNonWorking',1.30,'Active','2026-11-10 13:27:37','2026-11-10 13:27:37'),
(25,'2026-12-24','Christmas Eve','SpecialNonWorking',1.30,'Active','2026-11-10 13:28:07','2026-11-10 13:28:07'),
(26,'2026-12-31','Last Day of the Year','SpecialNonWorking',1.30,'Active','2026-11-10 13:28:51','2026-11-10 13:28:51'),
(27,'2026-02-25','EDSA People Power Revolution Anniversary','Special',1.00,'Active','2026-11-10 13:29:58','2026-11-10 13:29:58'),
(28,'2026-07-27','Founding Anniversary of Iglesia ni Cristo','Special',1.00,'Active','2026-11-10 13:31:11','2026-11-10 13:31:11'),
(29,'2026-09-08','Feast of the Nativity of the Blessed Virgin Mary','Special',1.00,'Active','2026-11-10 13:32:30','2026-11-10 13:32:30'),
(30,'2026-11-07','Sheikh Karim\'ul Makhdum Day','Special',1.00,'Active','2026-11-10 13:33:10','2026-11-10 13:33:10');
/*!40000 ALTER TABLE `holiday_calendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_position`
--

DROP TABLE IF EXISTS `job_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_position` (
  `position_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `position_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `department` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Active','Inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `sort_order` smallint unsigned NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`position_id`),
  UNIQUE KEY `uq_position_title` (`position_title`),
  KEY `idx_position_status_sort` (`status`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Managed list of job titles/positions for the employee form dropdown';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_position`
--

LOCK TABLES `job_position` WRITE;
/*!40000 ALTER TABLE `job_position` DISABLE KEYS */;
INSERT INTO `job_position` VALUES
(1,'Business Owner','Management','Active',1,'2026-09-03 00:38:57','2026-09-03 00:38:57'),
(2,'Store In-charge','Management','Active',2,'2026-09-03 00:38:57','2026-09-03 00:38:57'),
(3,'HR Head','Admin','Active',3,'2026-09-03 00:38:57','2026-09-03 00:38:57'),
(4,'Secretary','Admin','Active',4,'2026-09-03 00:38:57','2026-09-03 00:38:57'),
(5,'Accounting Staff','Admin','Active',5,'2026-09-03 00:38:57','2026-09-03 00:38:57'),
(6,'Sales Clerk','Sales','Active',10,'2026-09-03 00:38:57','2026-09-03 00:38:57'),
(7,'Cashier','Sales','Active',11,'2026-09-03 00:38:57','2026-09-03 00:38:57'),
(8,'Checker','Operations','Active',12,'2026-09-03 00:38:57','2026-09-03 00:38:57'),
(9,'Encoder','Operations','Active',13,'2026-09-03 00:38:57','2026-09-03 00:38:57'),
(10,'Warehouse In-charge','Warehouse','Active',20,'2026-09-03 00:38:57','2026-09-03 00:38:57'),
(11,'Driver','Logistics','Active',21,'2026-09-03 00:38:57','2026-09-03 00:38:57'),
(12,'Laborer','Warehouse','Active',22,'2026-09-03 00:38:57','2026-09-03 00:38:57'),
(13,'Labor',NULL,'Active',1,'2026-09-03 07:07:42','2026-09-03 07:07:42'),
(14,'Part time Cashier','Sales','Active',10,'2026-10-18 14:15:20','2026-10-18 14:15:20');
/*!40000 ALTER TABLE `job_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_entitlement`
--

DROP TABLE IF EXISTS `leave_entitlement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_entitlement` (
  `entitlement_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `leave_type` enum('Sick') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `leave_year` smallint unsigned NOT NULL,
  `entitled_days` decimal(5,2) NOT NULL DEFAULT '4.00',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`entitlement_id`),
  UNIQUE KEY `uq_le_employee_type_year` (`employee_id`,`leave_type`,`leave_year`),
  CONSTRAINT `leave_entitlement_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Annual sick leave allocation; 4 days default per ADR-0001';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_entitlement`
--

LOCK TABLES `leave_entitlement` WRITE;
/*!40000 ALTER TABLE `leave_entitlement` DISABLE KEYS */;
INSERT INTO `leave_entitlement` VALUES
(16,104,'Sick',2026,4.00,'2026-11-09 22:22:07','2026-11-09 22:22:07'),
(17,105,'Sick',2026,4.00,'2026-11-09 22:28:10','2026-11-09 22:28:10'),
(18,106,'Sick',2026,4.00,'2026-11-09 22:44:48','2026-11-09 22:44:48'),
(19,107,'Sick',2026,4.00,'2026-11-09 22:52:01','2026-11-09 22:52:01'),
(20,108,'Sick',2026,4.00,'2026-11-10 00:13:10','2026-11-10 00:13:10'),
(21,109,'Sick',2026,4.00,'2026-11-10 00:22:22','2026-11-10 00:22:22'),
(22,110,'Sick',2026,4.00,'2026-11-10 00:27:14','2026-11-10 00:27:14'),
(23,111,'Sick',2026,4.00,'2026-11-10 00:32:25','2026-11-10 00:32:25'),
(24,112,'Sick',2026,4.00,'2026-11-10 00:41:44','2026-11-10 00:41:44'),
(25,113,'Sick',2026,4.00,'2026-11-10 00:47:23','2026-11-10 00:47:23'),
(26,114,'Sick',2026,4.00,'2026-11-10 00:54:09','2026-11-10 00:54:09'),
(27,115,'Sick',2026,4.00,'2026-11-10 00:59:24','2026-11-10 00:59:24'),
(28,116,'Sick',2026,4.00,'2026-11-10 01:12:04','2026-11-10 01:12:04'),
(29,117,'Sick',2026,4.00,'2026-11-10 01:19:23','2026-11-10 01:19:23');
/*!40000 ALTER TABLE `leave_entitlement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_ledger`
--

DROP TABLE IF EXISTS `leave_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_ledger` (
  `entry_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `entitlement_id` bigint unsigned NOT NULL,
  `request_id` bigint unsigned DEFAULT NULL,
  `entry_type` enum('Grant','Usage','Adjustment','Reversal') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `days_delta` decimal(5,2) NOT NULL,
  `recorded_by` bigint unsigned DEFAULT NULL,
  `notes` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`entry_id`),
  UNIQUE KEY `uq_ll_request_id` (`request_id`),
  KEY `entitlement_id` (`entitlement_id`),
  KEY `recorded_by` (`recorded_by`),
  CONSTRAINT `leave_ledger_ibfk_1` FOREIGN KEY (`entitlement_id`) REFERENCES `leave_entitlement` (`entitlement_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `leave_ledger_ibfk_2` FOREIGN KEY (`request_id`) REFERENCES `request` (`request_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `leave_ledger_ibfk_3` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Append-only ledger; running balance = SUM(days_delta) per entitlement';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_ledger`
--

LOCK TABLES `leave_ledger` WRITE;
/*!40000 ALTER TABLE `leave_ledger` DISABLE KEYS */;
INSERT INTO `leave_ledger` VALUES
(21,16,NULL,'Grant',4.00,NULL,'Annual sick leave auto-grant','2026-11-09 22:22:07'),
(22,17,NULL,'Grant',4.00,NULL,'Annual sick leave auto-grant','2026-11-09 22:28:10'),
(23,18,NULL,'Grant',4.00,NULL,'Annual sick leave auto-grant','2026-11-09 22:44:48'),
(24,19,NULL,'Grant',4.00,NULL,'Annual sick leave auto-grant','2026-11-09 22:52:01'),
(25,20,NULL,'Grant',4.00,NULL,'Annual sick leave auto-grant','2026-11-10 00:13:10'),
(26,21,NULL,'Grant',4.00,NULL,'Annual sick leave auto-grant','2026-11-10 00:22:22'),
(27,22,NULL,'Grant',4.00,NULL,'Annual sick leave auto-grant','2026-11-10 00:27:14'),
(28,23,NULL,'Grant',4.00,NULL,'Annual sick leave auto-grant','2026-11-10 00:32:25'),
(29,24,NULL,'Grant',4.00,NULL,'Annual sick leave auto-grant','2026-11-10 00:41:44'),
(30,25,NULL,'Grant',4.00,NULL,'Annual sick leave auto-grant','2026-11-10 00:47:23'),
(31,26,NULL,'Grant',4.00,NULL,'Annual sick leave auto-grant','2026-11-10 00:54:09'),
(32,27,NULL,'Grant',4.00,NULL,'Annual sick leave auto-grant','2026-11-10 00:59:24'),
(33,28,NULL,'Grant',4.00,NULL,'Annual sick leave auto-grant','2026-11-10 01:12:04'),
(34,29,NULL,'Grant',4.00,NULL,'Annual sick leave auto-grant','2026-11-10 01:19:23');
/*!40000 ALTER TABLE `leave_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_request_detail`
--

DROP TABLE IF EXISTS `leave_request_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_request_detail` (
  `request_id` bigint unsigned NOT NULL,
  `leave_type` enum('Sick') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `days_requested` decimal(5,2) NOT NULL,
  PRIMARY KEY (`request_id`),
  CONSTRAINT `leave_request_detail_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `request` (`request_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_lrd_dates` CHECK (((`end_date` >= `start_date`) and (`days_requested` > 0)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_request_detail`
--

LOCK TABLES `leave_request_detail` WRITE;
/*!40000 ALTER TABLE `leave_request_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `leave_request_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `overtime_request_detail`
--

DROP TABLE IF EXISTS `overtime_request_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `overtime_request_detail` (
  `request_id` bigint unsigned NOT NULL,
  `overtime_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `requested_minutes` smallint unsigned NOT NULL,
  PRIMARY KEY (`request_id`),
  CONSTRAINT `overtime_request_detail_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `request` (`request_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_ord_minutes` CHECK ((`requested_minutes` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `overtime_request_detail`
--

LOCK TABLES `overtime_request_detail` WRITE;
/*!40000 ALTER TABLE `overtime_request_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `overtime_request_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagibig_rate`
--

DROP TABLE IF EXISTS `pagibig_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagibig_rate` (
  `rate_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contribution_policy_id` bigint unsigned NOT NULL,
  `rate_decimal` decimal(7,6) DEFAULT NULL,
  `basis_ceiling` decimal(12,2) DEFAULT NULL,
  `employee_fixed_amount` decimal(12,2) DEFAULT NULL,
  `employer_fixed_amount` decimal(12,2) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`rate_id`),
  UNIQUE KEY `uq_pagibig_policy` (`contribution_policy_id`),
  CONSTRAINT `pagibig_rate_ibfk_1` FOREIGN KEY (`contribution_policy_id`) REFERENCES `contribution_policy_version` (`contribution_policy_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_pagibig_mode` CHECK ((((`rate_decimal` is not null) and (`basis_ceiling` is not null)) or ((`employee_fixed_amount` is not null) and (`employer_fixed_amount` is not null))))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Pag-IBIG rate';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagibig_rate`
--

LOCK TABLES `pagibig_rate` WRITE;
/*!40000 ALTER TABLE `pagibig_rate` DISABLE KEYS */;
INSERT INTO `pagibig_rate` VALUES
(1,1,NULL,NULL,200.00,200.00,'2026-10-11 14:02:12','2026-10-11 14:02:12');
/*!40000 ALTER TABLE `pagibig_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_challenge`
--

DROP TABLE IF EXISTS `password_reset_challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_challenge` (
  `challenge_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `otp_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempts_remaining` tinyint unsigned NOT NULL,
  `consumed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`challenge_id`),
  KEY `idx_prc_user_expires` (`user_id`,`expires_at`),
  CONSTRAINT `password_reset_challenge_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Hashed, expiring, single-use OTP challenges for password recovery';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_challenge`
--

LOCK TABLES `password_reset_challenge` WRITE;
/*!40000 ALTER TABLE `password_reset_challenge` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_challenge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll`
--

DROP TABLE IF EXISTS `payroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll` (
  `payroll_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payroll_run_id` bigint unsigned NOT NULL,
  `payroll_period_id` bigint unsigned NOT NULL,
  `employee_id` bigint unsigned NOT NULL,
  `branch_assignment_id` bigint unsigned NOT NULL,
  `salary_id` bigint unsigned NOT NULL,
  `daily_rate_snapshot` decimal(12,2) NOT NULL,
  `gross_pay` decimal(12,2) NOT NULL,
  `total_deductions` decimal(12,2) NOT NULL,
  `net_pay` decimal(12,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`payroll_id`),
  UNIQUE KEY `uq_payroll_period_employee` (`payroll_period_id`,`employee_id`),
  KEY `employee_id` (`employee_id`),
  KEY `branch_assignment_id` (`branch_assignment_id`),
  KEY `salary_id` (`salary_id`),
  KEY `fk_payroll_run_period` (`payroll_run_id`,`payroll_period_id`),
  CONSTRAINT `fk_payroll_run_period` FOREIGN KEY (`payroll_run_id`, `payroll_period_id`) REFERENCES `payroll_run` (`payroll_run_id`, `payroll_period_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `payroll_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `payroll_ibfk_2` FOREIGN KEY (`branch_assignment_id`) REFERENCES `employee_branch_assignment` (`branch_assignment_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `payroll_ibfk_3` FOREIGN KEY (`salary_id`) REFERENCES `salary` (`salary_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `payroll_ibfk_4` FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_period` (`payroll_period_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=455 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Employee payroll detail; approved rows are immutable per ADR-0002';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll`
--

LOCK TABLES `payroll` WRITE;
/*!40000 ALTER TABLE `payroll` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_adjustment`
--

DROP TABLE IF EXISTS `payroll_adjustment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_adjustment` (
  `adjustment_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payroll_run_id` bigint unsigned NOT NULL,
  `payroll_id` bigint unsigned NOT NULL,
  `adjustment_type` enum('earning','deduction') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `earning_id` bigint unsigned DEFAULT NULL,
  `deduction_id` bigint unsigned DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `reason` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adjusted_by` bigint unsigned NOT NULL,
  `adjusted_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`adjustment_id`),
  KEY `idx_payroll_adjustment_payroll` (`payroll_id`),
  KEY `payroll_run_id` (`payroll_run_id`),
  KEY `earning_id` (`earning_id`),
  KEY `deduction_id` (`deduction_id`),
  KEY `adjusted_by` (`adjusted_by`),
  CONSTRAINT `payroll_adjustment_ibfk_1` FOREIGN KEY (`payroll_run_id`) REFERENCES `payroll_run` (`payroll_run_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `payroll_adjustment_ibfk_2` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`payroll_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `payroll_adjustment_ibfk_3` FOREIGN KEY (`earning_id`) REFERENCES `payroll_earnings` (`earning_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `payroll_adjustment_ibfk_4` FOREIGN KEY (`deduction_id`) REFERENCES `deduction` (`deduction_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `payroll_adjustment_ibfk_5` FOREIGN KEY (`adjusted_by`) REFERENCES `users` (`user_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Append-only HR manual payroll adjustments';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_adjustment`
--

LOCK TABLES `payroll_adjustment` WRITE;
/*!40000 ALTER TABLE `payroll_adjustment` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_adjustment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_earnings`
--

DROP TABLE IF EXISTS `payroll_earnings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_earnings` (
  `earning_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payroll_id` bigint unsigned NOT NULL,
  `earning_type` enum('Basic','Overtime','RegularHoliday','SpecialHoliday','ThirteenthMonth','ManualAdjustment') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_attendance_id` bigint unsigned DEFAULT NULL,
  `source_request_id` bigint unsigned DEFAULT NULL,
  `quantity` decimal(12,4) NOT NULL,
  `unit_rate` decimal(12,4) NOT NULL,
  `multiplier` decimal(8,4) NOT NULL DEFAULT '1.0000',
  `amount` decimal(12,2) NOT NULL,
  `calculation_details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`earning_id`),
  KEY `payroll_id` (`payroll_id`),
  KEY `source_attendance_id` (`source_attendance_id`),
  KEY `source_request_id` (`source_request_id`),
  CONSTRAINT `payroll_earnings_ibfk_1` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`payroll_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `payroll_earnings_ibfk_2` FOREIGN KEY (`source_attendance_id`) REFERENCES `attendance` (`attendance_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `payroll_earnings_ibfk_3` FOREIGN KEY (`source_request_id`) REFERENCES `request` (`request_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=504 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Itemized earning components with calculation evidence (JSON)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_earnings`
--

LOCK TABLES `payroll_earnings` WRITE;
/*!40000 ALTER TABLE `payroll_earnings` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_earnings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_period`
--

DROP TABLE IF EXISTS `payroll_period`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_period` (
  `payroll_period_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `pay_date` date NOT NULL,
  `status` enum('Open','AttendanceClosed','Disbursed','Closed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Open',
  `cutoff_pattern` enum('LegacyFridayThursday','SundayFriday') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SundayFriday',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`payroll_period_id`),
  UNIQUE KEY `uq_period_start` (`period_start`),
  UNIQUE KEY `uq_period_pay_date` (`pay_date`),
  CONSTRAINT `chk_period_cutoff_pattern` CHECK ((((`cutoff_pattern` = _utf8mb4'LegacyFridayThursday') and (dayofweek(`period_start`) = 6) and (dayofweek(`period_end`) = 5) and ((to_days(`period_end`) - to_days(`period_start`)) = 6) and (`pay_date` = (`period_end` + interval 1 day))) or ((`cutoff_pattern` = _utf8mb4'SundayFriday') and (dayofweek(`period_start`) = 1) and (dayofweek(`period_end`) = 6) and ((to_days(`period_end`) - to_days(`period_start`)) = 5) and (`pay_date` = `period_end`))))
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Weekly payroll window';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_period`
--

LOCK TABLES `payroll_period` WRITE;
/*!40000 ALTER TABLE `payroll_period` DISABLE KEYS */;
INSERT INTO `payroll_period` VALUES
(1,'2026-06-28','2026-07-03','2026-07-03','Open','SundayFriday','2026-10-08 16:55:20','2026-10-08 16:55:20'),
(2,'2026-07-05','2026-07-10','2026-07-10','Open','SundayFriday','2026-10-08 16:55:20','2026-10-08 16:55:20'),
(3,'2026-07-12','2026-07-17','2026-07-17','Open','SundayFriday','2026-10-08 16:55:20','2026-10-08 16:55:20'),
(4,'2026-07-19','2026-07-24','2026-07-24','Open','SundayFriday','2026-10-08 16:55:20','2026-10-08 16:55:20'),
(5,'2026-07-26','2026-07-31','2026-07-31','Open','SundayFriday','2026-10-08 16:55:20','2026-10-08 16:55:20'),
(6,'2026-08-02','2026-08-07','2026-08-07','Open','SundayFriday','2026-10-17 02:40:02','2026-10-17 02:40:02'),
(7,'2026-08-09','2026-08-14','2026-08-14','Open','SundayFriday','2026-10-17 02:40:02','2026-10-17 02:40:02'),
(8,'2026-08-16','2026-08-21','2026-08-21','Open','SundayFriday','2026-10-17 02:40:02','2026-10-17 02:40:02'),
(9,'2026-08-23','2026-08-28','2026-08-28','Open','SundayFriday','2026-10-17 02:40:02','2026-10-17 02:40:02'),
(10,'2026-08-30','2026-09-04','2026-09-04','Open','SundayFriday','2026-10-17 02:40:02','2026-10-17 02:40:02'),
(11,'2026-09-27','2026-10-02','2026-10-02','Open','SundayFriday','2026-10-22 05:10:50','2026-10-22 05:10:50'),
(12,'2026-10-04','2026-10-09','2026-10-09','Open','SundayFriday','2026-10-22 05:10:50','2026-10-22 05:10:50'),
(13,'2026-10-11','2026-10-16','2026-10-16','Open','SundayFriday','2026-10-22 05:10:50','2026-10-22 05:10:50'),
(14,'2026-10-18','2026-10-23','2026-10-23','Open','SundayFriday','2026-10-22 05:10:50','2026-10-22 05:10:50'),
(15,'2026-10-25','2026-10-30','2026-10-30','Open','SundayFriday','2026-10-22 05:10:50','2026-10-22 05:10:50'),
(16,'2026-11-01','2026-11-06','2026-11-06','Open','SundayFriday','2026-10-22 05:11:12','2026-10-22 05:11:12'),
(17,'2026-11-08','2026-11-13','2026-11-13','Open','SundayFriday','2026-10-22 05:11:12','2026-10-22 05:11:12'),
(18,'2026-11-15','2026-11-20','2026-11-20','Open','SundayFriday','2026-10-22 05:11:12','2026-10-22 05:11:12'),
(19,'2026-11-22','2026-11-27','2026-11-27','Open','SundayFriday','2026-10-22 05:11:12','2026-10-22 05:11:12'),
(20,'2026-11-29','2026-12-04','2026-12-04','Open','SundayFriday','2026-10-22 05:11:12','2026-10-22 05:11:12'),
(21,'2026-05-31','2026-06-05','2026-06-05','Open','SundayFriday','2026-10-22 05:11:44','2026-10-22 05:11:44'),
(22,'2026-06-07','2026-06-12','2026-06-12','Open','SundayFriday','2026-10-22 05:11:44','2026-10-22 05:11:44'),
(23,'2026-06-14','2026-06-19','2026-06-19','Open','SundayFriday','2026-10-22 05:11:44','2026-10-22 05:11:44'),
(24,'2026-06-21','2026-06-26','2026-06-26','Open','SundayFriday','2026-10-22 05:11:44','2026-10-22 05:11:44'),
(25,'2025-12-28','2026-01-02','2026-01-02','Open','SundayFriday','2026-10-22 05:12:17','2026-10-22 05:12:17'),
(26,'2026-01-04','2026-01-09','2026-01-09','Open','SundayFriday','2026-10-22 05:12:17','2026-10-22 05:12:17'),
(27,'2026-01-11','2026-01-16','2026-01-16','Open','SundayFriday','2026-10-22 05:12:17','2026-10-22 05:12:17'),
(28,'2026-01-18','2026-01-23','2026-01-23','Open','SundayFriday','2026-10-22 05:12:17','2026-10-22 05:12:17'),
(29,'2026-01-25','2026-01-30','2026-01-30','Open','SundayFriday','2026-10-22 05:12:17','2026-10-22 05:12:17'),
(30,'2020-12-27','2021-01-01','2021-01-01','Open','SundayFriday','2026-10-22 05:13:24','2026-10-22 05:13:24'),
(31,'2021-01-03','2021-01-08','2021-01-08','Open','SundayFriday','2026-10-22 05:13:24','2026-10-22 05:13:24'),
(32,'2021-01-10','2021-01-15','2021-01-15','Open','SundayFriday','2026-10-22 05:13:24','2026-10-22 05:13:24'),
(33,'2021-01-17','2021-01-22','2021-01-22','Open','SundayFriday','2026-10-22 05:13:24','2026-10-22 05:13:24'),
(34,'2021-01-24','2021-01-29','2021-01-29','Open','SundayFriday','2026-10-22 05:13:24','2026-10-22 05:13:24'),
(35,'2021-01-31','2021-02-05','2021-02-05','Open','SundayFriday','2026-10-22 05:13:24','2026-10-22 05:13:24');
/*!40000 ALTER TABLE `payroll_period` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_policy_version`
--

DROP TABLE IF EXISTS `payroll_policy_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_policy_version` (
  `policy_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `policy_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `eemr_days_per_year` smallint unsigned NOT NULL DEFAULT '313',
  `annual_tax_threshold` decimal(12,2) NOT NULL DEFAULT '250000.00',
  `late_rate_per_minute` decimal(12,2) NOT NULL DEFAULT '1.00',
  `rounding_mode` enum('HalfUp') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HalfUp',
  `demo_only` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('Draft','Approved','Retired') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Draft',
  `approved_by` bigint unsigned DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`policy_id`),
  UNIQUE KEY `uq_ppv_code_version` (`policy_code`,`version`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `payroll_policy_version_ibfk_1` FOREIGN KEY (`approved_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Versioned payroll rules';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_policy_version`
--

LOCK TABLES `payroll_policy_version` WRITE;
/*!40000 ALTER TABLE `payroll_policy_version` DISABLE KEYS */;
INSERT INTO `payroll_policy_version` VALUES
(1,'DEFAULT','V1','2024-01-01',NULL,313,250000.00,1.00,'HalfUp',1,'Approved',NULL,'2026-10-11 13:35:13','2026-10-11 13:35:13','2026-10-11 13:35:13');
/*!40000 ALTER TABLE `payroll_policy_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_run`
--

DROP TABLE IF EXISTS `payroll_run`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_run` (
  `payroll_run_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payroll_period_id` bigint unsigned NOT NULL,
  `branch_id` bigint unsigned NOT NULL,
  `payroll_policy_id` bigint unsigned NOT NULL,
  `status` enum('Draft','Computed','PendingOwnerApproval','Approved','Returned','Cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Draft',
  `gross_pay` decimal(15,2) DEFAULT NULL,
  `total_deductions` decimal(15,2) DEFAULT NULL,
  `net_pay` decimal(15,2) DEFAULT NULL,
  `computed_by` bigint unsigned DEFAULT NULL,
  `computed_at` datetime DEFAULT NULL,
  `submitted_by` bigint unsigned DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `reviewed_by` bigint unsigned DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `return_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lock_version` int unsigned NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cancellation_reason` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancelled_by` bigint unsigned DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `active_run_marker` tinyint unsigned DEFAULT '1',
  PRIMARY KEY (`payroll_run_id`),
  UNIQUE KEY `uq_run_id_period` (`payroll_run_id`,`payroll_period_id`),
  UNIQUE KEY `uq_active_run_period_branch` (`payroll_period_id`,`branch_id`,`active_run_marker`),
  KEY `branch_id` (`branch_id`),
  KEY `payroll_policy_id` (`payroll_policy_id`),
  KEY `computed_by` (`computed_by`),
  KEY `submitted_by` (`submitted_by`),
  KEY `reviewed_by` (`reviewed_by`),
  KEY `fk_payroll_run_cancelled_by` (`cancelled_by`),
  KEY `idx_run_period_branch` (`payroll_period_id`,`branch_id`),
  CONSTRAINT `fk_payroll_run_cancelled_by` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `payroll_run_ibfk_1` FOREIGN KEY (`payroll_period_id`) REFERENCES `payroll_period` (`payroll_period_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `payroll_run_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `payroll_run_ibfk_3` FOREIGN KEY (`payroll_policy_id`) REFERENCES `payroll_policy_version` (`policy_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `payroll_run_ibfk_4` FOREIGN KEY (`computed_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `payroll_run_ibfk_5` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `payroll_run_ibfk_6` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_run_returned_reason` CHECK (((`status` <> _utf8mb4'Returned') or (`return_reason` is not null)))
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Branch-scoped payroll run; status is the sole approval state per ADR-0002';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_run`
--

LOCK TABLES `payroll_run` WRITE;
/*!40000 ALTER TABLE `payroll_run` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_run` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payslip`
--

DROP TABLE IF EXISTS `payslip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payslip` (
  `payslip_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payroll_id` bigint unsigned NOT NULL,
  `issue_date` date NOT NULL,
  `file_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generated_by` bigint unsigned DEFAULT NULL,
  `generated_at` datetime NOT NULL,
  `content_hash` char(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`payslip_id`),
  UNIQUE KEY `uq_payslip_payroll_id` (`payroll_id`),
  KEY `generated_by` (`generated_by`),
  CONSTRAINT `payslip_ibfk_1` FOREIGN KEY (`payroll_id`) REFERENCES `payroll` (`payroll_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `payslip_ibfk_2` FOREIGN KEY (`generated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Digital payslip; one per payroll row';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payslip`
--

LOCK TABLES `payslip` WRITE;
/*!40000 ALTER TABLE `payslip` DISABLE KEYS */;
/*!40000 ALTER TABLE `payslip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `philhealth_rate`
--

DROP TABLE IF EXISTS `philhealth_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `philhealth_rate` (
  `rate_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contribution_policy_id` bigint unsigned NOT NULL,
  `rate_decimal` decimal(7,6) NOT NULL,
  `basis_floor` decimal(12,2) DEFAULT NULL,
  `basis_ceiling` decimal(12,2) DEFAULT NULL,
  `employee_share_decimal` decimal(7,6) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`rate_id`),
  UNIQUE KEY `uq_philhealth_policy` (`contribution_policy_id`),
  CONSTRAINT `philhealth_rate_ibfk_1` FOREIGN KEY (`contribution_policy_id`) REFERENCES `contribution_policy_version` (`contribution_policy_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PhilHealth rate';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `philhealth_rate`
--

LOCK TABLES `philhealth_rate` WRITE;
/*!40000 ALTER TABLE `philhealth_rate` DISABLE KEYS */;
INSERT INTO `philhealth_rate` VALUES
(1,1,0.040000,NULL,NULL,0.020000,'2026-10-11 14:02:12','2026-10-11 14:02:12');
/*!40000 ALTER TABLE `philhealth_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phinxlog`
--

DROP TABLE IF EXISTS `phinxlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phinxlog` (
  `version` bigint NOT NULL,
  `migration_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phinxlog`
--

LOCK TABLES `phinxlog` WRITE;
/*!40000 ALTER TABLE `phinxlog` DISABLE KEYS */;
INSERT INTO `phinxlog` VALUES
(20260831000001,'CreateIdentityAccessTables','2026-09-02 01:00:36','2026-09-02 01:00:37',0),
(20260831000002,'CreateOrganizationEmployeeTables','2026-09-02 01:00:37','2026-09-02 01:00:40',0),
(20260831000003,'CreateAttendanceImportTables','2026-09-02 01:00:40','2026-09-02 01:00:42',0),
(20260831000004,'CreateRequestLeaveCashAdvanceTables','2026-09-02 01:00:42','2026-09-02 01:00:44',0),
(20260831000005,'CreateSalaryPayrollContributionTables','2026-09-02 01:00:44','2026-09-02 01:00:48',0),
(20260831000006,'CreateBankDisbursementTables','2026-09-02 01:00:48','2026-09-02 01:00:49',0),
(20260901000007,'CreateJobPositionTable','2026-09-03 00:38:46','2026-09-03 00:38:47',0),
(20260902000007,'RefactorWorkScheduleDecoupleEmployee','2026-09-03 00:38:47','2026-09-03 00:38:49',0),
(20260903000008,'AddRequiresPasswordChangeToUsers','2026-09-03 15:40:14','2026-09-03 15:40:14',0),
(20260903000009,'CreateEmployeeLifecycleTables','2026-09-03 16:08:21','2026-09-03 16:08:22',0),
(20260904000010,'UpdatePayrollPeriodToSundayFriday','2026-09-04 09:48:37','2026-09-04 09:48:37',0),
(20260906000011,'AddAttendanceAdjustmentOvertimeColumns','2026-09-06 14:51:04','2026-09-06 14:51:04',0),
(20260906000012,'AddManualPayrollAdjustments','2026-09-06 15:23:41','2026-09-06 15:23:41',0),
(20260907000013,'CreateEmployeeDocumentTable','2026-09-07 16:59:57','2026-09-07 16:59:58',0),
(20260907000014,'AddSssNumberToEmployee','2026-09-07 16:59:58','2026-09-07 16:59:58',0),
(20260907000015,'AddAttendanceImportWorkflow','2026-09-07 17:02:42','2026-09-07 17:02:42',0),
(20260907000016,'AddSssNumberToEmployee','2026-09-07 17:02:42','2026-09-07 17:02:42',0),
(20260907000017,'AddRequestOwnerApprovalWorkflow','2026-09-21 16:24:18','2026-09-21 16:24:19',0),
(20260912000017,'AddSpecialNonWorkingHolidayType','2026-09-12 16:08:21','2026-09-12 16:08:21',0),
(20260913000018,'AddAbsencePayrollDeduction','2026-09-21 16:24:19','2026-09-21 16:24:19',0),
(20260913000019,'CreateEmployeeHrNoticeTable','2026-09-21 16:24:19','2026-09-21 16:24:20',0),
(20260921000020,'RenameRejectedToCancelledInRequest','2026-09-21 16:24:20','2026-09-21 16:24:20',0),
(20260921000021,'AddPasswordResetToUsers','2026-09-21 16:36:50','2026-09-21 16:36:51',0),
(20261001000022,'AddSupersededToSalaryStatus','2026-10-01 15:35:18','2026-10-01 15:35:18',0),
(20261010000023,'MakeAttendanceScheduleIdNullable','2026-10-10 17:36:29','2026-10-10 17:36:30',0),
(20261018000024,'AddAbsenceToDeductionType','2026-10-18 15:28:15','2026-10-18 15:28:15',0),
(20261025000025,'EnsurePayrollRunCancellationSchema','2026-10-25 00:57:32','2026-10-25 00:57:32',0),
(20261109000024,'RestoreFridayThursdayPayrollPeriod','2026-11-09 17:50:22','2026-11-09 17:50:22',0),
(20261110000025,'AddUserIdToSessions','2026-11-09 17:50:15','2026-11-09 17:50:15',0);
/*!40000 ALTER TABLE `phinxlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `province`
--

DROP TABLE IF EXISTS `province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `province` (
  `province_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `province_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`province_id`),
  UNIQUE KEY `uq_province_name` (`province_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `province`
--

LOCK TABLES `province` WRITE;
/*!40000 ALTER TABLE `province` DISABLE KEYS */;
/*!40000 ALTER TABLE `province` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `request` (
  `request_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `request_type_id` bigint unsigned NOT NULL,
  `reason` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Pending','HRApproved','Approved','Returned','Cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `submitted_at` datetime NOT NULL,
  `reviewed_by` bigint unsigned DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `review_notes` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner_reviewed_by` bigint unsigned DEFAULT NULL,
  `owner_reviewed_at` datetime DEFAULT NULL,
  `owner_notes` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `archived_by` bigint unsigned DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`request_id`),
  KEY `idx_request_employee` (`employee_id`),
  KEY `request_type_id` (`request_type_id`),
  KEY `reviewed_by` (`reviewed_by`),
  KEY `archived_by` (`archived_by`),
  KEY `owner_reviewed_by` (`owner_reviewed_by`),
  CONSTRAINT `request_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `request_ibfk_2` FOREIGN KEY (`request_type_id`) REFERENCES `request_type` (`request_type_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `request_ibfk_3` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `request_ibfk_4` FOREIGN KEY (`archived_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `request_ibfk_5` FOREIGN KEY (`owner_reviewed_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Employee request header';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request`
--

LOCK TABLES `request` WRITE;
/*!40000 ALTER TABLE `request` DISABLE KEYS */;
/*!40000 ALTER TABLE `request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `request_type`
--

DROP TABLE IF EXISTS `request_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_type` (
  `request_type_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type_name` enum('Leave','Overtime','CashAdvance') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Active','Inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`request_type_id`),
  UNIQUE KEY `uq_request_type_name` (`type_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Lookup for Leave, Overtime, CashAdvance request categories';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request_type`
--

LOCK TABLES `request_type` WRITE;
/*!40000 ALTER TABLE `request_type` DISABLE KEYS */;
INSERT INTO `request_type` VALUES
(1,'Leave','Active','2026-09-02 01:00:55','2026-09-02 01:00:55'),
(2,'Overtime','Active','2026-09-02 01:00:55','2026-09-02 01:00:55'),
(3,'CashAdvance','Active','2026-09-02 01:00:55','2026-09-02 01:00:55');
/*!40000 ALTER TABLE `request_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `role_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'BusinessOwner | HRHead | Employee',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `uq_role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Application roles: BusinessOwner, HRHead, Employee';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES
(1,'BusinessOwner','2026-09-02 01:00:55','2026-09-02 01:00:55'),
(2,'HRHead','2026-09-02 01:00:55','2026-09-02 01:00:55'),
(3,'Employee','2026-09-02 01:00:55','2026-09-02 01:00:55');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary`
--

DROP TABLE IF EXISTS `salary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `salary` (
  `salary_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned NOT NULL,
  `daily_rate` decimal(12,2) NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `status` enum('Active','Superseded','Archived') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`salary_id`),
  UNIQUE KEY `uq_salary_employee_from` (`employee_id`,`effective_from`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `salary_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `salary_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_salary_period` CHECK (((`effective_to` is null) or (`effective_to` > `effective_from`))),
  CONSTRAINT `chk_salary_rate` CHECK ((`daily_rate` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Effective-dated daily rate per employee; new row for every rate change';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary`
--

LOCK TABLES `salary` WRITE;
/*!40000 ALTER TABLE `salary` DISABLE KEYS */;
INSERT INTO `salary` VALUES
(131,104,600.00,'2020-05-29',NULL,'Active',NULL,'2026-11-09 22:21:25','2026-11-09 22:21:25'),
(132,105,465.00,'2020-05-29',NULL,'Active',NULL,'2026-11-09 22:27:21','2026-11-09 22:27:21'),
(133,106,470.00,'2020-05-29',NULL,'Active',NULL,'2026-11-09 22:44:13','2026-11-09 22:44:13'),
(134,107,520.00,'2020-05-29',NULL,'Active',NULL,'2026-11-09 22:51:15','2026-11-09 22:51:15'),
(135,108,500.00,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:11:44','2026-11-10 00:11:44'),
(136,109,480.00,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:18:50','2026-11-10 00:18:50'),
(137,110,470.00,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:26:39','2026-11-10 00:26:39'),
(138,111,500.00,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:31:34','2026-11-10 00:31:34'),
(139,112,460.00,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:40:36','2026-11-10 00:40:36'),
(140,113,460.00,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:46:49','2026-11-10 00:46:49'),
(141,114,700.00,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:53:15','2026-11-10 00:53:15'),
(142,115,470.00,'2020-05-29',NULL,'Active',NULL,'2026-11-10 00:58:31','2026-11-10 00:58:31'),
(143,116,465.00,'2020-05-29',NULL,'Active',NULL,'2026-11-10 01:11:03','2026-11-10 01:11:03'),
(144,117,460.00,'2020-05-29',NULL,'Active',NULL,'2026-11-10 01:17:46','2026-11-10 01:17:46'),
(145,118,500.00,'2025-01-01','2026-11-10','Archived',NULL,'2026-11-10 09:50:23','2026-11-10 09:51:21');
/*!40000 ALTER TABLE `salary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `expires_at` bigint unsigned NOT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `idx_sessions_expires_at` (`expires_at`),
  KEY `idx_sessions_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PHP session storage; managed by DatabaseSessionHandler';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('0ticc9p3maeljomlcbi1ffe7k2',NULL,1794309135,'_csrf_token|s:64:\"239a920e0cc4aa4996c192730e24ebd744b62df47969eac4fce36f8aec7d863e\";'),
('4h7mm7njvjq0n5p4jabv2ubt3a',NULL,1794322312,'_csrf_token|s:64:\"036354993647a351502b63afd089db469d35d7a512b2ecd16623fbfa97316c6a\";'),
('6lso28a0j4238llou3j93dobv0',NULL,1794294319,'_csrf_token|s:64:\"97501866a158a1f2f145727e569f1024bfe0469b6b6841feaed894918910dd43\";'),
('g6v24dbl17ks8959f6s8jgsbeq',133,1794333515,'_csrf_token|s:64:\"331bb163c37c1433b0ad6bba494e599d170009d21a19b180af43d7bdbdf7fa95\";_auth|a:7:{s:7:\"user_id\";i:133;s:8:\"username\";s:17:\"lovely.paguntalan\";s:9:\"role_name\";s:8:\"Employee\";s:11:\"employee_id\";i:105;s:24:\"requires_password_change\";b:0;s:12:\"logged_in_at\";i:1794290218;s:11:\"last_active\";i:1794290315;}'),
('gc3gsbpsa5vkq86bd99e7u16f8',NULL,1794323360,'_csrf_token|s:64:\"6618df2f91234abd551f8b2dac8a2970a2348b880c3a739316472b895b22633f\";'),
('jplddspfpc6v1r0k2bsldh7bom',2,1794361003,'_csrf_token|s:64:\"bc360beca43f0ed2af76c3b50118ffdbab725d96bcd8a412adf29e0538dbac9d\";_auth|a:7:{s:7:\"user_id\";i:2;s:8:\"username\";s:6:\"hrhead\";s:9:\"role_name\";s:6:\"HRHead\";s:11:\"employee_id\";N;s:24:\"requires_password_change\";b:0;s:12:\"logged_in_at\";i:1794315668;s:11:\"last_active\";i:1794317803;}'),
('kjhlj3po1e2807235udc3f2pav',NULL,1794322815,'_csrf_token|s:64:\"9df3c60f0d78af397afb74fd76f38fc64723c7a7dfae2bc9d059883a32745c9a\";'),
('mb9salfhtojtld6vmko2v2ue00',NULL,1794302436,''),
('mdckaq0pkplsuhjbkjgc654ecq',142,1794361058,'_csrf_token|s:64:\"a9ca21707e36161d3e7b57742cb27dbeaa76d5a70d874fed85ae4446a361673a\";_auth|a:7:{s:7:\"user_id\";i:142;s:8:\"username\";s:12:\"roce.catayoc\";s:9:\"role_name\";s:6:\"HRHead\";s:11:\"employee_id\";i:114;s:24:\"requires_password_change\";b:0;s:12:\"logged_in_at\";i:1794315774;s:11:\"last_active\";i:1794317858;}'),
('mdtb2ckrhfgq2v2vq788jvmbc9',NULL,1794320717,'_csrf_token|s:64:\"a499f665f90e6c713e22424fdc8ed29155ac8c6e1f8ddc3b3d5eefffcf64d8d1\";'),
('rc464nt3tde2mg4kq67k5nb4ra',NULL,1794294316,'_csrf_token|s:64:\"f45cc2c5942a661cf2efa97bf8c5032bf05df6e894afe07c9aed786308bbae6b\";'),
('sunvjbckrkcds8ejftdb9nv0nt',NULL,1794355188,'_csrf_token|s:64:\"bc1f248f0603fa73271c5718c4ea03e634443298b64728ae843df1793227e6e1\";');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sss_bracket`
--

DROP TABLE IF EXISTS `sss_bracket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sss_bracket` (
  `bracket_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contribution_policy_id` bigint unsigned NOT NULL,
  `salary_from` decimal(12,2) NOT NULL,
  `salary_to` decimal(12,2) DEFAULT NULL,
  `employee_share` decimal(12,2) NOT NULL,
  `employer_share` decimal(12,2) NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`bracket_id`),
  UNIQUE KEY `uq_sss_policy_from` (`contribution_policy_id`,`salary_from`),
  CONSTRAINT `sss_bracket_ibfk_1` FOREIGN KEY (`contribution_policy_id`) REFERENCES `contribution_policy_version` (`contribution_policy_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='SSS salary brackets';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sss_bracket`
--

LOCK TABLES `sss_bracket` WRITE;
/*!40000 ALTER TABLE `sss_bracket` DISABLE KEYS */;
INSERT INTO `sss_bracket` VALUES
(1,1,0.00,NULL,540.00,1140.00,'2024-01-01',NULL,'2026-10-11 14:02:12','2026-10-11 14:02:12');
/*!40000 ALTER TABLE `sss_bracket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint unsigned DEFAULT NULL COMMENT 'NULL for non-payroll users (e.g. Business Owner)',
  `role_id` bigint unsigned NOT NULL,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_email` varchar(254) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_reset_token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_reset_expires_at` datetime DEFAULT NULL,
  `status` enum('Active','Inactive','Archived') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `requires_password_change` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_account_email` (`account_email`),
  UNIQUE KEY `uq_users_employee_id` (`employee_id`),
  KEY `role_id` (`role_id`),
  KEY `idx_users_pwd_reset_token` (`password_reset_token`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='System accounts; employee_id nullable for the Business Owner';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,NULL,1,'owner','owner@demo.test','$2y$10$H1oIqiL5SP8bCToqOlPum.gwuU32ATbltoLar1abN9t7jf6Er0LzK',NULL,NULL,'Active',0,'2026-09-02 01:00:55','2026-10-06 17:12:10'),
(2,NULL,2,'hrhead','hrhead@demo.test','$2y$10$.BbYF9KljDOrUI2Pjl9ZqeHt.lTJtKeeraU5P/3scJN3U75B3YAIa','fa1eac29f66854bba7110241812cd492711d0ae0d62239b479eb18bfa3599a54','2026-10-18 03:19:04','Active',0,'2026-09-02 01:00:55','2026-11-09 17:53:37'),
(4,NULL,1,'support','support@email.com','$2y$10$H1oIqiL5SP8bCToqOlPum.gwuU32ATbltoLar1abN9t7jf6Er0LzK',NULL,NULL,'Archived',0,'2026-09-02 07:18:26','2026-11-09 01:29:48'),
(132,104,3,'ronan.delacruz','almrhmaindan@gmail.com','$2y$10$hIA5iBPUnTMmJHttzjHal.6Dp4CIbAQF2PZXKkUNQho5hpTi7avNS',NULL,NULL,'Active',0,'2026-11-09 22:21:25','2026-11-10 12:05:47'),
(133,105,3,'lovely.paguntalan','jianearielleee@gmail.com','$2y$10$SeGnIfiLRLVxHv/cWSk6.uR0By.r14U.VjwAI5wM2ixXkwl4hY1/C',NULL,NULL,'Active',0,'2026-11-09 22:27:21','2026-11-09 22:28:10'),
(134,106,3,'dave.dalipe','jianegamboa22@gmail.com','$2y$10$0.APNcgFb8dlovQq5XAwsO2Fe0oAcJeLRl2Nfza9Hggj53.M2XHyK',NULL,NULL,'Active',0,'2026-11-09 22:44:14','2026-11-09 22:44:48'),
(135,107,3,'joshua.pugay','jianegamboa24@gmail.com','$2y$10$gdPNQ0j8kK58WyuDa2YzB.1eJlthVUmk.r5rbN/X30PBdVFEsO8MK',NULL,NULL,'Active',0,'2026-11-09 22:51:15','2026-11-09 22:52:00'),
(136,108,3,'isabel.tayong','jianegamboa26@gmail.com','$2y$10$UtTyughgNt4WiwQG3ISh2ePNGH1sS.vi4Nz8UNFFu6ZNQGG6uuGJ.',NULL,NULL,'Active',0,'2026-11-10 00:11:44','2026-11-10 00:13:09'),
(137,109,3,'albert.indo','jianegamboa28@gmail.com','$2y$10$T8/V5xquERkImYvcc6M0..HuPM4Rp/KvssMSk4PCaPxtdSn/mbU5C',NULL,NULL,'Active',0,'2026-11-10 00:18:51','2026-11-10 00:22:21'),
(138,110,3,'laurence.amara','jianegamboa32@gmail.com','$2y$10$nYcCz8F4vbwxEPSM6n8sCO2U8nfcAXphFV8Uud4ofpPnxZspJfSKG',NULL,NULL,'Active',0,'2026-11-10 00:26:39','2026-11-10 00:27:13'),
(139,111,3,'melanie.vidal','jianegamboa35@gmail.com','$2y$10$Xo3kzKHyzEKjAl4ulfi24uev64s59sxnTTBFKy/30rdw95RJgUiPy',NULL,NULL,'Active',0,'2026-11-10 00:31:34','2026-11-10 00:32:25'),
(140,112,3,'lowel.dalipe','jianegamboa27@gmail.com','$2y$10$GBcJSv83hTQkZTJdMLF/8eYnNqOz8NTsTilnCoUo8JFond7S2fflq',NULL,NULL,'Active',0,'2026-11-10 00:40:36','2026-11-10 00:41:43'),
(141,113,3,'herwin.libuna','jianegamboa34@gmail.com','$2y$10$Fq8JghxEjaRatt5WSJEgdu7Po/QFL/rV3aK6iJh0bfJnMCK1qvY4.',NULL,NULL,'Active',0,'2026-11-10 00:46:49','2026-11-10 03:09:20'),
(142,114,2,'roce.catayoc','almairahmaindan18@gmail.com','$2y$10$KiWQaDu5liluHYP6LLKx.OW.tZpPpOVppEOPQSRC5y3dwpVMJyfjS',NULL,NULL,'Active',0,'2026-11-10 00:53:15','2026-11-10 10:37:58'),
(143,115,3,'menen.delacruz','alejandradangan@gmail.com','$2y$10$BNRz4f7SRGrwfjXmIc/LL.gk3ARW60h1No0lJRyC7C/e3Pa2pM9nq',NULL,NULL,'Active',0,'2026-11-10 00:58:31','2026-11-10 00:59:23'),
(144,116,3,'manny.linsaw','k.batcharo30@gmail.com','$2y$10$RGSGsvbOu.rHzCGP06AIuOpSaet2IebchAnHZMAl6bbklPC5FR3iC',NULL,NULL,'Active',0,'2026-11-10 01:11:03','2026-11-10 01:12:04'),
(145,117,3,'johndave.tagaduar','aljayveeversola@gmail.com','$2y$10$knq5Gg1Rpwntaq6SGSyqLO2ksmGGgPGH0c1rVWybT7eseP07AVree',NULL,NULL,'Active',0,'2026-11-10 01:17:46','2026-11-10 12:11:50'),
(146,118,3,'a.a','maindan@gmail.com','$2y$10$05PHYg9dbl1nMIbn97iXL.mcFlrOKknBiR9B3OJstlZPeTPirs5FG',NULL,NULL,'Inactive',1,'2026-11-10 09:50:23','2026-11-10 10:05:28');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_schedule`
--

DROP TABLE IF EXISTS `work_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_schedule` (
  `schedule_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `schedule_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `working_days` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON array e.g. ["Monday","Tuesday",...]',
  `rest_days` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON array e.g. ["Saturday","Sunday"]',
  `break_minutes` smallint unsigned NOT NULL DEFAULT '60',
  `grace_minutes` smallint unsigned NOT NULL DEFAULT '0',
  `overtime_allowed` tinyint(1) NOT NULL DEFAULT '1',
  `break_start_time` time DEFAULT NULL,
  `break_end_time` time DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `work_start_time` time NOT NULL,
  `work_end_time` time NOT NULL,
  `standard_minutes` smallint unsigned NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `status` enum('Active','Archived') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`schedule_id`),
  UNIQUE KEY `uq_ws_name` (`schedule_name`),
  CONSTRAINT `chk_ws_period` CHECK (((`effective_to` is null) or (`effective_to` > `effective_from`)))
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Employee work schedule templates';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_schedule`
--

LOCK TABLES `work_schedule` WRITE;
/*!40000 ALTER TABLE `work_schedule` DISABLE KEYS */;
INSERT INTO `work_schedule` VALUES
(1,'Regular Wholeday','[\"Monday\",\"Tuesday\",\"Wednesday\",\"Thursday\",\"Friday\",\"Sunday\"]','[\"Saturday\"]',60,0,1,'12:00:00','13:00:00',NULL,'07:30:00','16:30:00',480,'2020-01-01',NULL,'Active','2026-09-02 01:00:56','2026-11-10 01:08:36'),
(2,'Whole Day','[\"Monday\",\"Tuesday\",\"Wednesday\",\"Thursday\",\"Friday\"]','[\"Saturday\",\"Sunday\"]',60,0,1,'12:00:00','13:00:00','test','07:00:00','16:00:00',480,'2026-10-07',NULL,'Active','2026-09-04 14:58:22','2026-11-09 10:00:46'),
(3,'Night Shift','[\"Monday\",\"Tuesday\",\"Wednesday\",\"Thursday\",\"Friday\",\"Saturday\",\"Sunday\"]','[]',60,15,1,'00:00:00','01:00:00','Anything','06:00:00','12:00:00',300,'2026-09-12',NULL,'Archived','2026-09-12 21:57:36','2026-10-25 10:00:37'),
(4,'Wholeday','[\"Monday\",\"Tuesday\",\"Wednesday\",\"Thursday\",\"Friday\",\"Sunday\"]','[\"Saturday\"]',60,5,1,'12:00:00','13:00:00','Mid Shift','08:00:00','17:00:00',480,'2026-10-07',NULL,'Active','2026-10-01 21:40:12','2026-10-07 07:50:31'),
(5,'Sample','[\"Monday\",\"Tuesday\",\"Wednesday\",\"Thursday\",\"Friday\"]','[\"Saturday\",\"Sunday\"]',60,0,1,NULL,NULL,NULL,'08:00:00','17:00:00',480,'2026-10-01',NULL,'Archived','2026-10-01 21:45:38','2026-11-10 01:05:29'),
(7,'Afternoon Shift','[\"Monday\",\"Tuesday\",\"Wednesday\",\"Thursday\",\"Friday\",\"Sunday\"]','[\"Saturday\"]',0,0,1,NULL,NULL,NULL,'14:00:00','17:30:00',210,'2026-10-17',NULL,'Archived','2026-10-17 03:04:13','2026-11-10 02:20:57'),
(10,'Morning Shift','[\"Monday\",\"Tuesday\",\"Wednesday\",\"Thursday\",\"Friday\",\"Sunday\"]','[\"Saturday\"]',0,0,0,NULL,NULL,NULL,'07:00:00','12:00:00',300,'2026-10-25',NULL,'Archived','2026-10-24 22:19:44','2026-10-25 09:36:36'),
(11,'TEST SHIFT','[\"Monday\",\"Tuesday\",\"Wednesday\",\"Thursday\",\"Friday\"]','[\"Saturday\",\"Sunday\"]',60,0,1,NULL,NULL,NULL,'08:00:00','20:00:00',660,'2026-10-25',NULL,'Archived','2026-10-25 09:29:48','2026-11-10 01:05:23'),
(12,'Regular Shift','[\"Monday\",\"Tuesday\",\"Wednesday\",\"Thursday\",\"Friday\"]','[\"Saturday\",\"Sunday\"]',60,0,1,NULL,NULL,NULL,'08:00:00','17:00:00',480,'2026-10-25',NULL,'Archived','2026-10-25 09:35:59','2026-11-10 01:05:39'),
(13,'test','[\"Monday\",\"Tuesday\",\"Wednesday\",\"Thursday\",\"Friday\",\"Sunday\"]','[\"Saturday\"]',60,15,0,'12:00:00','13:00:00',NULL,'08:00:00','17:00:00',480,'2026-11-04',NULL,'Archived','2026-11-04 08:05:08','2026-11-04 08:05:42');
/*!40000 ALTER TABLE `work_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'railway'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-10 13:44:00
